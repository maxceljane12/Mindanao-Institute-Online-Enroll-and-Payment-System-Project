-- Add receipt_path column to bills table
ALTER TABLE `bills` 
ADD COLUMN `receipt_path` VARCHAR(255) DEFAULT NULL AFTER `status`;