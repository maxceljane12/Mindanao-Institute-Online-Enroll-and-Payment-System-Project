<?php
require_once __DIR__ . '/../includes/db.php';

echo "Testing deactivate functionality with valid user...\n";

try {
    // Get a test user with a valid ID (not the empty one)
    $stmt = $pdo->query("SELECT id, username, is_active FROM users WHERE id != '' AND role != 'admin' LIMIT 1");
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "Test user: " . $user['username'] . " (ID: " . $user['id'] . ")\n";
        echo "Current status: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
        
        // Test the deactivate functionality
        $stmt = $pdo->prepare("UPDATE users SET is_active = 0 WHERE id = ?");
        if ($stmt->execute([$user['id']])) {
            echo "SUCCESS: User deactivated\n";
            
            // Verify the change
            $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
            $stmt->execute([$user['id']]);
            $updatedUser = $stmt->fetch(PDO::FETCH_ASSOC);
            echo "Verified status: " . ($updatedUser['is_active'] ? 'Active' : 'Inactive') . "\n";
            
            // Restore original status
            $stmt = $pdo->prepare("UPDATE users SET is_active = 1 WHERE id = ?");
            $stmt->execute([$user['id']]);
            echo "Status restored to Active\n";
        } else {
            echo "ERROR: Failed to deactivate user\n";
        }
    } else {
        echo "No users with valid IDs found.\n";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "Deactivate functionality test completed.\n";
?>