-- Complete Database Schema for MI2 Student Management System
-- This script creates all tables in the correct order to satisfy foreign key constraints

-- Create users table
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(20) NOT NULL PRIMARY KEY,
  `first_name` VARCHAR(100) NOT NULL,
  `middle_name` VARCHAR(100) DEFAULT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `suffix` VARCHAR(16) DEFAULT NULL,
  `birthdate` DATE NOT NULL,
  `age` INT NOT NULL,
  `sex` VARCHAR(16) NOT NULL,
  `street` VARCHAR(255) NOT NULL,
  `barangay` VARCHAR(255) NOT NULL,
  `municipal` VARCHAR(255) NOT NULL,
  `province` VARCHAR(255) NOT NULL,
  `country` VARCHAR(128) NOT NULL,
  `zipcode` VARCHAR(16) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(32) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `security_question_1` VARCHAR(255) DEFAULT NULL,
  `answer_1` VARCHAR(255) DEFAULT NULL,
  `security_question_2` VARCHAR(255) DEFAULT NULL,
  `answer_2` VARCHAR(255) DEFAULT NULL,
  `security_question_3` VARCHAR(255) DEFAULT NULL,
  `answer_3` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create applications table
CREATE TABLE IF NOT EXISTS `applications` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` VARCHAR(64) DEFAULT NULL,
  `first_name` VARCHAR(150) NOT NULL,
  `last_name` VARCHAR(150) NOT NULL,
  `birthdate` DATE NOT NULL,
  `contact` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admission_note` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create application_details table to store detailed application information
CREATE TABLE IF NOT EXISTS `application_details` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `middle_name` VARCHAR(150) DEFAULT NULL,
  `suffix` VARCHAR(16) DEFAULT NULL,
  `place_of_birth` VARCHAR(255) DEFAULT NULL,
  `nationality` VARCHAR(100) DEFAULT NULL,
  `religion` VARCHAR(100) DEFAULT NULL,
  `lrn` VARCHAR(50) DEFAULT NULL,
  `email_address` VARCHAR(191) DEFAULT NULL,
  `home_address` VARCHAR(255) DEFAULT NULL,
  `barangay` VARCHAR(255) DEFAULT NULL,
  `municipality` VARCHAR(255) DEFAULT NULL,
  `province` VARCHAR(255) DEFAULT NULL,
  `zip_code` VARCHAR(16) DEFAULT NULL,
  `application_type` ENUM('New Student', 'Transferee', 'Returning / Balik-Aral') DEFAULT NULL,
  `last_school_attended` VARCHAR(255) DEFAULT NULL,
  `school_address` VARCHAR(255) DEFAULT NULL,
  `last_grade_level_completed` VARCHAR(100) DEFAULT NULL,
  `year_completed` VARCHAR(20) DEFAULT NULL,
  `awards_received` TEXT DEFAULT NULL,
  `mother_name` VARCHAR(255) DEFAULT NULL,
  `mother_contact` VARCHAR(255) DEFAULT NULL,
  `mother_occupation` VARCHAR(255) DEFAULT NULL,
  `father_name` VARCHAR(255) DEFAULT NULL,
  `father_contact` VARCHAR(255) DEFAULT NULL,
  `father_occupation` VARCHAR(255) DEFAULT NULL,
  `guardian_name` VARCHAR(255) DEFAULT NULL,
  `guardian_relationship` VARCHAR(100) DEFAULT NULL,
  `guardian_contact` VARCHAR(255) DEFAULT NULL,
  `guardian_address` VARCHAR(255) DEFAULT NULL,
  `emergency_name` VARCHAR(255) DEFAULT NULL,
  `emergency_relationship` VARCHAR(100) DEFAULT NULL,
  `emergency_mobile` VARCHAR(255) DEFAULT NULL,
  `emergency_address` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_application_details_application` FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create enrollments table
CREATE TABLE IF NOT EXISTS `enrollments` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `app_id` INT NOT NULL,
  `user_id` VARCHAR(64) DEFAULT NULL,
  `enrollment_number` VARCHAR(64) DEFAULT NULL,
  `first_name` VARCHAR(150) DEFAULT NULL,
  `middle_name` VARCHAR(150) DEFAULT NULL,
  `last_name` VARCHAR(150) DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `contact_number` VARCHAR(255) DEFAULT NULL,
  `guardian_name` VARCHAR(255) DEFAULT NULL,
  `guardian_contact` VARCHAR(255) DEFAULT NULL,
  `grade_level` VARCHAR(64) DEFAULT NULL,
  `strand` VARCHAR(64) DEFAULT NULL,
  `program` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('pending_payment','paid','enrolled','cancelled') NOT NULL DEFAULT 'pending_payment',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_enrollments_app` FOREIGN KEY (`app_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create bills table
CREATE TABLE IF NOT EXISTS `bills` (
  `bill_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `enrollment_id` INT NOT NULL,
  `bill_type` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `amount` DECIMAL(10, 2) NOT NULL,
  `due_date` DATE,
  `status` ENUM('pending', 'paid', 'overdue', 'cancelled', 'pending_verification') NOT NULL DEFAULT 'pending',
  `receipt_path` VARCHAR(255) DEFAULT NULL,
  `payment_method` ENUM('walk_in', 'gcash') DEFAULT NULL,
  `verified_by` VARCHAR(20) NULL,
  `verification_note` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_bills_enrollment_id` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bills_verified_by` FOREIGN KEY (`verified_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create enrollment_fees table
CREATE TABLE IF NOT EXISTS `enrollment_fees` (
  `fee_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `fee_name` VARCHAR(255) NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `school_year` VARCHAR(100) NOT NULL,
  `applicable_to_group` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create enrollment_periods table
CREATE TABLE IF NOT EXISTS `enrollment_periods` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_year` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 0,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_school_year` (`school_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert initial enrollment period for current school year
INSERT IGNORE INTO `enrollment_periods` (`school_year`, `is_active`, `start_date`, `end_date`) 
VALUES ('2025-2026', 1, '2025-06-01', '2025-12-31');

-- Create user_id_counter table
CREATE TABLE IF NOT EXISTS `user_id_counter` (
  `year` INT NOT NULL PRIMARY KEY,
  `counter` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert an initial row for the current year if it doesn't exist
INSERT IGNORE INTO `user_id_counter` (`year`, `counter`)
SELECT YEAR(CURDATE()), 0
WHERE NOT EXISTS (SELECT 1 FROM `user_id_counter` WHERE `year` = YEAR(CURDATE()));

-- Create payments table to track actual payment transactions
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `bill_id` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `payment_method` ENUM('walk_in', 'gcash') NOT NULL,
  `reference_number` VARCHAR(100) DEFAULT NULL,
  `receipt_path` VARCHAR(255) DEFAULT NULL,
  `payment_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_payments_bill` FOREIGN KEY (`bill_id`) REFERENCES `bills`(`bill_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_enrollments_user_id ON enrollments(user_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_status ON enrollments(status);
CREATE INDEX IF NOT EXISTS idx_bills_enrollment_id ON bills(enrollment_id);
CREATE INDEX IF NOT EXISTS idx_bills_status ON bills(status);
CREATE INDEX IF NOT EXISTS idx_applications_user_id ON applications(user_id);
CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_payments_bill_id ON payments(bill_id);
CREATE INDEX IF NOT EXISTS idx_payments_payment_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_payment_method ON payments(payment_method);