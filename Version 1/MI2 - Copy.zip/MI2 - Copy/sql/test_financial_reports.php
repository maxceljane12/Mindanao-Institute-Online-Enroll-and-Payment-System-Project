<?php
require_once __DIR__ . '/../includes/db.php';

// Test the same queries used in financial_reports.php
$filter_month = date('Y-m');

try {
    // Total payments received
    $stmt = $pdo->prepare("SELECT COUNT(*) as count, SUM(amount) as total FROM payments WHERE DATE_FORMAT(payment_date, '%Y-%m') = ?");
    $stmt->execute([$filter_month]);
    $monthly_payments = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Monthly payments: " . ($monthly_payments['count'] ?? 0) . " payments, Total: " . ($monthly_payments['total'] ?? 0) . "\n";
    
    // Test the join query that was failing
    $stmt = $pdo->prepare("
        SELECT p.*, e.user_id, u.first_name, u.last_name 
        FROM payments p 
        JOIN bills b ON p.bill_id = b.bill_id 
        JOIN enrollments e ON b.enrollment_id = e.id
        JOIN users u ON e.user_id = u.id 
        WHERE DATE_FORMAT(p.payment_date, '%Y-%m') = ? 
        ORDER BY p.payment_date DESC 
        LIMIT 10
    ");
    $stmt->execute([$filter_month]);
    $recent_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "Recent payments query: SUCCESS\n";
    echo "Found " . count($recent_payments) . " recent payments\n";
    
    echo "All queries executed successfully! The financial reports should now work.\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>