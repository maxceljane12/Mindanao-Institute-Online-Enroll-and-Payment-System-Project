<?php
require_once __DIR__ . '/../includes/db.php';

try {
    $stmt = $pdo->prepare("DESCRIBE bills");
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Bills table structure:\n";
    echo "====================\n";
    foreach ($columns as $column) {
        echo $column['Field'] . " " . $column['Type'] . " " . ($column['Null'] === 'YES' ? 'NULL' : 'NOT NULL');
        if ($column['Key']) echo " " . $column['Key'];
        if ($column['Default'] !== null) echo " DEFAULT " . $column['Default'];
        echo "\n";
    }
    
    // Check the relationship with enrollments
    echo "\nChecking relationship with enrollments:\n";
    $stmt = $pdo->prepare("
        SELECT b.bill_id, b.enrollment_id, e.user_id 
        FROM bills b 
        JOIN enrollments e ON b.enrollment_id = e.id 
        LIMIT 5
    ");
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($results as $row) {
        echo "Bill ID: " . $row['bill_id'] . ", Enrollment ID: " . $row['enrollment_id'] . ", User ID: " . $row['user_id'] . "\n";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>