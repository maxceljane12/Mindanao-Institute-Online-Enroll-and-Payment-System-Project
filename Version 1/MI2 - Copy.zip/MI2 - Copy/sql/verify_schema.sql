-- Verification script to confirm all tables are properly created with relationships

SELECT '=== DATABASE SCHEMA VERIFICATION ===' as message;

SELECT '1. Users table exists' as message;
SELECT COUNT(*) as user_count FROM users;

SELECT '2. Applications table exists' as message;
SELECT COUNT(*) as applications_count FROM applications;

SELECT '3. Enrollments table exists' as message;
SELECT COUNT(*) as enrollments_count FROM enrollments;

SELECT '4. Bills table exists' as message;
SELECT COUNT(*) as bills_count FROM bills;

SELECT '5. Enrollment fees table exists' as message;
SELECT COUNT(*) as fees_count FROM enrollment_fees;

SELECT '6. Enrollment periods table exists' as message;
SELECT COUNT(*) as periods_count FROM enrollment_periods;

SELECT '7. User ID counter table exists' as message;
SELECT COUNT(*) as counter_count FROM user_id_counter;

SELECT '=== FOREIGN KEY CONSTRAINTS VERIFICATION ===' as message;

SELECT '8. Enrollments with valid application references' as message;
SELECT COUNT(*) as valid_enrollments 
FROM enrollments e 
JOIN applications a ON e.app_id = a.id;

SELECT '9. Bills with valid enrollment references' as message;
SELECT COUNT(*) as valid_bills 
FROM bills b 
JOIN enrollments e ON b.enrollment_id = e.id;

SELECT '10. Bills with valid user references (verified_by)' as message;
SELECT COUNT(*) as valid_verified_bills 
FROM bills b 
LEFT JOIN users u ON b.verified_by = u.id 
WHERE b.verified_by IS NULL OR u.id IS NOT NULL;

SELECT '=== INDEXES VERIFICATION ===' as message;

SHOW INDEX FROM users;
SHOW INDEX FROM applications;
SHOW INDEX FROM enrollments;
SHOW INDEX FROM bills;

SELECT '=== SCHEMA VERIFICATION COMPLETE ===' as message;