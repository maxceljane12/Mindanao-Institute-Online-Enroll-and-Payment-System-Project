ALTER TABLE `bills`
ADD COLUMN `verified_by` VARCHAR(20) NULL AFTER `status`,
ADD COLUMN `verification_note` TEXT NULL AFTER `verified_by`,
ADD CONSTRAINT `fk_bills_verified_by` FOREIGN KEY (`verified_by`) REFERENCES `users`(`id`) ON DELETE SET NULL;
