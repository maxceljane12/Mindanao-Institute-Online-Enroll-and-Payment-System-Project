-- Example: change user 'jdoe' to role 'admin'
USE mi;
UPDATE users
SET role = 'admin'
WHERE username = 'jdoe';

-- Example: change user with id '2025-0001' to 'student'
UPDATE users
SET role = 'student'
WHERE id = '2025-0001';

-- Verify:
SELECT id, username, role FROM users WHERE username IN ('jdoe') LIMIT 10;
