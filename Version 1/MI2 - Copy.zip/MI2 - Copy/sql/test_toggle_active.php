<?php
require_once __DIR__ . '/../includes/db.php';

try {
    // Test toggling user active status
    $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE username = ?");
    
    // Deactivate a user
    $stmt->execute([0, 'Admin']);
    echo "User 'Admin' deactivated successfully.\n";
    
    // Check the status
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE username = ?");
    $stmt->execute(['Admin']);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Admin status: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
    
    // Activate the user again
    $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE username = ?");
    $stmt->execute([1, 'Admin']);
    echo "User 'Admin' activated successfully.\n";
    
    // Check the status
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE username = ?");
    $stmt->execute(['Admin']);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Admin status: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>