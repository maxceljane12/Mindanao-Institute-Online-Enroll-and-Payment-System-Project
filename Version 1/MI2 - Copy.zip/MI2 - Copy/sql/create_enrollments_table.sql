-- Create enrollments table to store enrollment form submissions after application approval
CREATE TABLE IF NOT EXISTS `enrollments` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `app_id` INT NOT NULL,
  `user_id` VARCHAR(64) DEFAULT NULL,
  `enrollment_number` VARCHAR(64) DEFAULT NULL,
  `first_name` VARCHAR(150) DEFAULT NULL,
  `middle_name` VARCHAR(150) DEFAULT NULL,
  `last_name` VARCHAR(150) DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `contact_number` VARCHAR(255) DEFAULT NULL,
  `guardian_name` VARCHAR(255) DEFAULT NULL,
  `guardian_contact` VARCHAR(255) DEFAULT NULL,
  `grade_level` VARCHAR(64) DEFAULT NULL,
  `strand` VARCHAR(64) DEFAULT NULL,
  `program` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('pending_payment','paid') NOT NULL DEFAULT 'pending_payment',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_enrollments_app` FOREIGN KEY (`app_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
