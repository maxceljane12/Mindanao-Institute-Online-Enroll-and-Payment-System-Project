<?php
require_once __DIR__ . '/../includes/db.php';

try {
    $stmt = $pdo->prepare("DESCRIBE payments");
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Payments table structure:\n";
    echo "========================\n";
    foreach ($columns as $column) {
        echo $column['Field'] . " " . $column['Type'] . " " . ($column['Null'] === 'YES' ? 'NULL' : 'NOT NULL');
        if ($column['Key']) echo " " . $column['Key'];
        if ($column['Default'] !== null) echo " DEFAULT " . $column['Default'];
        echo "\n";
    }
    
    // Test a simple query to make sure the table works
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM payments");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "\nTotal payments in table: " . $result['count'] . "\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>