<?php
require_once __DIR__ . '/../includes/db.php';

echo "Fixing enrollment periods duplicate entry issue...\n";

try {
    // Check if there are duplicate school years
    $stmt = $pdo->query("
        SELECT school_year, COUNT(*) as count 
        FROM enrollment_periods 
        GROUP BY school_year 
        HAVING COUNT(*) > 1
    ");
    $duplicates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($duplicates)) {
        echo "No duplicate school years found.\n";
    } else {
        echo "Found duplicate school years:\n";
        foreach ($duplicates as $duplicate) {
            echo "  School Year: " . $duplicate['school_year'] . " (Count: " . $duplicate['count'] . ")\n";
            
            // Get all records for this school year
            $stmt = $pdo->prepare("SELECT * FROM enrollment_periods WHERE school_year = ? ORDER BY created_at ASC");
            $stmt->execute([$duplicate['school_year']]);
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "  Keeping the most recent record (ID: " . $records[count($records)-1]['id'] . ")\n";
            
            // Delete all but the most recent record
            for ($i = 0; $i < count($records) - 1; $i++) {
                $stmt = $pdo->prepare("DELETE FROM enrollment_periods WHERE id = ?");
                $stmt->execute([$records[$i]['id']]);
                echo "  Deleted record with ID: " . $records[$i]['id'] . "\n";
            }
        }
    }
    
    // Ensure there's only one active enrollment period
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM enrollment_periods WHERE is_active = 1");
    $active_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($active_count > 1) {
        echo "Multiple active enrollment periods found. Deactivating all except the most recent...\n";
        
        // Get all active periods ordered by creation date
        $stmt = $pdo->query("SELECT id FROM enrollment_periods WHERE is_active = 1 ORDER BY created_at DESC");
        $active_periods = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Deactivate all except the first (most recent)
        for ($i = 1; $i < count($active_periods); $i++) {
            $stmt = $pdo->prepare("UPDATE enrollment_periods SET is_active = 0 WHERE id = ?");
            $stmt->execute([$active_periods[$i]['id']]);
            echo "  Deactivated enrollment period with ID: " . $active_periods[$i]['id'] . "\n";
        }
    } elseif ($active_count == 0) {
        echo "No active enrollment periods found. Setting the most recent one as active...\n";
        
        // Set the most recent enrollment period as active
        $stmt = $pdo->query("SELECT id FROM enrollment_periods ORDER BY created_at DESC LIMIT 1");
        $latest_period = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($latest_period) {
            $stmt = $pdo->prepare("UPDATE enrollment_periods SET is_active = 1 WHERE id = ?");
            $stmt->execute([$latest_period['id']]);
            echo "  Set enrollment period with ID: " . $latest_period['id'] . " as active\n";
        }
    } else {
        echo "Exactly one active enrollment period found. No changes needed.\n";
    }
    
    echo "Enrollment periods fix completed successfully!\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>