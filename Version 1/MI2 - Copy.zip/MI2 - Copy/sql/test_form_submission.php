<?php
// Simulate the form submission process
session_start();
require_once __DIR__ . '/../includes/db.php';

echo "Testing form submission for user activation/deactivation...\n";

// Get a test user who is not an admin
$stmt = $pdo->query("SELECT id, username, is_active FROM users WHERE role != 'admin' LIMIT 1");
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    echo "Test user: " . $user['username'] . " (ID: " . $user['id'] . ")\n";
    echo "Current status: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
    
    // Simulate the form data that would be sent
    $_POST['action'] = 'toggle_active';
    $_POST['user_id'] = $user['id'];
    $_POST['is_active'] = $user['is_active'] ? 0 : 1; // Toggle the status
    
    echo "Simulating form submission with:\n";
    echo "- Action: " . $_POST['action'] . "\n";
    echo "- User ID: " . $_POST['user_id'] . "\n";
    echo "- New Status: " . ($_POST['is_active'] ? 'Active' : 'Inactive') . "\n";
    
    // Process the form submission (similar to the code in manage_users.php)
    if ($_POST['action'] === 'toggle_active') {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $is_active = (int)($_POST['is_active'] ?? 0);
        
        if ($user_id > 0) {
            // Check if user exists
            $stmt = $pdo->prepare("SELECT id, username FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $found_user = $stmt->fetch();
            
            if ($found_user) {
                $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
                if ($stmt->execute([$is_active, $user_id])) {
                    $message = $is_active ? 'User activated successfully.' : 'User deactivated successfully.';
                    echo "SUCCESS: " . $message . "\n";
                    
                    // Verify the change
                    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $updatedUser = $stmt->fetch(PDO::FETCH_ASSOC);
                    echo "Verified new status: " . ($updatedUser['is_active'] ? 'Active' : 'Inactive') . "\n";
                } else {
                    echo "ERROR: Failed to update user status.\n";
                }
            } else {
                echo "ERROR: User not found.\n";
            }
        } else {
            echo "ERROR: Invalid user ID.\n";
        }
    }
    
    // Restore original status
    $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
    $stmt->execute([$user['is_active'], $user['id']]);
    echo "Status restored to original: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
} else {
    echo "No non-admin users found in database.\n";
}

echo "Form submission test completed.\n";
?>