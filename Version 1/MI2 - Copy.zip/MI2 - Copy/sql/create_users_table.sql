-- Recommended `users` table matching the registration handler
-- Review and adjust types/lengths to match your application needs before importing.

CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(20) NOT NULL PRIMARY KEY,
  `first_name` VARCHAR(100) NOT NULL,
  `middle_name` VARCHAR(100) DEFAULT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `suffix` VARCHAR(16) DEFAULT NULL,
  `birthdate` DATE NOT NULL,
  `age` INT NOT NULL,
  `sex` VARCHAR(16) NOT NULL,
  `street` VARCHAR(255) NOT NULL,
  `barangay` VARCHAR(255) NOT NULL,
  `municipal` VARCHAR(255) NOT NULL,
  `province` VARCHAR(255) NOT NULL,
  `country` VARCHAR(128) NOT NULL,
  `zipcode` VARCHAR(16) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(32) NOT NULL,
  `security_question_1` VARCHAR(255) DEFAULT NULL,
  `answer_1` VARCHAR(255) DEFAULT NULL,
  `security_question_2` VARCHAR(255) DEFAULT NULL,
  `answer_2` VARCHAR(255) DEFAULT NULL,
  `security_question_3` VARCHAR(255) DEFAULT NULL,
  `answer_3` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
