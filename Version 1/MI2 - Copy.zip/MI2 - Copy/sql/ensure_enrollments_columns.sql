-- Ensure required columns exist on `enrollments` table
-- Run this in the `mi` database (phpMyAdmin SQL tab or MySQL CLI)

-- Helper to add a column if missing
-- first_name
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'first_name'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `first_name` VARCHAR(150) DEFAULT NULL;',
  'SELECT "first_name exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- middle_name
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'middle_name'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `middle_name` VARCHAR(150) DEFAULT NULL;',
  'SELECT "middle_name exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- last_name
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'last_name'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `last_name` VARCHAR(150) DEFAULT NULL;',
  'SELECT "last_name exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- address
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'address'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `address` VARCHAR(255) DEFAULT NULL;',
  'SELECT "address exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- contact_number
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'contact_number'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `contact_number` VARCHAR(255) DEFAULT NULL;',
  'SELECT "contact_number exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- guardian_name
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'guardian_name'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `guardian_name` VARCHAR(255) DEFAULT NULL;',
  'SELECT "guardian_name exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- guardian_contact
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'guardian_contact'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `guardian_contact` VARCHAR(255) DEFAULT NULL;',
  'SELECT "guardian_contact exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- grade_level
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'grade_level'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `grade_level` VARCHAR(64) DEFAULT NULL;',
  'SELECT "grade_level exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- strand
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'strand'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `strand` VARCHAR(64) DEFAULT NULL;',
  'SELECT "strand exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- program
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'program'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `program` VARCHAR(255) DEFAULT NULL;',
  'SELECT "program exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- status (enum)
SET @exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME = 'status'
);
SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `status` ENUM(''pending_payment'',''paid'') NOT NULL DEFAULT ''pending_payment'';',
  'SELECT "status exists";'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- finished
SELECT 'ensure_enrollments_columns.sql completed' AS message;
