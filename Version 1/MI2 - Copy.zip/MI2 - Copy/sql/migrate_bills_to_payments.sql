-- Migration script to populate payments table with existing paid bills data
-- This script should be run after creating the payments table

-- Insert payments for bills that are marked as 'paid'
-- We'll use the bill creation date as the payment date for existing data
INSERT INTO payments (bill_id, amount, payment_method, payment_date, created_at, updated_at)
SELECT 
    b.bill_id,
    b.amount,
    COALESCE(b.payment_method, 'walk_in') as payment_method,
    b.updated_at as payment_date,
    b.created_at,
    b.updated_at
FROM bills b
WHERE b.status = 'paid'
AND NOT EXISTS (
    SELECT 1 FROM payments p WHERE p.bill_id = b.bill_id
);

-- For bills with receipts, copy the receipt path to the payments table
UPDATE payments p
JOIN bills b ON p.bill_id = b.bill_id
SET p.receipt_path = b.receipt_path
WHERE b.receipt_path IS NOT NULL
AND p.receipt_path IS NULL;