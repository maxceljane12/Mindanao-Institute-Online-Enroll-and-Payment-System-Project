-- Add `enrollment_number` column to `enrollments` table if it does not already exist
-- Run this in the `mi` database (phpMyAdmin SQL tab or MySQL CLI)

SET @exists := (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'enrollments'
    AND COLUMN_NAME = 'enrollment_number'
);

SET @sql := IF(@exists = 0,
  'ALTER TABLE `enrollments` ADD COLUMN `enrollment_number` VARCHAR(64) DEFAULT NULL AFTER `user_id`;',
  'SELECT "enrollment_number column already exists";'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- If the `enrollments` table does not exist, run the create script instead:
-- See `sql/create_enrollments_table.sql` in this repo.
