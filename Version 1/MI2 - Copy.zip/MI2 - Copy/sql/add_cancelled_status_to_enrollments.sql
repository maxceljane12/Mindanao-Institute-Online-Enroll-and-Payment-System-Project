ALTER TABLE `enrollments` MODIFY `status` ENUM('pending_payment','paid','enrolled','cancelled') NOT NULL DEFAULT 'pending_payment';
