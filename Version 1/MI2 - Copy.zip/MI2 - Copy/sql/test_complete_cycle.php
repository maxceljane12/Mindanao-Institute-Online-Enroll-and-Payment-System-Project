<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

// Test both activate and deactivate functionality
echo "Testing complete activate/deactivate cycle...\n";

try {
    // Get a user with a valid ID to test with
    $stmt = $pdo->query("SELECT id, username, is_active FROM users WHERE id != '' AND role != 'admin' LIMIT 1");
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "Test user: " . $user['username'] . " (ID: " . $user['id'] . ")\n";
        echo "Initial status: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
        
        // First, deactivate the user
        echo "\n1. Deactivating user...\n";
        $_POST['action'] = 'toggle_active';
        $_POST['user_id'] = $user['id'];
        $_POST['is_active'] = 0; // 0 means deactivate
        
        processToggleAction();
        
        // Verify user is deactivated
        $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
        $stmt->execute([$user['id']]);
        $updatedUser = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "Status after deactivation: " . ($updatedUser['is_active'] ? 'Active' : 'Inactive') . "\n";
        
        // Then, activate the user
        echo "\n2. Activating user...\n";
        $_POST['action'] = 'toggle_active';
        $_POST['user_id'] = $user['id'];
        $_POST['is_active'] = 1; // 1 means activate
        
        processToggleAction();
        
        // Verify user is activated
        $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
        $stmt->execute([$user['id']]);
        $updatedUser = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "Status after activation: " . ($updatedUser['is_active'] ? 'Active' : 'Inactive') . "\n";
        
        echo "\nComplete cycle test PASSED!\n";
    } else {
        echo "No valid users found for testing.\n";
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage() . "\n";
}

function processToggleAction() {
    global $pdo;
    
    if ($_POST['action'] === 'toggle_active') {
        $user_id = trim($_POST['user_id'] ?? '');
        $is_active = (int)($_POST['is_active'] ?? 0);
        
        if (empty($user_id)) {
            echo "ERROR: Invalid user ID.\n";
            return false;
        } else {
            // Check if user exists
            $stmt = $pdo->prepare("SELECT id, username FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $found_user = $stmt->fetch();
            
            if (!$found_user) {
                echo "ERROR: User not found.\n";
                return false;
            } else {
                $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
                if ($stmt->execute([$is_active, $user_id])) {
                    $message = $is_active ? 'User activated successfully.' : 'User deactivated successfully.';
                    echo "SUCCESS: " . $message . "\n";
                    return true;
                } else {
                    echo "ERROR: Failed to update user status.\n";
                    return false;
                }
            }
        }
    }
}

echo "Complete activate/deactivate test completed.\n";
?>