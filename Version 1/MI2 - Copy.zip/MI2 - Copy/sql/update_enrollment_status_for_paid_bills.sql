-- Update enrollment status to 'paid' for enrollments that have paid bills
-- This fixes existing data where the enrollment status was not properly updated
-- when bills were paid

UPDATE enrollments e 
JOIN bills b ON e.id = b.enrollment_id 
SET e.status = 'paid' 
WHERE b.status = 'paid' AND e.status = 'pending_payment';

SELECT ROW_COUNT() AS 'Number of enrollments updated';