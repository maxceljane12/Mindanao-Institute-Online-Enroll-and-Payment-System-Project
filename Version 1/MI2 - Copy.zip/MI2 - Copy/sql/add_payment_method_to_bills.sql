-- Add payment_method column to bills table
ALTER TABLE `bills` 
ADD COLUMN `payment_method` ENUM('walk_in', 'gcash') DEFAULT NULL AFTER `status`;