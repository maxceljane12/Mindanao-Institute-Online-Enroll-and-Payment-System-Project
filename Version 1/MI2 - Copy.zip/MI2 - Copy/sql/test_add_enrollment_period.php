<?php
require_once __DIR__ . '/../includes/db.php';

echo "Testing enrollment period addition...\n";

try {
    // Test adding a new enrollment period
    $school_year = '2025-2026';
    $start_date = '2025-06-01';
    $end_date = '2025-12-31';
    $is_active = 1;
    
    // Check if school year already exists
    $stmt = $pdo->prepare("SELECT id FROM enrollment_periods WHERE school_year = ?");
    $stmt->execute([$school_year]);
    $existing_period = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_period) {
        echo "School year '$school_year' already exists. Updating instead of inserting...\n";
        
        // If setting as active, deactivate all others first
        if ($is_active) {
            $stmt = $pdo->prepare("UPDATE enrollment_periods SET is_active = 0");
            $stmt->execute();
        }
        
        // Update existing period
        $stmt = $pdo->prepare("UPDATE enrollment_periods SET start_date = ?, end_date = ?, is_active = ? WHERE school_year = ?");
        $stmt->execute([$start_date, $end_date, $is_active, $school_year]);
        echo "Successfully updated enrollment period for '$school_year'\n";
    } else {
        echo "School year '$school_year' does not exist. Inserting new record...\n";
        
        // If setting as active, deactivate all others first
        if ($is_active) {
            $stmt = $pdo->prepare("UPDATE enrollment_periods SET is_active = 0");
            $stmt->execute();
        }
        
        // Insert new period
        $stmt = $pdo->prepare("INSERT INTO enrollment_periods (school_year, start_date, end_date, is_active) VALUES (?, ?, ?, ?)");
        $stmt->execute([$school_year, $start_date, $end_date, $is_active]);
        echo "Successfully added new enrollment period for '$school_year'\n";
    }
    
    echo "Test completed successfully!\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>