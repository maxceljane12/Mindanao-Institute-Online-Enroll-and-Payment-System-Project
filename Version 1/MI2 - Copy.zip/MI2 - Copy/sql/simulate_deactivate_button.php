<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

// Simulate the exact scenario that would happen when clicking the deactivate button
echo "Simulating deactivate button click...\n";

try {
    // Get a user with a valid ID to test with
    $stmt = $pdo->query("SELECT id, username, is_active FROM users WHERE id != '' AND role != 'admin' LIMIT 1");
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "Test user: " . $user['username'] . " (ID: " . $user['id'] . ")\n";
        echo "Current status: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
        
        // Simulate the exact POST data that would be sent when clicking deactivate
        $_POST['action'] = 'toggle_active';
        $_POST['user_id'] = $user['id'];
        $_POST['is_active'] = 0; // 0 means deactivate
        
        echo "Simulating POST data:\n";
        echo "- action: " . $_POST['action'] . "\n";
        echo "- user_id: " . $_POST['user_id'] . "\n";
        echo "- is_active: " . $_POST['is_active'] . "\n";
        
        // Process exactly as the manage_users.php file would
        if ($_POST['action'] === 'toggle_active') {
            $user_id = trim($_POST['user_id'] ?? '');
            $is_active = (int)($_POST['is_active'] ?? 0);
            
            if (empty($user_id)) {
                echo "ERROR: Invalid user ID.\n";
            } else {
                // Check if user exists
                $stmt = $pdo->prepare("SELECT id, username FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $found_user = $stmt->fetch();
                
                if (!$found_user) {
                    echo "ERROR: User not found.\n";
                } else {
                    $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
                    if ($stmt->execute([$is_active, $user_id])) {
                        $message = $is_active ? 'User activated successfully.' : 'User deactivated successfully.';
                        echo "SUCCESS: " . $message . "\n";
                        
                        // Verify the change
                        $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
                        $stmt->execute([$user_id]);
                        $updatedUser = $stmt->fetch(PDO::FETCH_ASSOC);
                        echo "Verified new status: " . ($updatedUser['is_active'] ? 'Active' : 'Inactive') . "\n";
                        
                        // Restore to active for next test
                        $stmt = $pdo->prepare("UPDATE users SET is_active = 1 WHERE id = ?");
                        $stmt->execute([$user_id]);
                        echo "User restored to Active status.\n";
                    } else {
                        echo "ERROR: Failed to update user status.\n";
                    }
                }
            }
        }
    } else {
        echo "No valid users found for testing.\n";
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage() . "\n";
}

echo "Deactivate button simulation completed.\n";
?>