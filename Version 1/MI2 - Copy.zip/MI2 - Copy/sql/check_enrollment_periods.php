<?php
require_once __DIR__ . '/../includes/db.php';

try {
    $stmt = $pdo->query("SELECT * FROM enrollment_periods ORDER BY school_year");
    $periods = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Current Enrollment Periods:\n";
    echo "========================\n";
    foreach ($periods as $period) {
        echo "ID: " . $period['id'] . "\n";
        echo "School Year: " . $period['school_year'] . "\n";
        echo "Start Date: " . $period['start_date'] . "\n";
        echo "End Date: " . $period['end_date'] . "\n";
        echo "Active: " . ($period['is_active'] ? 'Yes' : 'No') . "\n";
        echo "Created: " . $period['created_at'] . "\n";
        echo "------------------------\n";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>