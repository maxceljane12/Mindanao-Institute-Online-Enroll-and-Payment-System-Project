<?php
require_once __DIR__ . '/../includes/db.php';

echo "Testing user activation/deactivation button behavior...\n";

try {
    // Get a test user
    $stmt = $pdo->query("SELECT id, username, is_active FROM users WHERE role != 'admin' LIMIT 1");
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "Test user: " . $user['username'] . " (ID: " . $user['id'] . ")\n";
        echo "Current status: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
        
        // Show what button would be displayed
        if ($user['is_active']) {
            echo "Button would show: Deactivate\n";
        } else {
            echo "Button would show: Activate\n";
        }
        
        // Toggle the status
        $newStatus = $user['is_active'] ? 0 : 1;
        $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
        $stmt->execute([$newStatus, $user['id']]);
        
        echo "Status toggled to: " . ($newStatus ? 'Active' : 'Inactive') . "\n";
        
        // Show what button would be displayed after toggle
        if ($newStatus) {
            echo "Button would now show: Deactivate\n";
        } else {
            echo "Button would now show: Activate\n";
        }
        
        // Toggle back to original status
        $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
        $stmt->execute([$user['is_active'], $user['id']]);
        
        echo "Status restored to original: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
    } else {
        echo "No non-admin users found in database.\n";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "Test completed.\n";
?>