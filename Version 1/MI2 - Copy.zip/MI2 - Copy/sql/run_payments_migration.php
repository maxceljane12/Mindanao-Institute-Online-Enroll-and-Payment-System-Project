<?php
// Script to run all payments-related migrations
// This script should be run once to set up the payments table and migrate existing data

require_once __DIR__ . '/../includes/db.php';

echo "Starting payments migration...\n";

try {
    // First, check if the receipt_path column exists in bills table
    echo "Checking if receipt_path column exists in bills table...\n";
    $columnExists = false;
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `bills` LIKE 'receipt_path'");
        $stmt->execute();
        $columnExists = $stmt->rowCount() > 0;
    } catch (Exception $e) {
        // Column doesn't exist or other error
        $columnExists = false;
    }
    
    if (!$columnExists) {
        echo "Adding receipt_path column to bills table...\n";
        $addReceiptPathSQL = file_get_contents(__DIR__ . '/add_receipt_path_to_bills.sql');
        $pdo->exec($addReceiptPathSQL);
        echo "✓ receipt_path column added to bills table\n";
    } else {
        echo "✓ receipt_path column already exists in bills table\n";
    }
    
    // Read and execute the create payments table script
    $createTableSQL = file_get_contents(__DIR__ . '/create_payments_table.sql');
    $pdo->exec($createTableSQL);
    echo "✓ Payments table created successfully\n";
    
    // Read and execute the migrate bills to payments script
    $migrateSQL = file_get_contents(__DIR__ . '/migrate_bills_to_payments.sql');
    $pdo->exec($migrateSQL);
    echo "✓ Existing bills data migrated to payments table\n";
    
    echo "All migrations completed successfully!\n";
    echo "The financial reports should now work correctly.\n";
    
} catch (PDOException $e) {
    echo "Error during migration: " . $e->getMessage() . "\n";
    exit(1);
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>