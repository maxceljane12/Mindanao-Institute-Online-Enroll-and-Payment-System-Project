<#
Run migrations for the MI2 project.

This script will:
 - Back up `enrollments` table if it exists
 - Create `enrollments` table from `create_enrollments_table.sql` if missing
 - Run `ensure_enrollments_columns.sql` (idempotent)
 - Run `add_enrollment_number_if_missing.sql` (idempotent)

Defaults assume XAMPP on Windows and a database named `mi` with user `root` and no password.
You can override parameters when running the script.

Examples:
  # Run with defaults
  .\run_migrations.ps1

  # Provide MySQL credentials and alternate path
  .\run_migrations.ps1 -DbUser 'root' -DbPass '' -SqlDir 'C:\xampp\htdocs\MI2\sql'
#>

param(
  [string]$MySqlExe = 'C:\xampp\mysql\bin\mysql.exe',
  [string]$MySqlDumpExe = 'C:\xampp\mysql\bin\mysqldump.exe',
  [string]$SqlDir = (Join-Path $PSScriptRoot ''),
  [string]$DbUser = 'root',
  [string]$DbPass = '',
  [string]$DbName = 'mi'
)

function Exec-MySqlFile {
  param($filePath)
  $mysqlArgs = @("-u", $DbUser)
  if (-not [string]::IsNullOrEmpty($DbPass)) {
    $mysqlArgs += "-p$DbPass"
  }
  $mysqlArgs += $DbName

  Get-Content $filePath | & $MySqlExe @mysqlArgs
}

try {
  Write-Output "Using SQL directory: $SqlDir"

  # Check if enrollments table exists
  $existsQuery = "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA='$DbName' AND TABLE_NAME='enrollments';"
            $mysqlExistsArgs = @("-u", $DbUser)
            if (-not [string]::IsNullOrEmpty($DbPass)) {
              $mysqlExistsArgs += "-p$DbPass"
            }
            $mysqlExistsArgs += @("-N", "-B", "-e", $existsQuery)
            $exists = & $MySqlExe @mysqlExistsArgs
  if ($exists -eq '1') {
    Write-Output 'enrollments table found — creating backup before migration.'
    $timestamp = (Get-Date -Format 'yyyyMMdd_HHmmss')
    $backupPath = Join-Path $SqlDir "enrollments_backup_${timestamp}.sql"
              $mysqldumpArgs = @("-u", $DbUser)
              if (-not [string]::IsNullOrEmpty($DbPass)) {
                $mysqldumpArgs += "-p$DbPass"
              }
              $mysqldumpArgs += @($DbName, "enrollments")
              & $MySqlDumpExe @mysqldumpArgs | Out-File -FilePath $backupPath -Encoding UTF8
    Write-Output "Backup written to: $backupPath"
  } else {
    Write-Output 'enrollments table not found — will create it from create_enrollments_table.sql'
    $createFile = Join-Path $SqlDir 'create_enrollments_table.sql'
    if (-Not (Test-Path $createFile)) {
      throw "Missing create script: $createFile"
    }
    Exec-MySqlFile $createFile
    Write-Output 'Created enrollments table.'
  }

  # Create bills table
  Write-Output 'Creating bills table from create_bills_table.sql'
  $createBillsFile = Join-Path $SqlDir 'create_bills_table.sql'
  if (-Not (Test-Path $createBillsFile)) {
    throw "Missing create script: $createBillsFile"
  }
  Exec-MySqlFile $createBillsFile
  Write-Output 'Created bills table.'

  # Create enrollment_fees table
  Write-Output 'Creating enrollment_fees table from create_enrollment_fees_table.sql'
  $createEnrollmentFeesFile = Join-Path $SqlDir 'create_enrollment_fees_table.sql'
  if (-Not (Test-Path $createEnrollmentFeesFile)) {
    throw "Missing create script: $createEnrollmentFeesFile"
  }
  Exec-MySqlFile $createEnrollmentFeesFile
  Write-Output 'Created enrollment_fees table.'

  # Run ensure columns script (idempotent)
  $ensureFile = Join-Path $SqlDir 'ensure_enrollments_columns.sql'
  if (Test-Path $ensureFile) {
    Write-Output "Running: $ensureFile"
    Exec-MySqlFile $ensureFile
  } else {
    Write-Output "ensure script not found: $ensureFile (skipping)"
  }

  # Run enrollment_number add script (idempotent)
  $addEnNumberFile = Join-Path $SqlDir 'add_enrollment_number_if_missing.sql'
  if (Test-Path $addEnNumberFile) {
    Write-Output "Running: $addEnNumberFile"
    Exec-MySqlFile $addEnNumberFile
  } else {
    Write-Output "add_enrollment_number script not found: $addEnNumberFile (skipping)"
  }

  # Run add cancelled status to enrollments script
  $addCancelledStatusFile = Join-Path $SqlDir 'add_cancelled_status_to_enrollments.sql'
  if (Test-Path $addCancelledStatusFile) {
    Write-Output "Running: $addCancelledStatusFile"
    Exec-MySqlFile $addCancelledStatusFile
  } else {
    Write-Output "add_cancelled_status script not found: $addCancelledStatusFile (skipping)"
  }

  # Run update enrollment status for paid bills script
  $updateEnrollmentStatusFile = Join-Path $SqlDir 'update_enrollment_status_for_paid_bills.sql'
  if (Test-Path $updateEnrollmentStatusFile) {
    Write-Output "Running: $updateEnrollmentStatusFile"
    Exec-MySqlFile $updateEnrollmentStatusFile
  } else {
    Write-Output "update_enrollment_status script not found: $updateEnrollmentStatusFile (skipping)"
  }

  # Run add pending_verification status to bills script
  $addPendingVerificationStatusFile = Join-Path $SqlDir 'add_pending_verification_status_to_bills.sql'
  if (Test-Path $addPendingVerificationStatusFile) {
    Write-Output "Running: $addPendingVerificationStatusFile"
    Exec-MySqlFile $addPendingVerificationStatusFile
  } else {
    Write-Output "add_pending_verification_status script not found: $addPendingVerificationStatusFile (skipping)"
  }

  # Run create enrollment_periods table script
  $createEnrollmentPeriodsFile = Join-Path $SqlDir 'create_enrollment_periods_table.sql'
  if (Test-Path $createEnrollmentPeriodsFile) {
    Write-Output "Running: $createEnrollmentPeriodsFile"
    Exec-MySqlFile $createEnrollmentPeriodsFile
  } else {
    Write-Output "create_enrollment_periods_table script not found: $createEnrollmentPeriodsFile (skipping)"
  }

  Write-Output "All migrations completed."
}
catch {
  Write-Error "Migration failed: $_"
  exit 1
}
