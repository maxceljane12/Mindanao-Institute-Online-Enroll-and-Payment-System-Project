<?php
require_once __DIR__ . '/../includes/db.php';

echo "Checking users table structure...\n";

try {
    // Check if is_active column exists
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'is_active'");
    $column = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($column) {
        echo "SUCCESS: is_active column exists in users table\n";
        echo "Column details:\n";
        echo "- Field: " . $column['Field'] . "\n";
        echo "- Type: " . $column['Type'] . "\n";
        echo "- Null: " . $column['Null'] . "\n";
        echo "- Key: " . $column['Key'] . "\n";
        echo "- Default: " . $column['Default'] . "\n";
        echo "- Extra: " . $column['Extra'] . "\n";
    } else {
        echo "ERROR: is_active column does not exist in users table\n";
        
        // Try to add the column
        echo "Attempting to add is_active column...\n";
        $pdo->exec("ALTER TABLE users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER role");
        echo "SUCCESS: is_active column added to users table\n";
    }
    
    // Check a few sample users to see their is_active status
    echo "\nChecking sample users' is_active status:\n";
    $stmt = $pdo->query("SELECT id, username, is_active FROM users LIMIT 5");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($users as $user) {
        echo "- User: " . $user['username'] . " (ID: '" . $user['id'] . "') - Active: " . ($user['is_active'] ? 'Yes' : 'No') . "\n";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    
    // If column doesn't exist, try to add it
    if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
        echo "INFO: is_active column already exists\n";
    } else {
        echo "Attempting to add is_active column...\n";
        try {
            $pdo->exec("ALTER TABLE users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER role");
            echo "SUCCESS: is_active column added to users table\n";
        } catch (PDOException $addErr) {
            echo "Failed to add is_active column: " . $addErr->getMessage() . "\n";
        }
    }
}

echo "Database structure check completed.\n";
?>