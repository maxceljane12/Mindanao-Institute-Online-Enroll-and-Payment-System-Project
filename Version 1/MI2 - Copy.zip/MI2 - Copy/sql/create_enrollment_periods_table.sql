-- Create enrollment_periods table to track when enrollment is active
CREATE TABLE IF NOT EXISTS `enrollment_periods` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_year` VARCHAR(100) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 0,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_school_year` (`school_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert initial enrollment period for current school year
INSERT IGNORE INTO `enrollment_periods` (`school_year`, `is_active`, `start_date`, `end_date`) 
VALUES ('2025-2026', 1, '2025-06-01', '2025-12-31');