<?php
require_once __DIR__ . '/../includes/db.php';

try {
    // Test querying users with is_active column
    $stmt = $pdo->query("SELECT id, username, is_active FROM users LIMIT 5");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Users with active status:\n";
    foreach ($users as $user) {
        echo "ID: " . $user['id'] . ", Username: " . $user['username'] . ", Active: " . ($user['is_active'] ? 'Yes' : 'No') . "\n";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>