ALTER TABLE enrollments MODIFY COLUMN status ENUM('pending_payment', 'paid', 'enrolled') NOT NULL DEFAULT 'pending_payment';
