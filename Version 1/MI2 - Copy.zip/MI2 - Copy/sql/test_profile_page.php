<?php
// Test if profile.php can be included without errors
echo "Testing profile.php...\n";

// Start output buffering to capture any output
ob_start();

// Try to include the profile.php file
try {
    include __DIR__ . '/../profile.php';
    echo "SUCCESS: profile.php included without syntax errors\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

// Clean the output buffer
ob_end_clean();

echo "Test completed.\n";
?>