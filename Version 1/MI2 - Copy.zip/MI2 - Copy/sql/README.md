# MI2 Database Schema

This directory contains all the SQL scripts needed to set up the database schema for the MI2 Student Management System.

## Complete Schema

The main schema is in [complete_schema.sql](file:///c%3A/xampp/htdocs/MI2/sql/complete_schema.sql) which creates all tables in the correct order with proper foreign key relationships.

## Tables Created

1. **users** - Stores all user accounts (students, parents, admin, etc.)
2. **applications** - Stores new student applications
3. **enrollments** - Stores enrollment form submissions
4. **bills** - Stores billing information for enrollments
5. **enrollment_fees** - Stores fee structures
6. **enrollment_periods** - Tracks when enrollment is active
7. **user_id_counter** - Tracks user ID counters per year

## Verification

The schema has been verified and all foreign key constraints are properly set up.

## Indexes

Appropriate indexes have been added for better query performance.