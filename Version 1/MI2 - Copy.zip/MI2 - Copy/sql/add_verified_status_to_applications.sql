-- Add 'verified' status to applications table
-- This allows admission to first approve, then verify before parents can enroll

ALTER TABLE `applications` 
MODIFY COLUMN `status` ENUM('pending','approved','verified','rejected') NOT NULL DEFAULT 'pending';

-- Note: After running this migration:
-- Workflow will be: pending → approved (by Admission) → verified (by Admission) → ready for enrollment
-- Parents can only proceed to enrollment form when status is 'verified'
