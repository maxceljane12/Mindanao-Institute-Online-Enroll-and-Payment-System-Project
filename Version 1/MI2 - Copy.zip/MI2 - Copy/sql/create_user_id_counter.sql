-- Create table to store per-year counter for user IDs
CREATE TABLE IF NOT EXISTS `user_id_counter` (
  `year` INT NOT NULL PRIMARY KEY,
  `counter` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert an initial row for the current year if it doesn't exist
INSERT INTO `user_id_counter` (`year`, `counter`)
SELECT YEAR(CURDATE()), 0
WHERE NOT EXISTS (SELECT 1 FROM `user_id_counter` WHERE `year` = YEAR(CURDATE()));
