-- Add 'pending_verification' status to bills table
-- This is needed for GCash payments that require cashier verification

ALTER TABLE `bills` MODIFY `status` ENUM('pending','paid','overdue','cancelled','pending_verification') NOT NULL DEFAULT 'pending';