<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

echo "Testing user activation/deactivation functionality...\n";

try {
    // Get a test user who is not an admin
    $stmt = $pdo->query("SELECT id, username, is_active FROM users WHERE role != 'admin' LIMIT 1");
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "Test user: " . $user['username'] . " (ID: " . $user['id'] . ")\n";
        echo "Current status: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
        
        // Toggle the status
        $newStatus = $user['is_active'] ? 0 : 1;
        $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
        $stmt->execute([$newStatus, $user['id']]);
        
        echo "Status toggled to: " . ($newStatus ? 'Active' : 'Inactive') . "\n";
        
        // Verify the change
        $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
        $stmt->execute([$user['id']]);
        $updatedUser = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "Verified status: " . ($updatedUser['is_active'] ? 'Active' : 'Inactive') . "\n";
        
        // Toggle back to original status
        $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
        $stmt->execute([$user['is_active'], $user['id']]);
        
        echo "Status restored to original: " . ($user['is_active'] ? 'Active' : 'Inactive') . "\n";
    } else {
        echo "No non-admin users found in database.\n";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "Test completed.\n";
?>