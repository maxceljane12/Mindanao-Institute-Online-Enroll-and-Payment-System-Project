<?php
require_once __DIR__ . '/../includes/db.php';

try {
    $sql = "ALTER TABLE users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER role";
    $pdo->exec($sql);
    echo "Column 'is_active' added successfully to users table.\n";
} catch (PDOException $e) {
    if ($e->getCode() == "42S21") {
        echo "Column 'is_active' already exists in users table.\n";
    } else {
        echo "Error adding column: " . $e->getMessage() . "\n";
    }
}
?>