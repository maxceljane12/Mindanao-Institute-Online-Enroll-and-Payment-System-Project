<?php
require_once __DIR__ . '/../includes/db.php';

echo "Checking users in database...\n";

try {
    $stmt = $pdo->query("SELECT id, username, role, is_active FROM users ORDER BY created_at DESC");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($users)) {
        echo "No users found in database.\n";
    } else {
        echo "Found " . count($users) . " users:\n";
        foreach ($users as $user) {
            echo "- ID: '" . $user['id'] . "' | Username: " . $user['username'] . " | Role: " . $user['role'] . " | Active: " . ($user['is_active'] ? 'Yes' : 'No') . "\n";
        }
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "Database check completed.\n";
?>