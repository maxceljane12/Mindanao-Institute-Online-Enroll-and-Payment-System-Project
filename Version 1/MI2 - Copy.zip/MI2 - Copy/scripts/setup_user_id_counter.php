<?php
// Run this script from CLI: php scripts/setup_user_id_counter.php
// Or open in browser: http://localhost/MI2/scripts/setup_user_id_counter.php

// Include DB connection
require_once __DIR__ . '/../includes/db.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS `user_id_counter` (
      `year` INT NOT NULL PRIMARY KEY,
      `counter` INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    if ($conn->query($sql) === TRUE) {
        echo "Table `user_id_counter` created or already exists.\n";
    } else {
        throw new Exception("Error creating table: " . $conn->error);
    }

    // Insert initial row for current year if missing
    $year = date('Y');
    $stmt = $conn->prepare("SELECT counter FROM user_id_counter WHERE `year` = ?");
    $stmt->bind_param('i', $year);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 0) {
        $ins = $conn->prepare("INSERT INTO user_id_counter (`year`, `counter`) VALUES (?, 0)");
        $ins->bind_param('i', $year);
        if ($ins->execute()) {
            echo "Inserted initial row for year {$year} with counter=0.\n";
        } else {
            throw new Exception("Insert failed: " . $conn->error);
        }
    } else {
        echo "Row for year {$year} already exists.\n";
    }

    echo "Done. You can now reload registration page.\n";
} catch (Exception $e) {
    echo "Setup error: " . $e->getMessage() . "\n";
}

?>
