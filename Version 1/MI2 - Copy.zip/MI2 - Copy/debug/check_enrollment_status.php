<?php
// Path: debug/check_enrollment_status.php

ini_set('display_errors', 1);
error_reporting(E_ALL);

include_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php'; // Include the database connection

echo "<h1>Debug: Checking for Students Ready for Enrollment</h1>";

$students_to_enroll = [];
$error_message = '';

try {
    $sql = "
        SELECT
            e.id as enrollment_id,
            e.first_name,
            e.last_name,
            e.enrollment_number,
            e.status as enrollment_status,
            b.bill_id,
            b.amount,
            b.status as bill_status
        FROM
            bills b
        JOIN
            enrollments e ON b.enrollment_id = e.id
        WHERE
            b.status = 'paid' AND e.status = 'paid'
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $students_to_enroll = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error_message = "Database error: Could not fetch students. " . $e->getMessage();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Debug: Enrollment Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">

        <?php if ($error_message): ?>
            <div class="alert alert-danger" role="alert">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <h2>Query Executed:</h2>
        <pre><?= htmlspecialchars($sql) ?></pre>

        <h2>Results:</h2>
        <p>Found <strong><?= count($students_to_enroll) ?></strong> student(s) ready for enrollment.</p>

        <?php if (empty($students_to_enroll)): ?>
            <p>This means there are no students in the database who have a bill with status 'paid' AND an enrollment status of 'paid'.</p>
            <p>For a student to appear on the registrar dashboard, please ensure that:</p>
            <ol>
                <li>A student has completed the enrollment form (creating an entry in the `enrollments` table with `status` = 'pending_payment').</li>
                <li>The student has paid their enrollment fee (creating an entry in the `bills` table with `status` = 'paid').</li>
                <li>The cashier has verified the payment, updating the enrollment status to 'paid'.</li>
                <li>When both conditions are met (bill status = 'paid' AND enrollment status = 'paid'), the student will appear in the registrar dashboard ready to be officially enrolled.</li>
                <li>After the registrar enrolls the student, the enrollment status will change to 'enrolled' and will appear in the enrolled students list.</li>
            </ol>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Enrollment ID</th>
                            <th>Student Name</th>
                            <th>Enrollment Number</th>
                            <th>Enrollment Status</th>
                            <th>Bill ID</th>
                            <th>Amount Paid</th>
                            <th>Bill Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students_to_enroll as $student): ?>
                            <tr>
                                <td><?= htmlspecialchars($student['enrollment_id']) ?></td>
                                <td><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></td>
                                <td><?= htmlspecialchars($student['enrollment_number'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($student['enrollment_status']) ?></td>
                                <td><?= htmlspecialchars($student['bill_id']) ?></td>
                                <td>₱<?= htmlspecialchars(number_format($student['amount'], 2)) ?></td>
                                <td><?= htmlspecialchars($student['bill_status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
