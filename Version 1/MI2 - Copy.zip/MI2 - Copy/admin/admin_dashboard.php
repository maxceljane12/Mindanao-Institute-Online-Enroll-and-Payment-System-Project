<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Only admin role allowed
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// Check if user is still active
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !$user['is_active']) {
        // User is deactivated, log them out
        session_destroy();
        header('Location: ../index.php?error=account_deactivated');
        exit;
    }
}

// Fetch dashboard statistics
try {
    // Total users
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    $totalUsers = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    // Total applications
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM applications");
    $totalApplications = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    // Pending applications
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM applications WHERE status = 'pending'");
    $stmt->execute();
    $pendingApps = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    // Total enrollments
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM enrollments");
    $totalEnrollments = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
} catch (PDOException $e) {
    error_log("Dashboard stats error: " . $e->getMessage());
    $totalUsers = 0;
    $totalApplications = 0;
    $pendingApps = 0;
    $totalEnrollments = 0;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mindanao Institute — Enrollment and Payment Management System</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1>Admin Dashboard</h1>
            </div>
            
            <div style="margin-bottom: 30px;">
                <h2>Welcome to the Admin Area</h2>
                <p>As an administrator, you can manage the entire system including users, enrollment periods, and system settings.</p>
            </div>
            
            <div style="margin-bottom: 30px;">
                <h2>Quick Statistics</h2>
                <div style="display: flex; gap: 10px;">
                    <div style="flex: 1; background-color: #007bff; color: white; padding: 20px; text-align: center;">
                        <h3><?php echo $totalUsers; ?></h3>
                        <p>Total Users</p>
                    </div>
                    <div style="flex: 1; background-color: #28a745; color: white; padding: 20px; text-align: center;">
                        <h3><?php echo $totalApplications; ?></h3>
                        <p>Total Applications</p>
                    </div>
                    <div style="flex: 1; background-color: #ffc107; color: white; padding: 20px; text-align: center;">
                        <h3><?php echo $pendingApps; ?></h3>
                        <p>Pending Applications</p>
                    </div>
                    <div style="flex: 1; background-color: #17a2b8; color: white; padding: 20px; text-align: center;">
                        <h3><?php echo $totalEnrollments; ?></h3>
                        <p>Total Enrollments</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>