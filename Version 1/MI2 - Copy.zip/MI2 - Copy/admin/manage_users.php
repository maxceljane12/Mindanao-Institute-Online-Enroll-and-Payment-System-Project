<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Only admin role allowed
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log("POST data received: " . print_r($_POST, true)); // Debug log
    
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        try {
            if ($action === 'add') {
                // Add new user
                $username = trim($_POST['username'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $password = $_POST['password'] ?? '';
                $role = $_POST['role'] ?? '';
                $first_name = trim($_POST['first_name'] ?? '');
                $last_name = trim($_POST['last_name'] ?? '');
                
                // Validate inputs
                if (empty($username) || empty($email) || empty($password) || empty($role) || empty($first_name) || empty($last_name)) {
                    $error = 'All fields are required.';
                } elseif (strlen($password) < 6) {
                    $error = 'Password must be at least 6 characters long.';
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error = 'Invalid email format.';
                } else {
                    // Check if username or email already exists
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
                    $stmt->execute([$username, $email]);
                    if ($stmt->fetch()) {
                        $error = 'Username or email already exists.';
                    } else {
                        // Hash password
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        
                        // Insert new user
                        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, first_name, last_name) VALUES (?, ?, ?, ?, ?, ?)");
                        if ($stmt->execute([$username, $email, $hashed_password, $role, $first_name, $last_name])) {
                            $message = 'User added successfully.';
                        } else {
                            $error = 'Failed to add user. Please try again.';
                        }
                    }
                }
            } elseif ($action === 'update') {
                // Update user
                $user_id = (int)($_POST['user_id'] ?? 0);
                $email = trim($_POST['email'] ?? '');
                $role = $_POST['role'] ?? '';
                $first_name = trim($_POST['first_name'] ?? '');
                $last_name = trim($_POST['last_name'] ?? '');
                
                // Validate inputs
                if (empty($user_id) || empty($email) || empty($role) || empty($first_name) || empty($last_name)) {
                    $error = 'All fields are required.';
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error = 'Invalid email format.';
                } else {
                    // Check if email already exists for other users
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                    $stmt->execute([$email, $user_id]);
                    if ($stmt->fetch()) {
                        $error = 'Email already exists for another user.';
                    } else {
                        // Update user
                        $stmt = $pdo->prepare("UPDATE users SET email = ?, role = ?, first_name = ?, last_name = ? WHERE id = ?");
                        if ($stmt->execute([$email, $role, $first_name, $last_name, $user_id])) {
                            $message = 'User updated successfully.';
                        } else {
                            $error = 'Failed to update user. Please try again.';
                        }
                    }
                }
            } elseif ($action === 'delete') {
                // Delete user
                $user_id = (int)($_POST['user_id'] ?? 0);
                
                if ($user_id <= 0) {
                    $error = 'Invalid user ID.';
                } else {
                    // Prevent deleting oneself
                    if ($user_id == ($_SESSION['user_id'] ?? 0)) {
                        $error = 'You cannot delete your own account.';
                    } else {
                        // Check if user exists
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
                        $stmt->execute([$user_id]);
                        if (!$stmt->fetch()) {
                            $error = 'User not found.';
                        } else {
                            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                            if ($stmt->execute([$user_id])) {
                                $message = 'User deleted successfully.';
                            } else {
                                $error = 'Failed to delete user. Please try again.';
                            }
                        }
                    }
                }
            } elseif ($action === 'change_password') {
                // Change user password
                $user_id = (int)($_POST['user_id'] ?? 0);
                $new_password = $_POST['new_password'] ?? '';
                $confirm_password = $_POST['confirm_password'] ?? '';
                
                // Validate inputs
                if (empty($user_id)) {
                    $error = 'Invalid user ID.';
                } elseif (empty($new_password) || empty($confirm_password)) {
                    $error = 'All password fields are required.';
                } elseif (strlen($new_password) < 6) {
                    $error = 'Password must be at least 6 characters long.';
                } elseif ($new_password !== $confirm_password) {
                    $error = 'Passwords do not match.';
                } else {
                    // Check if user exists
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    if (!$stmt->fetch()) {
                        $error = 'User not found.';
                    } else {
                        // Hash new password
                        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                        
                        // Update password
                        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                        if ($stmt->execute([$hashed_password, $user_id])) {
                            $message = 'Password changed successfully.';
                        } else {
                            $error = 'Failed to change password. Please try again.';
                        }
                    }
                }
            } elseif ($action === 'toggle_active') {
                // Toggle user active status
                $user_id = trim($_POST['user_id'] ?? ''); // Keep as string to handle empty values
                $is_active = (int)($_POST['is_active'] ?? 0);
                
                error_log("Toggle active - User ID: '$user_id', Is Active: $is_active"); // Debug log
                
                if (empty($user_id)) {
                    $error = 'Invalid user ID.';
                } else {
                    // Prevent toggling oneself
                    if ($user_id == ($_SESSION['user_id'] ?? '')) {
                        $error = 'You cannot change your own account status.';
                    } else {
                        // Check if user exists
                        $stmt = $pdo->prepare("SELECT id, username FROM users WHERE id = ?");
                        $stmt->execute([$user_id]);
                        $user = $stmt->fetch();
                        
                        if (!$user) {
                            $error = 'User not found.';
                        } else {
                            $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
                            if ($stmt->execute([$is_active, $user_id])) {
                                $message = $is_active ? 'User activated successfully.' : 'User deactivated successfully.';
                                error_log("User {$user['username']} status changed to: " . ($is_active ? 'active' : 'inactive')); // Debug log
                            } else {
                                $error = 'Failed to update user status. Please try again.';
                            }
                        }
                    }
                }
            } else {
                $error = 'Invalid action.';
            }
        } catch (PDOException $e) {
            error_log("User management error: " . $e->getMessage());
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = 'No action specified.';
    }
    
    // Refresh the page to show updated status
    if ($message || $error) {
        // Store message/error in session to persist after redirect
        if ($message) {
            $_SESSION['manage_users_message'] = $message;
        }
        if ($error) {
            $_SESSION['manage_users_error'] = $error;
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

// Check for message/error from redirect
if (isset($_SESSION['manage_users_message'])) {
    $message = $_SESSION['manage_users_message'];
    unset($_SESSION['manage_users_message']); // Clear the message
}
if (isset($_SESSION['manage_users_error'])) {
    $error = $_SESSION['manage_users_error'];
    unset($_SESSION['manage_users_error']); // Clear the error
}

// Fetch all users
try {
    $stmt = $pdo->query("SELECT id, username, email, role, first_name, last_name, created_at, is_active FROM users ORDER BY created_at DESC");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching users: " . $e->getMessage());
    $users = [];
    $error = "Database error: " . $e->getMessage();
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manage Users - Mindanao Institute</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Users</h1>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="my-0">Add New User</h5>
                </div>
                <div class="card-body">
                    <form method="post" id="addUserForm">
                        <input type="hidden" name="action" value="add">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Username *</label>
                                <input type="text" name="username" class="form-control" required 
                                       pattern="[a-zA-Z0-9_]+" title="Only letters, numbers, and underscores allowed">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email *</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Password *</label>
                                <input type="password" name="password" class="form-control" required minlength="6">
                                <div class="form-text">Minimum 6 characters</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Role *</label>
                                <select name="role" class="form-select" required>
                                    <option value="">Select Role</option>
                                    <option value="student">Student</option>
                                    <option value="parent">Parent</option>
                                    <option value="admission">Admission Officer</option>
                                    <option value="cashier">Cashier</option>
                                    <option value="registrar">Registrar</option>
                                    <option value="admin">Administrator</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">First Name *</label>
                                <input type="text" name="first_name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Last Name *</label>
                                <input type="text" name="last_name" class="form-control" required>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">Add User</button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="my-0">Existing Users</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($users)): ?>
                        <div class="alert alert-info">No users found.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover table-striped">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td><?= $user['id'] ?></td>
                                            <td><?= htmlspecialchars($user['username']) ?></td>
                                            <td><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></td>
                                            <td><?= htmlspecialchars($user['email']) ?></td>
                                            <td>
                                                <span class="badge bg-secondary"><?= ucfirst(htmlspecialchars($user['role'])) ?></span>
                                            </td>
                                            <td>
                                                <?php if ($user['is_active']): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= htmlspecialchars(date('M j, Y', strtotime($user['created_at']))) ?></td>
                                            <td>
                                                <div class="btn-group btn-group-sm" role="group">
                                                    <button class="btn btn-outline-info edit-user-btn" 
                                                            data-user='<?= htmlspecialchars(json_encode($user)) ?>'
                                                            title="Edit User">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    
                                                    <!-- Activate/Deactivate Button -->
                                                    <?php if (!empty($user['id'])): // Only show toggle button if user has a valid ID ?>
                                                        <?php if ($user['is_active']): ?>
                                                            <form method="post" class="d-inline" 
                                                                  onsubmit="return confirm('Are you sure you want to deactivate user <?= htmlspecialchars($user['username']) ?>?');">
                                                                <input type="hidden" name="action" value="toggle_active">
                                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                                <input type="hidden" name="is_active" value="0">
                                                                <button type="submit" class="btn btn-outline-warning" 
                                                                        <?= $user['id'] == ($_SESSION['user_id'] ?? 0) ? 'disabled title="Cannot deactivate your own account"' : 'title="Deactivate User"' ?>>
                                                                    <i class="fas fa-user-slash"></i>
                                                                </button>
                                                            </form>
                                                        <?php else: ?>
                                                            <form method="post" class="d-inline" 
                                                                  onsubmit="return confirm('Are you sure you want to activate user <?= htmlspecialchars($user['username']) ?>?');">
                                                                <input type="hidden" name="action" value="toggle_active">
                                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                                <input type="hidden" name="is_active" value="1">
                                                                <button type="submit" class="btn btn-outline-success" title="Activate User">
                                                                    <i class="fas fa-user-check"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <button class="btn btn-outline-secondary" title="Cannot manage user without valid ID" disabled>
                                                            <i class="fas fa-exclamation-triangle"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                    
                                                    <button class="btn btn-outline-warning change-password-btn" 
                                                            data-user-id="<?= $user['id'] ?>"
                                                            data-user-name="<?= htmlspecialchars($user['username']) ?>"
                                                            title="Change Password" <?= empty($user['id']) ? 'disabled' : '' ?>>
                                                        <i class="fas fa-key"></i>
                                                    </button>
                                                    
                                                    <form method="post" class="d-inline" 
                                                          onsubmit="return confirm('Are you sure you want to delete user <?= htmlspecialchars($user['username']) ?>? This action cannot be undone.');">
                                                        <input type="hidden" name="action" value="delete">
                                                        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                        <button type="submit" class="btn btn-outline-danger" 
                                                                <?= empty($user['id']) || $user['id'] == ($_SESSION['user_id'] ?? 0) ? 'disabled title="Cannot delete your own account or users without valid ID"' : 'title="Delete User"' ?>>
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="editUserForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="user_id" id="edit-user-id">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" id="edit-username" class="form-control" disabled>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" id="edit-email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role *</label>
                        <select name="role" id="edit-role" class="form-select" required>
                            <option value="student">Student</option>
                            <option value="parent">Parent</option>
                            <option value="admission">Admission Officer</option>
                            <option value="cashier">Cashier</option>
                            <option value="registrar">Registrar</option>
                            <option value="admin">Administrator</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">First Name *</label>
                        <input type="text" name="first_name" id="edit-first-name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Last Name *</label>
                        <input type="text" name="last_name" id="edit-last-name" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="changePasswordForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="changePasswordModalLabel">Change Password for <span id="password-user-name"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="change_password">
                    <input type="hidden" name="user_id" id="password-user-id">
                    <div class="mb-3">
                        <label class="form-label">New Password *</label>
                        <input type="password" name="new_password" class="form-control" required minlength="6">
                        <div class="form-text">Minimum 6 characters</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Confirm Password *</label>
                        <input type="password" name="confirm_password" class="form-control" required minlength="6">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Change Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('Document loaded - initializing user management...');
    
    // Edit user modal
    const editButtons = document.querySelectorAll('.edit-user-btn');
    const editModal = new bootstrap.Modal(document.getElementById('editUserModal'));
    
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const user = JSON.parse(this.dataset.user);
            console.log('Editing user:', user);
            
            document.getElementById('edit-user-id').value = user.id;
            document.getElementById('edit-username').value = user.username;
            document.getElementById('edit-email').value = user.email;
            document.getElementById('edit-role').value = user.role;
            document.getElementById('edit-first-name').value = user.first_name;
            document.getElementById('edit-last-name').value = user.last_name;
            
            editModal.show();
        });
    });
    
    // Change password modal
    const passwordButtons = document.querySelectorAll('.change-password-btn');
    const passwordModal = new bootstrap.Modal(document.getElementById('changePasswordModal'));
    
    passwordButtons.forEach(button => {
        button.addEventListener('click', function() {
            const userId = this.dataset.userId;
            const userName = this.dataset.userName;
            console.log('Changing password for user:', userName, 'ID:', userId);
            
            document.getElementById('password-user-id').value = userId;
            document.getElementById('password-user-name').textContent = userName;
            
            // Clear previous password fields
            document.querySelector('#changePasswordForm input[name="new_password"]').value = '';
            document.querySelector('#changePasswordForm input[name="confirm_password"]').value = '';
            
            passwordModal.show();
        });
    });
    
    // Debug: Log form submissions
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            console.log('Form submitted:', this);
            console.log('Form action:', this.querySelector('input[name="action"]')?.value);
            console.log('Form data:', new FormData(this));
        });
    });
    
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            if (alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 5000);
    });
});
</script>
</body>
</html>