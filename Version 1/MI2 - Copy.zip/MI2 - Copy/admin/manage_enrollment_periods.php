<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
    header('Location: ../index.php');
    exit;
}
require_once __DIR__ . '/../includes/db.php';

// Fetch enrollment periods
try {
    $stmt = $pdo->query("SELECT * FROM enrollment_periods ORDER BY school_year DESC");
    $enrollmentPeriods = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching enrollment periods: " . $e->getMessage());
    $_SESSION['error_message'] = "Database error: Could not fetch enrollment periods.";
    $enrollmentPeriods = [];
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manage Enrollment Periods - Mindanao Institute</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Enrollment Periods</h1>
            </div>
            
            <p class="small-muted">As an administrator, you can manage enrollment periods for different school years. Only one period can be active at a time.</p>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success" role="alert">
                    <?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="my-0">Existing Enrollment Periods</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($enrollmentPeriods)): ?>
                        <p>No enrollment periods found.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>School Year</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($enrollmentPeriods as $period): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($period['school_year']) ?></td>
                                            <td><?= htmlspecialchars($period['start_date']) ?></td>
                                            <td><?= htmlspecialchars($period['end_date']) ?></td>
                                            <td>
                                                <?php if ($period['is_active']): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-info edit-period-btn" data-period='<?= json_encode($period) ?>'>Edit</button>
                                                <?php if (!$period['is_active']): ?>
                                                    <form action="../PHP/process_enrollment_period.php" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to activate this enrollment period?');">
                                                        <input type="hidden" name="action" value="toggle_active">
                                                        <input type="hidden" name="period_id" value="<?= $period['id'] ?>">
                                                        <button type="submit" class="btn btn-sm btn-success">Activate</button>
                                                    </form>
                                                    <form action="../PHP/process_enrollment_period.php" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this enrollment period?');">
                                                        <input type="hidden" name="action" value="delete">
                                                        <input type="hidden" name="period_id" value="<?= $period['id'] ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                                    </form>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-secondary" disabled>Active Period</button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="my-0">Add New Enrollment Period</h5>
                </div>
                <div class="card-body">
                    <form action="../PHP/process_enrollment_period.php" method="POST" class="needs-validation" novalidate>
                        <input type="hidden" name="action" value="add" id="period-action">
                        <input type="hidden" name="period_id" id="period-id">
                        
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="school-year" class="form-label">School Year *</label>
                                <input type="text" class="form-control" id="school-year" name="school_year" placeholder="e.g., 2025-2026" required>
                                <div class="invalid-feedback">
                                    Please provide the school year.
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <label for="start-date" class="form-label">Start Date *</label>
                                <input type="date" class="form-control" id="start-date" name="start_date" required>
                                <div class="invalid-feedback">
                                    Please provide a start date.
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <label for="end-date" class="form-label">End Date *</label>
                                <input type="date" class="form-control" id="end-date" name="end_date" required>
                                <div class="invalid-feedback">
                                    Please provide an end date.
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="is-active" name="is_active" value="1">
                                    <label class="form-check-label" for="is-active">
                                        Set as Active Period
                                    </label>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary" id="period-form-submit-btn">Add Period</button>
                                <button type="button" class="btn btn-secondary" id="cancel-edit-btn" style="display:none;">Cancel Edit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const editButtons = document.querySelectorAll('.edit-period-btn');
    const periodForm = document.querySelector('form');
    const periodIdInput = document.getElementById('period-id');
    const schoolYearInput = document.getElementById('school-year');
    const startDateInput = document.getElementById('start-date');
    const endDateInput = document.getElementById('end-date');
    const isActiveCheckbox = document.getElementById('is-active');
    const formActionInput = document.getElementById('period-action');
    const formSubmitBtn = document.getElementById('period-form-submit-btn');
    const cancelEditBtn = document.getElementById('cancel-edit-btn');

    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const period = JSON.parse(this.dataset.period);
            
            periodIdInput.value = period.id;
            schoolYearInput.value = period.school_year;
            startDateInput.value = period.start_date;
            endDateInput.value = period.end_date;
            isActiveCheckbox.checked = period.is_active == 1;

            formActionInput.value = 'update';
            formSubmitBtn.textContent = 'Update Period';
            cancelEditBtn.style.display = 'inline-block';

            // Scroll to the form
            periodForm.scrollIntoView({ behavior: 'smooth' });
        });
    });

    cancelEditBtn.addEventListener('click', function() {
        periodIdInput.value = '';
        schoolYearInput.value = '';
        startDateInput.value = '';
        endDateInput.value = '';
        isActiveCheckbox.checked = false;

        formActionInput.value = 'add';
        formSubmitBtn.textContent = 'Add Period';
        cancelEditBtn.style.display = 'none';

        periodForm.reset(); // Resets form validation state as well
    });

    // Bootstrap form validation
    (function () {
      'use strict'
      var forms = document.querySelectorAll('.needs-validation')
      Array.prototype.slice.call(forms)
        .forEach(function (form) {
          form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
            }
            form.classList.add('was-validated')
          }, false)
        })
    })()
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>