<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Only admin role allowed
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$message = '';
$error = '';

// Initialize filters
$filter_month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$filter_year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');

// Fetch financial statistics
try {
    // Total payments received
    $stmt = $pdo->prepare("SELECT COUNT(*) as count, SUM(amount) as total FROM payments WHERE DATE_FORMAT(payment_date, '%Y-%m') = ?");
    $stmt->execute([$filter_month]);
    $monthly_payments = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Total bills generated
    $stmt = $pdo->prepare("SELECT COUNT(*) as count, SUM(amount) as total FROM bills WHERE DATE_FORMAT(created_at, '%Y-%m') = ?");
    $stmt->execute([$filter_month]);
    $monthly_bills = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Pending bills
    $stmt = $pdo->prepare("SELECT COUNT(*) as count, SUM(amount) as total FROM bills WHERE status = 'pending' AND DATE_FORMAT(created_at, '%Y-%m') = ?");
    $stmt->execute([$filter_month]);
    $pending_bills = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Paid bills
    $stmt = $pdo->prepare("SELECT COUNT(*) as count, SUM(amount) as total FROM bills WHERE status = 'paid' AND DATE_FORMAT(created_at, '%Y-%m') = ?");
    $stmt->execute([$filter_month]);
    $paid_bills = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Recent payments for the month
    $stmt = $pdo->prepare("
        SELECT p.*, e.user_id, u.first_name, u.last_name 
        FROM payments p 
        JOIN bills b ON p.bill_id = b.bill_id 
        JOIN enrollments e ON b.enrollment_id = e.id
        JOIN users u ON e.user_id = u.id 
        WHERE DATE_FORMAT(p.payment_date, '%Y-%m') = ? 
        ORDER BY p.payment_date DESC 
        LIMIT 10
    ");
    $stmt->execute([$filter_month]);
    $recent_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Payment method breakdown
    $stmt = $pdo->prepare("
        SELECT payment_method, COUNT(*) as count, SUM(amount) as total 
        FROM payments 
        WHERE DATE_FORMAT(payment_date, '%Y-%m') = ? 
        GROUP BY payment_method
    ");
    $stmt->execute([$filter_month]);
    $payment_methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    error_log("Financial report error: " . $e->getMessage());
    $error = "Database error: " . $e->getMessage();
    $monthly_payments = ['count' => 0, 'total' => 0];
    $monthly_bills = ['count' => 0, 'total' => 0];
    $pending_bills = ['count' => 0, 'total' => 0];
    $paid_bills = ['count' => 0, 'total' => 0];
    $recent_payments = [];
    $payment_methods = [];
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Financial Reports - Mindanao Institute</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Financial Reports</h1>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <!-- Filter Form -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="my-0">Report Filters</h5>
                </div>
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Month</label>
                            <input type="month" name="month" class="form-control" value="<?= htmlspecialchars($filter_month) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Year</label>
                            <input type="number" name="year" class="form-control" min="2020" max="2030" value="<?= htmlspecialchars($filter_year) ?>">
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary">Filter Reports</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Summary Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-primary h-100">
                        <div class="card-body">
                            <h5 class="card-title">Payments Received</h5>
                            <h3><?= $monthly_payments['count'] ?? 0 ?></h3>
                            <p class="card-text">₱<?= number_format($monthly_payments['total'] ?? 0, 2) ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-success h-100">
                        <div class="card-body">
                            <h5 class="card-title">Bills Generated</h5>
                            <h3><?= $monthly_bills['count'] ?? 0 ?></h3>
                            <p class="card-text">₱<?= number_format($monthly_bills['total'] ?? 0, 2) ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-warning h-100">
                        <div class="card-body">
                            <h5 class="card-title">Pending Bills</h5>
                            <h3><?= $pending_bills['count'] ?? 0 ?></h3>
                            <p class="card-text">₱<?= number_format($pending_bills['total'] ?? 0, 2) ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-info h-100">
                        <div class="card-body">
                            <h5 class="card-title">Paid Bills</h5>
                            <h3><?= $paid_bills['count'] ?? 0 ?></h3>
                            <p class="card-text">₱<?= number_format($paid_bills['total'] ?? 0, 2) ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Payment Methods Breakdown -->
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="my-0">Payment Methods Breakdown</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($payment_methods)): ?>
                                <p>No payment data available for this period.</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Payment Method</th>
                                                <th>Number of Payments</th>
                                                <th>Total Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($payment_methods as $method): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $method['payment_method']))) ?></td>
                                                    <td><?= $method['count'] ?></td>
                                                    <td>₱<?= number_format($method['total'], 2) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Payments -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="my-0">Recent Payments (<?= date('F Y', strtotime($filter_month)) ?>)</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($recent_payments)): ?>
                                <p>No recent payments found for this period.</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Payment Date</th>
                                                <th>Student</th>
                                                <th>Amount</th>
                                                <th>Payment Method</th>
                                                <th>Reference</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($recent_payments as $payment): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars(date('M j, Y', strtotime($payment['payment_date']))) ?></td>
                                                    <td><?= htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']) ?></td>
                                                    <td>₱<?= number_format($payment['amount'], 2) ?></td>
                                                    <td><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $payment['payment_method']))) ?></td>
                                                    <td><?= htmlspecialchars($payment['reference_number']) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>