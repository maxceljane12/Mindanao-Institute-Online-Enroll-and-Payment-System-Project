<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Only admin role allowed
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// Check if user is still active
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !$user['is_active']) {
        // User is deactivated, log them out
        session_destroy();
        header('Location: ../index.php?error=account_deactivated');
        exit;
    }
}

$message = '';
$messageType = '';

// Handle form submission to update enrollment status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $enrollment_id = (int)$_POST['enrollment_id'];
    $new_status = $_POST['new_status'];
    
    try {
        $stmt = $pdo->prepare("UPDATE enrollments SET status = :status WHERE id = :id");
        $result = $stmt->execute([
            'status' => $new_status,
            'id' => $enrollment_id
        ]);
        
        if ($result) {
            $message = "Enrollment status updated successfully!";
            $messageType = "success";
        } else {
            $message = "Failed to update enrollment status.";
            $messageType = "danger";
        }
    } catch (PDOException $e) {
        $message = "Error updating enrollment status: " . $e->getMessage();
        $messageType = "danger";
    }
}

// Fetch all enrollments with user information
try {
    $stmt = $pdo->query("
        SELECT 
            e.id,
            e.enrollment_number,
            e.first_name,
            e.last_name,
            e.grade_level,
            e.status,
            e.created_at,
            u.username,
            u.first_name as user_first_name,
            u.last_name as user_last_name
        FROM enrollments e
        LEFT JOIN users u ON e.user_id = u.id
        ORDER BY e.created_at DESC
    ");
    $enrollments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "Error fetching enrollments: " . $e->getMessage();
    $messageType = "danger";
    $enrollments = [];
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manage Enrollment Statuses - Mindanao Institute</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Enrollment Statuses</h1>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="my-0">Enrollment Status Management</h5>
                </div>
                <div class="card-body">
                    <p>As an administrator, you can update the status of any enrollment record in the system.</p>
                    
                    <?php if (empty($enrollments)): ?>
                        <p>No enrollments found.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Enrollment #</th>
                                        <th>Student Name</th>
                                        <th>Grade Level</th>
                                        <th>User</th>
                                        <th>Current Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($enrollments as $enrollment): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($enrollment['enrollment_number'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($enrollment['first_name'] . ' ' . $enrollment['last_name']); ?></td>
                                            <td><?php echo htmlspecialchars($enrollment['grade_level'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars(($enrollment['user_first_name'] ?? '') . ' ' . ($enrollment['user_last_name'] ?? $enrollment['username'] ?? 'N/A')); ?></td>
                                            <td>
                                                <?php
                                                    $status = $enrollment['status'];
                                                    $statusClass = '';
                                                    switch ($status) {
                                                        case 'pending_payment':
                                                            $statusClass = 'badge bg-warning text-dark';
                                                            $statusText = 'Pending Payment';
                                                            break;
                                                        case 'paid':
                                                            $statusClass = 'badge bg-info';
                                                            $statusText = 'Payment Submitted';
                                                            break;
                                                        case 'enrolled':
                                                            $statusClass = 'badge bg-success';
                                                            $statusText = 'Officially Enrolled';
                                                            break;
                                                        case 'not_enrolled':
                                                            $statusClass = 'badge bg-secondary';
                                                            $statusText = 'Not Enrolled';
                                                            break;
                                                        case 'cancelled':
                                                            $statusClass = 'badge bg-danger';
                                                            $statusText = 'Cancelled';
                                                            break;
                                                        default:
                                                            $statusClass = 'badge bg-secondary';
                                                            $statusText = ucfirst(str_replace('_', ' ', $status));
                                                    }
                                                ?>
                                                <span class="<?php echo $statusClass; ?>"><?php echo htmlspecialchars($statusText); ?></span>
                                            </td>
                                            <td><?php echo htmlspecialchars(date('M j, Y', strtotime($enrollment['created_at']))); ?></td>
                                            <td>
                                                <form method="POST" action="" class="d-inline">
                                                    <input type="hidden" name="enrollment_id" value="<?php echo $enrollment['id']; ?>">
                                                    <select name="new_status" class="form-select form-select-sm d-inline-block w-auto">
                                                        <option value="pending_payment" <?php echo ($status === 'pending_payment') ? 'selected' : ''; ?>>Pending Payment</option>
                                                        <option value="paid" <?php echo ($status === 'paid') ? 'selected' : ''; ?>>Payment Submitted</option>
                                                        <option value="enrolled" <?php echo ($status === 'enrolled') ? 'selected' : ''; ?>>Officially Enrolled</option>
                                                        <option value="not_enrolled" <?php echo ($status === 'not_enrolled') ? 'selected' : ''; ?>>Not Enrolled</option>
                                                        <option value="cancelled" <?php echo ($status === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                                    </select>
                                                    <button type="submit" name="update_status" class="btn btn-sm btn-primary">Update</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>