<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Ensure user is logged in and is a student
if (!isset($_SESSION['user_id']) || strtolower($_SESSION['role']) !== 'student') {
    header('Location: ../index.php');
    exit;
}

// Check if user is still active
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !$user['is_active']) {
        // User is deactivated, log them out
        session_destroy();
        header('Location: ../index.php?error=account_deactivated');
        exit;
    }
}

$user_id = $_SESSION['user_id'];

// Fetch student's enrollments
try {
    $stmt = $pdo->prepare("SELECT * FROM enrollments WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $enrollments = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching enrollments: " . $e->getMessage());
    $enrollments = [];
}

// Fetch student's pending applications
try {
    $stmt = $pdo->prepare("SELECT * FROM applications WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $pendingApplications = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching pending applications: " . $e->getMessage());
    $pendingApplications = [];
}

// Check if enrollment is active
try {
    $stmt = $pdo->prepare("SELECT * FROM enrollment_periods WHERE is_active = 1 LIMIT 1");
    $stmt->execute();
    $enrollmentPeriod = $stmt->fetch();
    $enrollmentActive = !empty($enrollmentPeriod);
} catch (PDOException $e) {
    error_log("Error checking enrollment period: " . $e->getMessage());
    $enrollmentPeriod = null;
    $enrollmentActive = false;
}

$message = '';
if (!$enrollmentActive) {
    $message = 'Enrollment is currently not active.';
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mindanao Institute — Enrollment and Payment Management System</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Student Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <?php if ($enrollmentActive): ?>
                        <a href="/MI2/enroll_select.php" class="btn btn-sm btn-outline-primary">Enroll Now</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php if ($message): ?>
                <div class="alert alert-warning"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>
            
            <?php if (!$enrollmentActive): ?>
                <div class="alert alert-warning">
                    <strong>Enrollment is currently not active.</strong> 
                    <?php if ($enrollmentPeriod): ?>
                        Enrollment for <?= htmlspecialchars($enrollmentPeriod['school_year']) ?> will be active from 
                        <?= htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['start_date']))) ?> to 
                        <?= htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['end_date']))) ?>.
                    <?php else: ?>
                        Please contact administration for more information about enrollment periods.
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h5 class="my-0 fw-normal">Your Enrollments</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($enrollments)): ?>
                        <p class="text-muted">You haven't submitted any enrollments yet.</p>
                        <?php if ($enrollmentActive): ?>
                            <a href="/MI2/enroll_select.php" class="btn btn-sm btn-primary">Enroll Now</a>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Enrollment #</th>
                                        <th>Grade</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($enrollments as $enrollment): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($enrollment['enrollment_number']) ?></td>
                                            <td><?= htmlspecialchars($enrollment['grade_level']) ?></td>
                                            <td>
                                                <?php
                                                    $status = $enrollment['status'];
                                                    $statusClass = '';
                                                    switch ($status) {
                                                        case 'pending_payment':
                                                            $statusClass = 'badge bg-warning text-dark';
                                                            $statusText = 'Pending Payment';
                                                            break;
                                                        case 'paid':
                                                            $statusClass = 'badge bg-info';
                                                            $statusText = 'Payment Submitted';
                                                            break;
                                                        case 'enrolled':
                                                            $statusClass = 'badge bg-success';
                                                            $statusText = 'Officially Enrolled';
                                                            break;
                                                        case 'not_enrolled':
                                                            $statusClass = 'badge bg-secondary';
                                                            $statusText = 'Not Enrolled';
                                                            break;
                                                        case 'cancelled':
                                                            $statusClass = 'badge bg-danger';
                                                            $statusText = 'Cancelled';
                                                            break;
                                                        default:
                                                            $statusClass = 'badge bg-secondary';
                                                            $statusText = ucfirst(str_replace('_', ' ', $status));
                                                    }
                                                ?>
                                                <span class="<?= $statusClass ?>">
                                                    <?= htmlspecialchars($statusText) ?>
                                                </span>
                                            </td>
                                            <td><?= htmlspecialchars(date('M j, Y', strtotime($enrollment['created_at']))) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h5 class="my-0 fw-normal">Pending Applications</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($pendingApplications)): ?>
                        <p class="text-muted">You don't have any pending applications.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Application #</th>
                                        <th>Student Name</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pendingApplications as $application): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($application['id']) ?></td>
                                            <td><?= htmlspecialchars($application['first_name'] . ' ' . $application['last_name']) ?></td>
                                            <td>
                                                <span class="badge bg-warning">
                                                    <?= htmlspecialchars(ucfirst($application['status'])) ?>
                                                </span>
                                            </td>
                                            <td><?= htmlspecialchars(date('M j, Y', strtotime($application['created_at']))) ?></td>
                                            <td>
                                                <a href="/MI2/student/application_status.php?app_id=<?= $application['id'] ?>" class="btn btn-sm btn-outline-primary">Check Status</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
