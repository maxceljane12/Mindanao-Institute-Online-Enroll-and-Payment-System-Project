<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$userId = $_SESSION['user_id'] ?? null;
$appId = isset($_GET['app_id']) ? (int)$_GET['app_id'] : null;
$userRole = strtolower($_SESSION['role'] ?? '');

// Check if we have an auto-redirect flag from admission
$autoRedirectAppId = $_SESSION['auto_redirect_app_id'] ?? null;
if ($autoRedirectAppId && $autoRedirectAppId == $appId) {
    // Clear the flag
    unset($_SESSION['auto_redirect_app_id']);
    // Redirect immediately to enrollment form
    header('Location: /MI2/student/enrollment_form.php?app_id=' . urlencode($appId));
    exit;
}

// Basic access check: make sure the application belongs to the logged-in user (if user_id is set)
if ($appId && $userId) {
    try {
        // For parents, check if the application was created by them
        if ($userRole === 'parent') {
            $stmt = $pdo->prepare('SELECT id, status, user_id FROM applications WHERE id = :app_id LIMIT 1');
            $stmt->bindParam(':app_id', $appId, PDO::PARAM_INT);
            $stmt->execute();
            $app = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Check if the application was created by this parent
            if (!$app || $app['user_id'] != $userId) {
                // Not found or doesn't belong to parent — show a warning but still allow parent to see pending apps
                $appId = null;
            }
        } else {
            // For students, use the original logic
            $stmt = $pdo->prepare('SELECT id, status FROM applications WHERE id = :app_id AND (user_id = :user_id OR user_id IS NULL) LIMIT 1');
            $stmt->bindParam(':app_id', $appId, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_STR);
            $stmt->execute();
            $res = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$res) {
                // Not found or doesn't belong to user — show a warning but still allow student to see pending apps
                $appId = null;
            }
        }
    } catch (PDOException $e) {
        error_log("Database error checking application status: " . $e->getMessage());
        // Optionally set an error message for the user, or handle more gracefully
        $appId = null; // In case of error, treat as if app_id is not valid for security
    }
}

?>
<main class="container hero">
  <div class="hero-content">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div style="flex:1;">
      <h3>Application Status</h3>

      <div id="statusBox" class="alert alert-info">
        Your application has been submitted. Please wait for Admission to confirm your application.
      </div>

      <div id="actionArea"></div>

    </div>
  </div>
</main>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
// Poll the server for application status every 5 seconds and redirect to payment when approved.
const appId = <?= json_encode($appId) ?>;
const userRole = <?= json_encode($userRole) ?>;

// Check if we have an auto-redirect flag from admission
const autoRedirectAppId = <?= json_encode($_SESSION['auto_redirect_app_id'] ?? null) ?>;
if (autoRedirectAppId && autoRedirectAppId == appId) {
    // Clear the flag
    <?php unset($_SESSION['auto_redirect_app_id']); ?>
    // Redirect immediately to enrollment form
    window.location.href = '/MI2/student/enrollment_form.php?app_id=' + encodeURIComponent(appId);
}

if (appId) {
  const statusBox = document.getElementById('statusBox');
  const actionArea = document.getElementById('actionArea');

  function checkStatus() {
    fetch('/MI2/student/check_application_status.php?app_id=' + encodeURIComponent(appId))
      .then(r => r.json())
      .then(data => {
        if (!data || !data.status) return;
        statusBox.textContent = 'Current status: ' + data.status;
        if (data.status === 'pending') {
          statusBox.className = 'alert alert-info';
          actionArea.innerHTML = '<p class="small-muted">Please wait — Admission will review your application. This page will update automatically when your application status changes.</p>';
        } else if (data.status === 'approved') {
          statusBox.className = 'alert alert-info';
          statusBox.textContent = 'Current status: Approved - Awaiting Verification';
          actionArea.innerHTML = '<p class="small-muted">Your application has been approved by Admission. Please wait for verification before proceeding to enrollment.</p>';
        } else if (data.status === 'verified') {
          statusBox.className = 'alert alert-success';
          statusBox.textContent = 'Current status: Verified - Ready for Enrollment';
          if (userRole === 'parent') {
            actionArea.innerHTML = '<p class="small-muted">The application was approved and verified. You can now proceed to enroll your child.</p>' +
              '<a href="/MI2/Parent/parent_enrollment.php?app_id=' + encodeURIComponent(appId) + '" class="btn btn-accent">Enroll Child Now</a>';
          } else {
            actionArea.innerHTML = '<p class="small-muted">Your application was approved and verified. Proceed to the Enrollment Form...</p>';
            // Redirect to enrollment form for this application
            window.location.href = '/MI2/student/enrollment_form.php?app_id=' + encodeURIComponent(appId);
          }
        } else if (data.status === 'rejected') {
          statusBox.className = 'alert alert-danger';
          actionArea.innerHTML = '<p class="small-muted">Your application was rejected by Admission. Please contact the Admission office for details.</p>';
        }
      }).catch(err => {
        console.error('Status check failed', err);
      });
  }

  // initial check and then polling
  checkStatus();
  const interval = setInterval(checkStatus, 5000);
}
</script>