<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$userId = $_SESSION['user_id'] ?? null;
$userRole = strtolower($_SESSION['role'] ?? '');
$appId = isset($_GET['app_id']) ? (int)$_GET['app_id'] : null;
$message = '';

// Verify application exists and is approved; also fetch applicant name/address if present
$appData = null;
if (!$appId) {
  $message = 'No application specified.';
} else {
  try {
    // For parents, we need to verify they created this application
    if ($userRole === 'parent') {
      $stmt = $pdo->prepare('SELECT id, status, first_name, last_name, contact, user_id FROM applications WHERE id = :app_id LIMIT 1');
      $stmt->bindParam(':app_id', $appId, PDO::PARAM_INT);
      $stmt->execute();
      $appData = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!$appData) {
        $message = 'Application not found.';
        $appId = null;
      } else {
        // Check if this parent created the application
        if ($appData['user_id'] != $userId) {
          $message = 'You do not have permission to access this application.';
          $appId = null;
        } else if ($appData['status'] !== 'verified') {
          $message = 'Application must be verified by Admission before enrollment. Current status: ' . $appData['status'] . '.';
          $appId = null;
        }
      }
    } else {
      // For students, use the original logic
      $stmt = $pdo->prepare('SELECT id, status, first_name, last_name, contact FROM applications WHERE id = :app_id LIMIT 1');
      $stmt->bindParam(':app_id', $appId, PDO::PARAM_INT);
      $stmt->execute();
      $appData = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!$appData) {
        $message = 'Application not found.';
        $appId = null;
      } else {
        if ($appData['status'] !== 'verified') {
          $message = 'Application must be verified by Admission before enrollment. Current status: ' . $appData['status'] . '.';
          $appId = null;
        }
      }
    }
  } catch (PDOException $e) {
    error_log("Database error verifying application: " . $e->getMessage());
    $message = 'Database error verifying application. Please try again later.';
    $appId = null;
  }
}

// Handle enrollment form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $appId) {
  $enrollment_number = trim($_POST['enrollment_number'] ?? '');
  $first_name = trim($_POST['first_name'] ?? '');
  $middle_name = trim($_POST['middle_name'] ?? '');
  $last_name = trim($_POST['last_name'] ?? '');
  $address = trim($_POST['address'] ?? '');
  $contact_number = trim($_POST['contact_number'] ?? '');
  $guardian_name = trim($_POST['guardian_name'] ?? '');
  $guardian_contact = trim($_POST['guardian_contact'] ?? '');
  $grade_level = trim($_POST['grade_level'] ?? '');
  $strand = trim($_POST['strand'] ?? '');
  $program = trim($_POST['program'] ?? '');

  $errors = [];
  if (empty($first_name)) $errors[] = 'First name is required.';
  if (empty($last_name)) $errors[] = 'Last name is required.';
  if (empty($address)) $errors[] = 'Address is required.';
  if (empty($contact_number)) $errors[] = 'Contact number is required.';
  if (empty($guardian_name)) $errors[] = 'Guardian name is required.';
  if (empty($guardian_contact)) $errors[] = 'Guardian contact is required.';
  if (empty($grade_level)) $errors[] = 'Grade level is required.';
  if (($grade_level === 'Grade 11' || $grade_level === 'Grade 12') && empty($strand)) {
    $errors[] = 'Strand is required for Grade 11 and 12.';
  }

  if (!empty($errors)) {
    $message = implode('<br>', $errors);
  } else {
    // Ensure required columns exist in enrollments table to avoid unknown column errors
    $requiredCols = [
      'enrollment_number' => "VARCHAR(64) DEFAULT NULL",
      'first_name' => "VARCHAR(150) DEFAULT NULL",
      'middle_name' => "VARCHAR(150) DEFAULT NULL",
      'last_name' => "VARCHAR(150) DEFAULT NULL",
      'address' => "VARCHAR(255) DEFAULT NULL",
      'contact_number' => "VARCHAR(255) DEFAULT NULL",
      'guardian_name' => "VARCHAR(255) DEFAULT NULL",
      'guardian_contact' => "VARCHAR(255) DEFAULT NULL",
      'grade_level' => "VARCHAR(64) DEFAULT NULL",
      'strand' => "VARCHAR(64) DEFAULT NULL",
      'program' => "VARCHAR(255) DEFAULT NULL",
      'status' => "ENUM('pending_payment','paid') NOT NULL DEFAULT 'pending_payment'",
    ];
    try {
      $placeholders = implode(',', array_map(function($n){ return "'".$n."'"; }, array_keys($requiredCols)));
      $colSql = "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'enrollments' AND COLUMN_NAME IN ($placeholders)";
      $resCols = $pdo->query($colSql);
      $existing = [];
      if ($resCols) {
        while ($r = $resCols->fetch(PDO::FETCH_ASSOC)) {
          $existing[] = $r['COLUMN_NAME'];
        }
      }
      $added = [];
      foreach ($requiredCols as $col => $definition) {
        if (!in_array($col, $existing)) {
          // Special handling for ENUM definition quoting
          $alter = "ALTER TABLE `enrollments` ADD COLUMN `$col` $definition";
          if ($pdo->query($alter)) {
            $added[] = $col;
          }
        }
      }
      if (!empty($added)) {
        $message = 'Added missing columns: ' . implode(', ', $added) . '. Please verify.';
      }
    } catch (PDOException $e) {
      // Non-fatal: continue and let the insert attempt produce a helpful message
      $message = 'Could not auto-migrate enrollments columns: ' . $e->getMessage();
    }

    try {
      $stmt = $pdo->prepare('INSERT INTO enrollments (app_id, user_id, enrollment_number, first_name, middle_name, last_name, address, contact_number, guardian_name, guardian_contact, grade_level, strand, program, status) VALUES (:app_id, :user_id, :enrollment_number, :first_name, :middle_name, :last_name, :address, :contact_number, :guardian_name, :guardian_contact, :grade_level, :strand, :program, :status)');
      if ($stmt) {
        $status = 'pending_payment';
        // For parents, set the user_id to the parent's ID
        $uid = $userId;
        $stmt->bindParam(':app_id', $appId, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $uid);
        $stmt->bindParam(':enrollment_number', $enrollment_number);
        $stmt->bindParam(':first_name', $first_name);
        $stmt->bindParam(':middle_name', $middle_name);
        $stmt->bindParam(':last_name', $last_name);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':contact_number', $contact_number);
        $stmt->bindParam(':guardian_name', $guardian_name);
        $stmt->bindParam(':guardian_contact', $guardian_contact);
        $stmt->bindParam(':grade_level', $grade_level);
        $stmt->bindParam(':strand', $strand);
        $stmt->bindParam(':program', $program);
        $stmt->bindParam(':status', $status);
        
        if ($stmt->execute()) {
          $enrollId = $pdo->lastInsertId();
          
          // For students (not parents), set auto-enroll flag for automatic payment processing
          if ($userRole === 'student') {
            $_SESSION['auto_enroll_app_id'] = $appId;
          }
          
          header('Location: /MI2/student/payment.php?enroll_id=' . urlencode($enrollId));
          exit;
        } else {
          $message = 'Database error: Could not save enrollment.';
        }
      } else {
        $message = 'Prepare failed for enrollment insertion.';
      }
    } catch (PDOException $e) {
      // Friendly error message instead of fatal exception
      $message = 'Database error: ' . $e->getMessage() . '. Please run the migration SQL to add missing columns.';
    }
  }
}

?>

<main class="container hero">
  <div class="hero-content">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div style="flex:1;">
      <h3>Enrollment Form</h3>
      <?php if ($message): ?>
        <div class="alert alert-warning"><?= htmlspecialchars($message) ?></div>
      <?php endif; ?>

      <?php if ($appId): ?>
      <form method="post">
        <?php
        // Generate a provisional enrollment number using the next AUTO_INCREMENT value if possible
        $enrollment_number = '';
        try {
            $statusStmt = $pdo->query("SHOW TABLE STATUS LIKE 'enrollments'");
            $row = $statusStmt->fetch(PDO::FETCH_ASSOC);
            $next = $row['Auto_increment'] ?? null;
            if ($next) {
                // Enrollment number format: MI{YEAR}-{zero-padded id}, e.g. MI2025-00001
                $enrollment_number = sprintf('MI%s-%05d', date('Y'), (int)$next);
            }
        } catch (PDOException $e) {
            error_log("Error fetching auto-increment for enrollments: " . $e->getMessage());
            $message = "Error generating enrollment number.";
        }
        
        // Prefill names from application data if available
        $pref_first = $appData['first_name'] ?? '';
        $pref_last = $appData['last_name'] ?? '';
        $pref_contact = $appData['contact'] ?? '';
        ?>

        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Enrollment ID</label>
            <input name="enrollment_number" class="form-control" readonly value="<?= htmlspecialchars($enrollment_number) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">First Name</label>
            <input name="first_name" class="form-control" required value="<?= htmlspecialchars($pref_first) ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Middle Name</label>
            <input name="middle_name" class="form-control" value="">
          </div>
          <div class="col-md-6">
            <label class="form-label">Last Name</label>
            <input name="last_name" class="form-control" required value="<?= htmlspecialchars($pref_last) ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Address</label>
            <input name="address" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label">Contact Number</label>
            <input name="contact_number" class="form-control" value="<?= htmlspecialchars($pref_contact) ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Guardian / Parent Name</label>
            <input name="guardian_name" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label">Guardian Contact</label>
            <input name="guardian_contact" class="form-control">
          </div>

          <div class="col-md-6">
            <label class="form-label">Grade Level</label>
            <select name="grade_level" id="gradeLevel" class="form-control" required>
              <option value="">-- Select Grade --</option>
              <option>Kinder</option>
              <?php for ($g=1;$g<=10;$g++): ?>
                <option>Grade <?= $g ?></option>
              <?php endfor; ?>
              <option>Grade 11</option>
              <option>Grade 12</option>
            </select>
          </div>

          <div class="col-md-6" id="strandCol" style="display:none">
            <label class="form-label">Strand (Senior High)</label>
            <select name="strand" class="form-control">
              <option value="">-- Select Strand --</option>
              <option>ABM</option>
              <option>HUMSS</option>
              <option>GAS</option>
            </select>
          </div>

          

          <div class="col-12 d-flex justify-content-end">
            <button class="btn btn-accent" type="submit">Proceed to Payment</button>
          </div>
        </div>
      </form>
      <?php else: ?>
        <div class="alert alert-secondary">Enrollment form is not available.</div>
      <?php endif; ?>
    </div>
  </div>
</main>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
// Show strand select when grade level is Grade 11 or Grade 12
document.addEventListener('DOMContentLoaded', function(){
  var grade = document.getElementById('gradeLevel');
  var strandCol = document.getElementById('strandCol');
  function updateStrand() {
    var v = grade.value || '';
    if (v === 'Grade 11' || v === 'Grade 12') {
      strandCol.style.display = '';
    } else {
      strandCol.style.display = 'none';
    }
  }
  if (grade) {
    grade.addEventListener('change', updateStrand);
    updateStrand();
  }

  const form = document.querySelector('form');
  if (form) {
    form.addEventListener('submit', function (event) {
        let isValid = true;
        
        const requiredFields = [
            'first_name', 'last_name', 'address', 'contact_number', 
            'guardian_name', 'guardian_contact', 'grade_level'
        ];

        requiredFields.forEach(function (fieldName) {
            const field = form.querySelector(`[name=${fieldName}]`);
            if (field && field.value.trim() === '') {
                field.classList.add('is-invalid');
                isValid = false;
            } else if (field) {
                field.classList.remove('is-invalid');
            }
        });

        if (grade.value === 'Grade 11' || grade.value === 'Grade 12') {
            const strand = form.querySelector('[name=strand]');
            if (strand && strand.value.trim() === '') {
                strand.classList.add('is-invalid');
                isValid = false;
            } else if (strand) {
                strand.classList.remove('is-invalid');
            }
        }

        if (!isValid) {
            event.preventDefault();
        }
    });
  }
});
</script>
