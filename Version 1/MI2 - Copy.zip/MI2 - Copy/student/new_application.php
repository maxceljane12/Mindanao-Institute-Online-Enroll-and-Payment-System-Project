<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$userId = $_SESSION['user_id'] ?? null;
$message = '';
$enrollmentActive = false;
$enrollmentPeriod = null;

// Check if enrollment is currently active
try {
    $stmt = $pdo->query("SELECT * FROM enrollment_periods WHERE is_active = 1 LIMIT 1");
    $enrollmentPeriod = $stmt->fetch(PDO::FETCH_ASSOC);
    $enrollmentActive = !empty($enrollmentPeriod);
} catch (PDOException $e) {
    $message = 'Database error: ' . $e->getMessage();
}

// If user already has a pending application, redirect to status page so they remain where they left off
if ($userId) {
    try {
        $check = $pdo->prepare("SELECT id, status FROM applications WHERE user_id = :user_id AND status IN ('pending','approved') ORDER BY created_at DESC LIMIT 1");
        $check->bindParam(':user_id', $userId);
        $check->execute();
        $row = $check->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            header('Location: /MI2/student/application_status.php?app_id=' . urlencode($row['id']));
            exit;
        }
    } catch (PDOException $e) {
        error_log("Database error checking existing application: " . $e->getMessage());
        // Optionally set an error message for the user
        $message = "Error checking application status. Please try again later.";
    }
}

// Load draft from session if user saved one earlier
$draft = $_SESSION['application_draft'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $enrollmentActive) {
    // Save draft request
    if (isset($_POST['save_draft'])) {
        $_SESSION['application_draft'] = [
            'first_name' => trim($_POST['first_name'] ?? ''),
            'last_name' => trim($_POST['last_name'] ?? ''),
            'middle_name' => trim($_POST['middle_name'] ?? ''),
            'suffix' => trim($_POST['suffix'] ?? ''),
            'sex' => trim($_POST['sex'] ?? ''),
            'birthdate' => $_POST['birthdate'] ?? null,
            'place_of_birth' => trim($_POST['place_of_birth'] ?? ''),
            'nationality' => trim($_POST['nationality'] ?? ''),
            'religion' => trim($_POST['religion'] ?? ''),
            'lrn' => trim($_POST['lrn'] ?? ''),
            'contact' => trim($_POST['contact'] ?? ''),
            'email_address' => trim($_POST['email_address'] ?? ''),
            'home_address' => trim($_POST['home_address'] ?? ''),
            'barangay' => trim($_POST['barangay'] ?? ''),
            'municipality' => trim($_POST['municipality'] ?? ''),
            'province' => trim($_POST['province'] ?? ''),
            'zip_code' => trim($_POST['zip_code'] ?? ''),
            'application_type' => trim($_POST['application_type'] ?? ''),
            'last_school_attended' => trim($_POST['last_school_attended'] ?? ''),
            'school_address' => trim($_POST['school_address'] ?? ''),
            'last_grade_level_completed' => trim($_POST['last_grade_level_completed'] ?? ''),
            'year_completed' => trim($_POST['year_completed'] ?? ''),
            'awards_received' => trim($_POST['awards_received'] ?? ''),
            'mother_name' => trim($_POST['mother_name'] ?? ''),
            'mother_contact' => trim($_POST['mother_contact'] ?? ''),
            'mother_occupation' => trim($_POST['mother_occupation'] ?? ''),
            'father_name' => trim($_POST['father_name'] ?? ''),
            'father_contact' => trim($_POST['father_contact'] ?? ''),
            'father_occupation' => trim($_POST['father_occupation'] ?? ''),
            'guardian_name' => trim($_POST['guardian_name'] ?? ''),
            'guardian_relationship' => trim($_POST['guardian_relationship'] ?? ''),
            'guardian_contact' => trim($_POST['guardian_contact'] ?? ''),
            'guardian_address' => trim($_POST['guardian_address'] ?? ''),
            'emergency_name' => trim($_POST['emergency_name'] ?? ''),
            'emergency_relationship' => trim($_POST['emergency_relationship'] ?? ''),
            'emergency_mobile' => trim($_POST['emergency_mobile'] ?? ''),
            'emergency_address' => trim($_POST['emergency_address'] ?? ''),
            'saved_at' => date('c')
        ];
        $message = 'Draft saved. You can resume later.';
        $draft = $_SESSION['application_draft'];
    } else {
        // Submit final application
        // Personal Information
        $last_name = trim($_POST['last_name'] ?? '');
        $first_name = trim($_POST['first_name'] ?? '');
        $middle_name = trim($_POST['middle_name'] ?? '');
        $suffix = trim($_POST['suffix'] ?? '');
        $sex = trim($_POST['sex'] ?? '');
        $date_of_birth = $_POST['date_of_birth'] ?? null;
        $place_of_birth = trim($_POST['place_of_birth'] ?? '');
        $nationality = trim($_POST['nationality'] ?? '');
        $religion = trim($_POST['religion'] ?? '');
        $lrn = trim($_POST['lrn'] ?? '');
        
        // Contact Information
        $mobile_number = trim($_POST['mobile_number'] ?? '');
        $email_address = trim($_POST['email_address'] ?? '');
        $home_address = trim($_POST['home_address'] ?? '');
        $barangay = trim($_POST['barangay'] ?? '');
        $municipality = trim($_POST['municipality'] ?? '');
        $province = trim($_POST['province'] ?? '');
        $zip_code = trim($_POST['zip_code'] ?? '');
        
        // Application Type
        $application_type = trim($_POST['application_type'] ?? '');
        
        // Educational Background
        $last_school_attended = trim($_POST['last_school_attended'] ?? '');
        $school_address = trim($_POST['school_address'] ?? '');
        $last_grade_level_completed = trim($_POST['last_grade_level_completed'] ?? '');
        $year_completed = trim($_POST['year_completed'] ?? '');
        $awards_received = trim($_POST['awards_received'] ?? '');
        
        // Parent/Guardian Information - Mother
        $mother_name = trim($_POST['mother_name'] ?? '');
        $mother_contact = trim($_POST['mother_contact'] ?? '');
        $mother_occupation = trim($_POST['mother_occupation'] ?? '');
        
        // Parent/Guardian Information - Father
        $father_name = trim($_POST['father_name'] ?? '');
        $father_contact = trim($_POST['father_contact'] ?? '');
        $father_occupation = trim($_POST['father_occupation'] ?? '');
        
        // Parent/Guardian Information - Guardian
        $guardian_name = trim($_POST['guardian_name'] ?? '');
        $guardian_relationship = trim($_POST['guardian_relationship'] ?? '');
        $guardian_contact = trim($_POST['guardian_contact'] ?? '');
        $guardian_address = trim($_POST['guardian_address'] ?? '');
        
        // Emergency Contact
        $emergency_name = trim($_POST['emergency_name'] ?? '');
        $emergency_relationship = trim($_POST['emergency_relationship'] ?? '');
        $emergency_mobile = trim($_POST['emergency_mobile'] ?? '');
        $emergency_address = trim($_POST['emergency_address'] ?? '');

        $errors = [];
        if (empty($last_name)) $errors[] = 'Last name is required.';
        if (empty($first_name)) $errors[] = 'First name is required.';
        if (empty($sex)) $errors[] = 'Sex is required.';
        if (empty($date_of_birth)) $errors[] = 'Date of birth is required.';
        if (empty($mobile_number)) $errors[] = 'Mobile number is required.';
        if (empty($home_address)) $errors[] = 'Home address is required.';
        if (empty($barangay)) $errors[] = 'Barangay is required.';
        if (empty($municipality)) $errors[] = 'Municipality/City is required.';
        if (empty($province)) $errors[] = 'Province is required.';
        if (empty($mother_name)) $errors[] = 'Mother\'s name is required.';
        if (empty($mother_contact)) $errors[] = 'Mother\'s contact number is required.';
        if (empty($father_name)) $errors[] = 'Father\'s name is required.';
        if (empty($father_contact)) $errors[] = 'Father\'s contact number is required.';
        if (empty($emergency_name)) $errors[] = 'Emergency contact name is required.';
        if (empty($emergency_relationship)) $errors[] = 'Emergency contact relationship is required.';
        if (empty($emergency_mobile)) $errors[] = 'Emergency contact mobile number is required.';
        if (empty($emergency_address)) $errors[] = 'Emergency contact address is required.';
        if (empty($application_type)) $errors[] = 'Application type is required.';
        
        // For new students, require educational background
        if (empty($last_school_attended)) $errors[] = 'Last school attended is required for new students.';
        if (empty($last_grade_level_completed)) $errors[] = 'Last grade level completed is required for new students.';
        if (empty($year_completed)) $errors[] = 'Year completed is required for new students.';

        if (!empty($errors)) {
            $message = implode('<br>', $errors);
        } else {
            try {
                // Create the application first
                $stmt = $pdo->prepare('INSERT INTO applications (user_id, first_name, last_name, birthdate, contact, status) VALUES (:user_id, :first_name, :last_name, :birthdate, :contact, :status)');
                $status = 'pending';
                $stmt->bindParam(':user_id', $userId);
                $stmt->bindParam(':first_name', $first_name);
                $stmt->bindParam(':last_name', $last_name);
                $stmt->bindParam(':birthdate', $date_of_birth);
                $stmt->bindParam(':contact', $mobile_number);
                $stmt->bindParam(':status', $status);
                
                if ($stmt->execute()) {
                    $appId = $pdo->lastInsertId();
                    
                    // Insert detailed application information
                    $detailStmt = $pdo->prepare('INSERT INTO application_details (
                        application_id, middle_name, suffix, place_of_birth, nationality, religion, lrn,
                        email_address, home_address, barangay, municipality, province, zip_code,
                        application_type, last_school_attended, school_address, last_grade_level_completed,
                        year_completed, awards_received, mother_name, mother_contact, mother_occupation,
                        father_name, father_contact, father_occupation, guardian_name, guardian_relationship,
                        guardian_contact, guardian_address, emergency_name, emergency_relationship,
                        emergency_mobile, emergency_address
                    ) VALUES (
                        :application_id, :middle_name, :suffix, :place_of_birth, :nationality, :religion, :lrn,
                        :email_address, :home_address, :barangay, :municipality, :province, :zip_code,
                        :application_type, :last_school_attended, :school_address, :last_grade_level_completed,
                        :year_completed, :awards_received, :mother_name, :mother_contact, :mother_occupation,
                        :father_name, :father_contact, :father_occupation, :guardian_name, :guardian_relationship,
                        :guardian_contact, :guardian_address, :emergency_name, :emergency_relationship,
                        :emergency_mobile, :emergency_address
                    )');
                    
                    $detailStmt->bindParam(':application_id', $appId, PDO::PARAM_INT);
                    $detailStmt->bindParam(':middle_name', $middle_name, PDO::PARAM_STR);
                    $detailStmt->bindParam(':suffix', $suffix, PDO::PARAM_STR);
                    $detailStmt->bindParam(':place_of_birth', $place_of_birth, PDO::PARAM_STR);
                    $detailStmt->bindParam(':nationality', $nationality, PDO::PARAM_STR);
                    $detailStmt->bindParam(':religion', $religion, PDO::PARAM_STR);
                    $detailStmt->bindParam(':lrn', $lrn, PDO::PARAM_STR);
                    $detailStmt->bindParam(':email_address', $email_address, PDO::PARAM_STR);
                    $detailStmt->bindParam(':home_address', $home_address, PDO::PARAM_STR);
                    $detailStmt->bindParam(':barangay', $barangay, PDO::PARAM_STR);
                    $detailStmt->bindParam(':municipality', $municipality, PDO::PARAM_STR);
                    $detailStmt->bindParam(':province', $province, PDO::PARAM_STR);
                    $detailStmt->bindParam(':zip_code', $zip_code, PDO::PARAM_STR);
                    $detailStmt->bindParam(':application_type', $application_type, PDO::PARAM_STR);
                    $detailStmt->bindParam(':last_school_attended', $last_school_attended, PDO::PARAM_STR);
                    $detailStmt->bindParam(':school_address', $school_address, PDO::PARAM_STR);
                    $detailStmt->bindParam(':last_grade_level_completed', $last_grade_level_completed, PDO::PARAM_STR);
                    $detailStmt->bindParam(':year_completed', $year_completed, PDO::PARAM_STR);
                    $detailStmt->bindParam(':awards_received', $awards_received, PDO::PARAM_STR);
                    $detailStmt->bindParam(':mother_name', $mother_name, PDO::PARAM_STR);
                    $detailStmt->bindParam(':mother_contact', $mother_contact, PDO::PARAM_STR);
                    $detailStmt->bindParam(':mother_occupation', $mother_occupation, PDO::PARAM_STR);
                    $detailStmt->bindParam(':father_name', $father_name, PDO::PARAM_STR);
                    $detailStmt->bindParam(':father_contact', $father_contact, PDO::PARAM_STR);
                    $detailStmt->bindParam(':father_occupation', $father_occupation, PDO::PARAM_STR);
                    $detailStmt->bindParam(':guardian_name', $guardian_name, PDO::PARAM_STR);
                    $detailStmt->bindParam(':guardian_relationship', $guardian_relationship, PDO::PARAM_STR);
                    $detailStmt->bindParam(':guardian_contact', $guardian_contact, PDO::PARAM_STR);
                    $detailStmt->bindParam(':guardian_address', $guardian_address, PDO::PARAM_STR);
                    $detailStmt->bindParam(':emergency_name', $emergency_name, PDO::PARAM_STR);
                    $detailStmt->bindParam(':emergency_relationship', $emergency_relationship, PDO::PARAM_STR);
                    $detailStmt->bindParam(':emergency_mobile', $emergency_mobile, PDO::PARAM_STR);
                    $detailStmt->bindParam(':emergency_address', $emergency_address, PDO::PARAM_STR);
                    
                    if ($detailStmt->execute()) {
                        // clear draft after successful submission
                        unset($_SESSION['application_draft']);
                        // Redirect to application status page where student will wait for admission confirmation
                        header('Location: /MI2/student/application_status.php?app_id=' . urlencode($appId));
                        exit;
                    } else {
                        $message = 'Database error: Could not save application details.';
                    }
                } else {
                    $message = 'Database error: Could not submit application.';
                }
            } catch (PDOException $e) {
                error_log("Database error submitting application: " . $e->getMessage());
                $message = 'Database error: Could not submit application. Please try again later.';
            }
        }
    }
}
?>

<main class="container hero">
  <div class="hero-content">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div style="flex:1;">
      <h3>New Student Application</h3>
      <?php if ($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
      <?php endif; ?>

      <?php if (!$enrollmentActive): ?>
        <div class="alert alert-warning">
          <strong>Enrollment is currently not active.</strong> 
          <?php if ($enrollmentPeriod): ?>
            Enrollment for <?= htmlspecialchars($enrollmentPeriod['school_year']) ?> will be active from 
            <?= htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['start_date']))) ?> to 
            <?= htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['end_date']))) ?>.
          <?php else: ?>
            Please contact administration for more information about enrollment periods.
          <?php endif; ?>
        </div>
      <?php else: ?>
        <form method="post" id="applicationForm">
          <!-- A. APPLICANT INFORMATION -->
          <div class="col-12">
            <h4 class="mt-4">A. APPLICANT INFORMATION</h4>
            <hr>
          </div>
          
          <!-- 1. Personal Information -->
          <div class="col-12">
            <h5>1. Personal Information</h5>
          </div>
          
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label">Last Name *</label>
              <input name="last_name" id="last_name" class="form-control" required value="<?= htmlspecialchars($draft['last_name'] ?? '') ?>">
              <div class="invalid-feedback">Last name is required.</div>
            </div>
            <div class="col-md-4">
              <label class="form-label">First Name *</label>
              <input name="first_name" id="first_name" class="form-control" required value="<?= htmlspecialchars($draft['first_name'] ?? '') ?>">
              <div class="invalid-feedback">First name is required.</div>
            </div>
            <div class="col-md-4">
              <label class="form-label">Middle Name</label>
              <input name="middle_name" class="form-control" value="<?= htmlspecialchars($draft['middle_name'] ?? '') ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">Suffix (Jr./III)</label>
              <input name="suffix" class="form-control" value="<?= htmlspecialchars($draft['suffix'] ?? '') ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">Sex *</label>
              <select name="sex" class="form-control" required>
                <option value="">-- Select --</option>
                <option value="Male" <?= (isset($draft['sex']) && $draft['sex'] === 'Male') ? 'selected' : '' ?>>Male</option>
                <option value="Female" <?= (isset($draft['sex']) && $draft['sex'] === 'Female') ? 'selected' : '' ?>>Female</option>
              </select>
              <div class="invalid-feedback">Sex is required.</div>
            </div>
            <div class="col-md-4">
              <label class="form-label">Date of Birth *</label>
              <input type="date" name="date_of_birth" id="date_of_birth" class="form-control" required value="<?= htmlspecialchars($draft['birthdate'] ?? '') ?>">
              <div class="invalid-feedback">Date of birth is required.</div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Place of Birth</label>
              <input name="place_of_birth" class="form-control" value="<?= htmlspecialchars($draft['place_of_birth'] ?? '') ?>">
            </div>
            <div class="col-md-3">
              <label class="form-label">Nationality</label>
              <input name="nationality" class="form-control" value="<?= htmlspecialchars($draft['nationality'] ?? 'Filipino') ?>">
            </div>
            <div class="col-md-3">
              <label class="form-label">Religion</label>
              <input name="religion" class="form-control" value="<?= htmlspecialchars($draft['religion'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Learner Reference Number (LRN)</label>
              <input name="lrn" class="form-control" value="<?= htmlspecialchars($draft['lrn'] ?? '') ?>">
            </div>
            
            <!-- 2. Contact Information -->
            <div class="col-12">
              <h5 class="mt-4">2. Contact Information</h5>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Mobile Number *</label>
              <input name="mobile_number" id="mobile_number" class="form-control" required value="<?= htmlspecialchars($draft['contact'] ?? '') ?>">
              <div class="invalid-feedback">Mobile number is required.</div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Email Address</label>
              <input type="email" name="email_address" class="form-control" value="<?= htmlspecialchars($draft['email_address'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Home Address *</label>
              <input name="home_address" id="home_address" class="form-control" required value="<?= htmlspecialchars($draft['home_address'] ?? '') ?>">
              <div class="invalid-feedback">Home address is required.</div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Barangay *</label>
              <input name="barangay" id="barangay" class="form-control" required value="<?= htmlspecialchars($draft['barangay'] ?? '') ?>">
              <div class="invalid-feedback">Barangay is required.</div>
            </div>
            <div class="col-md-4">
              <label class="form-label">Municipality/City *</label>
              <input name="municipality" id="municipality" class="form-control" required value="<?= htmlspecialchars($draft['municipality'] ?? '') ?>">
              <div class="invalid-feedback">Municipality/City is required.</div>
            </div>
            <div class="col-md-4">
              <label class="form-label">Province *</label>
              <input name="province" id="province" class="form-control" required value="<?= htmlspecialchars($draft['province'] ?? '') ?>">
              <div class="invalid-feedback">Province is required.</div>
            </div>
            <div class="col-md-4">
              <label class="form-label">ZIP Code</label>
              <input name="zip_code" class="form-control" value="<?= htmlspecialchars($draft['zip_code'] ?? '') ?>">
            </div>
            
            <!-- B. APPLICATION TYPE -->
            <div class="col-12">
              <h4 class="mt-4">B. APPLICATION TYPE</h4>
              <hr>
              <p>(Select one)</p>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="application_type" value="New Student" id="new_student" <?= (isset($draft['application_type']) && $draft['application_type'] === 'New Student') ? 'checked' : '' ?> required>
                <label class="form-check-label" for="new_student">New Student</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="application_type" value="Transferee" id="transferee" <?= (isset($draft['application_type']) && $draft['application_type'] === 'Transferee') ? 'checked' : '' ?>>
                <label class="form-check-label" for="transferee">Transferee</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="application_type" value="Returning / Balik-Aral" id="balik_aral" <?= (isset($draft['application_type']) && $draft['application_type'] === 'Returning / Balik-Aral') ? 'checked' : '' ?>>
                <label class="form-check-label" for="balik_aral">Returning / Balik-Aral</label>
              </div>
              <div class="invalid-feedback">Application type is required.</div>
            </div>
            
            <!-- C. EDUCATIONAL BACKGROUND -->
            <div class="col-12">
              <h4 class="mt-4">C. EDUCATIONAL BACKGROUND</h4>
              <hr>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Last School Attended</label>
              <input name="last_school_attended" class="form-control" value="<?= htmlspecialchars($draft['last_school_attended'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">School Address</label>
              <input name="school_address" class="form-control" value="<?= htmlspecialchars($draft['school_address'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Last Grade Level Completed</label>
              <input name="last_grade_level_completed" class="form-control" value="<?= htmlspecialchars($draft['last_grade_level_completed'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Year Completed</label>
              <input name="year_completed" class="form-control" value="<?= htmlspecialchars($draft['year_completed'] ?? '') ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Awards / Honors Received (if any)</label>
              <input name="awards_received" class="form-control" value="<?= htmlspecialchars($draft['awards_received'] ?? '') ?>">
            </div>
            
            <!-- D. PARENT / GUARDIAN INFORMATION -->
            <div class="col-12">
              <h4 class="mt-4">D. PARENT / GUARDIAN INFORMATION</h4>
              <hr>
            </div>
            
            <!-- Mother -->
            <div class="col-12">
              <h5>1. Mother</h5>
            </div>
            <div class="col-md-6">
              <label class="form-label">Full Name *</label>
              <input name="mother_name" id="mother_name" class="form-control" required value="<?= htmlspecialchars($draft['mother_name'] ?? '') ?>">
              <div class="invalid-feedback">Mother's name is required.</div>
            </div>
            <div class="col-md-3">
              <label class="form-label">Contact Number *</label>
              <input name="mother_contact" id="mother_contact" class="form-control" required value="<?= htmlspecialchars($draft['mother_contact'] ?? '') ?>">
              <div class="invalid-feedback">Mother's contact number is required.</div>
            </div>
            <div class="col-md-3">
              <label class="form-label">Occupation</label>
              <input name="mother_occupation" class="form-control" value="<?= htmlspecialchars($draft['mother_occupation'] ?? '') ?>">
            </div>
            
            <!-- Father -->
            <div class="col-12">
              <h5 class="mt-4">2. Father</h5>
            </div>
            <div class="col-md-6">
              <label class="form-label">Full Name *</label>
              <input name="father_name" id="father_name" class="form-control" required value="<?= htmlspecialchars($draft['father_name'] ?? '') ?>">
              <div class="invalid-feedback">Father's name is required.</div>
            </div>
            <div class="col-md-3">
              <label class="form-label">Contact Number *</label>
              <input name="father_contact" id="father_contact" class="form-control" required value="<?= htmlspecialchars($draft['father_contact'] ?? '') ?>">
              <div class="invalid-feedback">Father's contact number is required.</div>
            </div>
            <div class="col-md-3">
              <label class="form-label">Occupation</label>
              <input name="father_occupation" class="form-control" value="<?= htmlspecialchars($draft['father_occupation'] ?? '') ?>">
            </div>
            
            <!-- Guardian -->
            <div class="col-12">
              <h5 class="mt-4">3. Guardian (if not living with parents)</h5>
            </div>
            <div class="col-md-6">
              <label class="form-label">Full Name</label>
              <input name="guardian_name" class="form-control" value="<?= htmlspecialchars($draft['guardian_name'] ?? '') ?>">
            </div>
            <div class="col-md-3">
              <label class="form-label">Relationship to Applicant</label>
              <input name="guardian_relationship" class="form-control" value="<?= htmlspecialchars($draft['guardian_relationship'] ?? '') ?>">
            </div>
            <div class="col-md-3">
              <label class="form-label">Contact Number</label>
              <input name="guardian_contact" class="form-control" value="<?= htmlspecialchars($draft['guardian_contact'] ?? '') ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Address</label>
              <input name="guardian_address" class="form-control" value="<?= htmlspecialchars($draft['guardian_address'] ?? '') ?>">
            </div>
            
            <!-- E. EMERGENCY CONTACT -->
            <div class="col-12">
              <h4 class="mt-4">E. EMERGENCY CONTACT</h4>
              <hr>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Name *</label>
              <input name="emergency_name" id="emergency_name" class="form-control" required value="<?= htmlspecialchars($draft['emergency_name'] ?? '') ?>">
              <div class="invalid-feedback">Emergency contact name is required.</div>
            </div>
            <div class="col-md-3">
              <label class="form-label">Relationship *</label>
              <input name="emergency_relationship" id="emergency_relationship" class="form-control" required value="<?= htmlspecialchars($draft['emergency_relationship'] ?? '') ?>">
              <div class="invalid-feedback">Emergency contact relationship is required.</div>
            </div>
            <div class="col-md-3">
              <label class="form-label">Mobile Number *</label>
              <input name="emergency_mobile" id="emergency_mobile" class="form-control" required value="<?= htmlspecialchars($draft['emergency_mobile'] ?? '') ?>">
              <div class="invalid-feedback">Emergency contact mobile number is required.</div>
            </div>
            <div class="col-12">
              <label class="form-label">Address *</label>
              <input name="emergency_address" id="emergency_address" class="form-control" required value="<?= htmlspecialchars($draft['emergency_address'] ?? '') ?>">
              <div class="invalid-feedback">Emergency contact address is required.</div>
            </div>
            
            <div class="col-12">
              <div class="alert alert-info">
                <strong>Note:</strong> This is a complete application form for new students. After submission, you will need to wait for admission approval before proceeding with enrollment.
              </div>
            </div>

            <div class="col-12 d-flex gap-2">
              <button class="btn btn-accent" type="submit">Submit Application</button>
              <button class="btn btn-outline-secondary" type="submit" name="save_draft" value="1">Save Draft</button>
            </div>
            <?php if (!empty($draft['saved_at'])): ?>
              <div class="mt-2 small-muted">Draft last saved: <?= htmlspecialchars($draft['saved_at']) ?></div>
            <?php endif; ?>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('applicationForm');
    
    if (form) {
        form.addEventListener('submit', function (event) {
            // Skip validation if saving draft
            if (form.querySelector('[name=save_draft]') && form.querySelector('[name=save_draft]').value === '1') {
                return;
            }
            
            let isValid = true;
            
            // Validate required fields
            const requiredFields = [
                'last_name', 'first_name', 'sex', 'date_of_birth', 
                'mobile_number', 'home_address', 'barangay', 'municipality', 'province',
                'mother_name', 'mother_contact', 'father_name', 'father_contact',
                'emergency_name', 'emergency_relationship', 'emergency_mobile', 'emergency_address'
            ];
            
            requiredFields.forEach(function(fieldName) {
                const field = form.querySelector(`[name=${fieldName}]`);
                if (field && field.value.trim() === '') {
                    field.classList.add('is-invalid');
                    isValid = false;
                } else if (field) {
                    field.classList.remove('is-invalid');
                }
            });
            
            // Validate radio buttons for application type
            const applicationTypeChecked = form.querySelector('input[name="application_type"]:checked');
            if (!applicationTypeChecked) {
                // Add invalid feedback to the first radio button
                const firstRadio = form.querySelector('input[name="application_type"]');
                if (firstRadio) {
                    firstRadio.classList.add('is-invalid');
                }
                isValid = false;
            } else {
                // Remove invalid feedback from radio buttons
                const radioButtons = form.querySelectorAll('input[name="application_type"]');
                radioButtons.forEach(radio => {
                    radio.classList.remove('is-invalid');
                });
            }
            
            if (!isValid) {
                event.preventDefault();
            }
        });
    }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>