<?php
// Start session at the very beginning
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

// Check if user is student (not parent)
if (!isset($_SESSION['user_id']) || strtolower($_SESSION['role']) !== 'student') {
    header('Location: ../index.php');
    exit;
}

$userId = $_SESSION['user_id'];
$message = '';
$success = false;
$enrollmentActive = false;
$enrollmentPeriod = null;

// Check if enrollment is currently active
try {
    $stmt = $pdo->query("SELECT * FROM enrollment_periods WHERE is_active = 1 LIMIT 1");
    $enrollmentPeriod = $stmt->fetch(PDO::FETCH_ASSOC);
    $enrollmentActive = !empty($enrollmentPeriod);
} catch (PDOException $e) {
    $message = 'Database error: ' . $e->getMessage();
}

// Check if student has already enrolled in the current period
$alreadyEnrolled = false;
if ($enrollmentActive && $enrollmentPeriod) {
    try {
        // Check if student has already enrolled in the current school year
        $stmt = $pdo->prepare("
            SELECT e.id 
            FROM enrollments e 
            JOIN enrollment_periods ep ON e.created_at >= ep.start_date AND e.created_at <= ep.end_date
            WHERE e.user_id = :user_id AND ep.id = :period_id
        ");
        $stmt->execute([
            'user_id' => $userId,
            'period_id' => $enrollmentPeriod['id']
        ]);
        $enrollmentResult = $stmt->fetch();
        $alreadyEnrolled = !empty($enrollmentResult);
    } catch (PDOException $e) {
        $message = 'Database error: ' . $e->getMessage();
    }
}

// Get existing student information
$existingInfo = null;
try {
    $stmt = $pdo->prepare("
        SELECT first_name, middle_name, last_name, address, contact_number, guardian_name, guardian_contact, grade_level, strand, program 
        FROM enrollments 
        WHERE user_id = :user_id 
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $stmt->execute(['user_id' => $userId]);
    $existingInfo = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = 'Database error: ' . $e->getMessage();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if enrollment is active
    if (!$enrollmentActive) {
        $message = 'Enrollment is currently not active. Please contact administration for more information.';
    } 
    // Check if student has already enrolled
    elseif ($alreadyEnrolled) {
        $message = 'You have already submitted an enrollment for the current school year. Please contact administration if you need to make changes.';
    } 
    else {
        // Basic information for old students
        $last_name = trim($_POST['last_name'] ?? '');
        $first_name = trim($_POST['first_name'] ?? '');
        $middle_name = trim($_POST['middle_name'] ?? '');
        $mobile_number = trim($_POST['mobile_number'] ?? '');
        $home_address = trim($_POST['home_address'] ?? '');
        $last_grade_level_completed = trim($_POST['last_grade_level_completed'] ?? '');
        
        // Parent/Guardian Information
        $mother_name = trim($_POST['mother_name'] ?? '');
        $mother_contact = trim($_POST['mother_contact'] ?? '');
        $father_name = trim($_POST['father_name'] ?? '');
        $father_contact = trim($_POST['father_contact'] ?? '');
        $guardian_name = trim($_POST['guardian_name'] ?? '');
        $guardian_contact = trim($_POST['guardian_contact'] ?? '');

        $errors = [];
        if (empty($last_name)) $errors[] = 'Last name is required.';
        if (empty($first_name)) $errors[] = 'First name is required.';
        if (empty($mobile_number)) $errors[] = 'Mobile number is required.';
        if (empty($home_address)) $errors[] = 'Home address is required.';
        if (empty($last_grade_level_completed)) $errors[] = 'Last grade level completed is required.';
        if (empty($mother_name)) $errors[] = 'Mother\'s name is required.';
        if (empty($mother_contact)) $errors[] = 'Mother\'s contact number is required.';
        if (empty($father_name)) $errors[] = 'Father\'s name is required.';
        if (empty($father_contact)) $errors[] = 'Father\'s contact number is required.';

        if (!empty($errors)) {
            $message = implode('<br>', $errors);
        } else {
            try {
                // For old students, create a proper application record first
                $stmtApp = $pdo->prepare('INSERT INTO applications (user_id, first_name, last_name, birthdate, contact, status) VALUES (:user_id, :first_name, :last_name, :birthdate, :contact, :status)');
                $status = 'verified'; // Old students don't need approval, set directly to verified
                $birthdate = date('Y-m-d'); // Default birthdate
                $stmtApp->bindParam(':user_id', $userId);
                $stmtApp->bindParam(':first_name', $first_name, PDO::PARAM_STR);
                $stmtApp->bindParam(':last_name', $last_name, PDO::PARAM_STR);
                $stmtApp->bindParam(':birthdate', $birthdate, PDO::PARAM_STR);
                $stmtApp->bindParam(':contact', $mobile_number, PDO::PARAM_STR);
                $stmtApp->bindParam(':status', $status, PDO::PARAM_STR);
                
                if ($stmtApp->execute()) {
                    $appId = $pdo->lastInsertId();
                    
                    // Create application details record for old students
                    // This ensures proper data consistency in the application_details table
                    try {
                        $detailStmt = $pdo->prepare('INSERT INTO application_details (application_id, middle_name, home_address, last_grade_level_completed, mother_name, mother_contact, father_name, father_contact, guardian_name, guardian_contact, application_type, last_school_attended, year_completed, emergency_name, emergency_relationship, emergency_mobile, emergency_address) VALUES (:application_id, :middle_name, :home_address, :last_grade_level_completed, :mother_name, :mother_contact, :father_name, :father_contact, :guardian_name, :guardian_contact, :application_type, :last_school_attended, :year_completed, :emergency_name, :emergency_relationship, :emergency_mobile, :emergency_address)');
                        $detailStmt->bindParam(':application_id', $appId, PDO::PARAM_INT);
                        $detailStmt->bindParam(':middle_name', $middle_name, PDO::PARAM_STR);
                        $detailStmt->bindParam(':home_address', $home_address, PDO::PARAM_STR);
                        $detailStmt->bindParam(':last_grade_level_completed', $last_grade_level_completed, PDO::PARAM_STR);
                        $detailStmt->bindParam(':mother_name', $mother_name, PDO::PARAM_STR);
                        $detailStmt->bindParam(':mother_contact', $mother_contact, PDO::PARAM_STR);
                        $detailStmt->bindParam(':father_name', $father_name, PDO::PARAM_STR);
                        $detailStmt->bindParam(':father_contact', $father_contact, PDO::PARAM_STR);
                        $detailStmt->bindParam(':guardian_name', $guardian_name, PDO::PARAM_STR);
                        $detailStmt->bindParam(':guardian_contact', $guardian_contact, PDO::PARAM_STR);
                        $detailStmt->bindParam(':application_type', 'Returning / Balik-Aral', PDO::PARAM_STR);
                        $detailStmt->bindParam(':last_school_attended', 'Previous School', PDO::PARAM_STR);
                        $detailStmt->bindParam(':year_completed', date('Y'), PDO::PARAM_STR);
                        $detailStmt->bindParam(':emergency_name', $guardian_name ?: ($father_name ?: $mother_name), PDO::PARAM_STR);
                        $detailStmt->bindParam(':emergency_relationship', 'Guardian', PDO::PARAM_STR);
                        $detailStmt->bindParam(':emergency_mobile', $guardian_contact ?: ($father_contact ?: $mother_contact), PDO::PARAM_STR);
                        $detailStmt->bindParam(':emergency_address', $home_address, PDO::PARAM_STR);
                        $detailStmt->execute();
                    } catch (PDOException $e) {
                        error_log("Error creating application details: " . $e->getMessage());
                    }
                    
                    // Generate enrollment number
                    $statusStmt = $pdo->query("SHOW TABLE STATUS LIKE 'enrollments'");
                    $row = $statusStmt->fetch(PDO::FETCH_ASSOC);
                    $next = $row['Auto_increment'] ?? null;
                    if ($next) {
                        $enrollment_number = sprintf('MI%s-%05d', date('Y'), (int)$next);
                    } else {
                        $enrollment_number = 'MI' . date('Y') . '-' . rand(10000, 99999);
                    }

                    // Insert enrollment record
                    $stmt = $pdo->prepare('INSERT INTO enrollments (app_id, user_id, enrollment_number, first_name, middle_name, last_name, address, contact_number, guardian_name, guardian_contact, grade_level, strand, status) VALUES (:app_id, :user_id, :enrollment_number, :first_name, :middle_name, :last_name, :address, :contact_number, :guardian_name, :guardian_contact, :grade_level, :strand, :status)');
                    
                    $status = 'pending_payment';
                    $stmt->bindParam(':app_id', $appId, PDO::PARAM_INT);
                    $stmt->bindParam(':user_id', $userId);
                    $stmt->bindParam(':enrollment_number', $enrollment_number, PDO::PARAM_STR);
                    $stmt->bindParam(':first_name', $first_name, PDO::PARAM_STR);
                    $stmt->bindParam(':middle_name', $middle_name, PDO::PARAM_STR);
                    $stmt->bindParam(':last_name', $last_name, PDO::PARAM_STR);
                    $stmt->bindParam(':address', $home_address, PDO::PARAM_STR);
                    $stmt->bindParam(':contact_number', $mobile_number, PDO::PARAM_STR);
                    $stmt->bindParam(':guardian_name', $guardian_name ?: ($father_name ?: $mother_name), PDO::PARAM_STR);
                    $stmt->bindParam(':guardian_contact', $guardian_contact ?: ($father_contact ?: $mother_contact), PDO::PARAM_STR);
                    // These will be filled by parent in next step for old students
                    $stmt->bindParam(':grade_level', $last_grade_level_completed, PDO::PARAM_STR);
                    $stmt->bindParam(':strand', '', PDO::PARAM_STR);
                    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
                    
                    if ($stmt->execute()) {
                        $enrollId = $pdo->lastInsertId();
                        $success = true;
                        $message = 'Old student enrollment submitted successfully. Please proceed to payment, then wait for cashier verification and registrar enrollment.';
                        // Redirect to payment page with the enrollment ID
                        header('Refresh: 3; url=/MI2/student/payment.php?enroll_id=' . urlencode($enrollId));
                    } else {
                        $message = 'Database error: Could not save enrollment.';
                    }
                }
            } catch (PDOException $e) {
                $message = 'Database error: ' . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Old Student Enrollment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            padding: 20px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        input, select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            box-sizing: border-box;
        }
        
        .row {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -10px;
        }
        
        .col-md-4, .col-md-6, .col-12 {
            padding: 0 10px;
            margin-bottom: 15px;
        }
        
        .col-md-4 {
            flex: 0 0 33.333%;
        }
        
        .col-md-6 {
            flex: 0 0 50%;
        }
        
        .col-12 {
            flex: 0 0 100%;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border: none;
            cursor: pointer;
            margin-right: 10px;
        }
        
        .btn:hover {
            background-color: #45a049;
        }
        
        .btn-outline-secondary {
            background-color: #6c757d;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        
        .alert-warning {
            color: #856404;
            background-color: #fff3cd;
            border-color: #ffeaa7;
        }
        
        .alert-info {
            color: #0c5460;
            background-color: #d1ecf1;
            border-color: #bee5eb;
        }
        
        hr {
            border: 0;
            border-top: 1px solid #eee;
            margin: 20px 0;
        }
        
        .d-grid {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>
    
    <div class="container">
        <div class="main-content">
            <h2>Old Student Enrollment</h2>
            <p>Enroll as an old student for the new school year.</p>
            
            <?php if ($message): ?>
                <div class="alert <?php echo $success ? 'alert-success' : 'alert-warning'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if (!$success): ?>
                <?php if (!$enrollmentActive): ?>
                    <div class="alert alert-warning">
                        <strong>Enrollment is currently not active.</strong> 
                        <?php if ($enrollmentPeriod): ?>
                            Enrollment for <?php echo htmlspecialchars($enrollmentPeriod['school_year'] ?? ''); ?> will be active from 
                            <?php echo htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['start_date'] ?? ''))); ?> to 
                            <?php echo htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['end_date'] ?? ''))); ?>.
                        <?php else: ?>
                            Please contact administration for more information about enrollment periods.
                        <?php endif; ?>
                    </div>
                <?php elseif ($alreadyEnrolled): ?>
                    <div class="alert alert-info">
                        <strong>You have already submitted an enrollment for the current school year.</strong> 
                        You can view your enrollment status in the <a href="/MI2/student/student_dashboard.php">student dashboard</a>.
                        Please contact administration if you need to make changes to your enrollment.
                    </div>
                <?php else: ?>
                    <?php if (!$existingInfo): ?>
                        <div class="alert alert-warning">No previous enrollment record found. Please contact administration.</div>
                    <?php else: ?>
                        <form method="post" id="enrollmentForm">
                            <div class="row">
                                <div class="col-12">
                                    <h3>STUDENT ENROLLMENT FORM</h3>
                                    <hr>
                                </div>
                                
                                <div class="col-md-4">
                                    <label>Last Name *</label>
                                    <input name="last_name" value="<?php echo htmlspecialchars($existingInfo['last_name'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-4">
                                    <label>First Name *</label>
                                    <input name="first_name" value="<?php echo htmlspecialchars($existingInfo['first_name'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-4">
                                    <label>Middle Name</label>
                                    <input name="middle_name" value="<?php echo htmlspecialchars($existingInfo['middle_name'] ?? ''); ?>">
                                </div>
                                
                                <div class="col-md-6">
                                    <label>Mobile Number *</label>
                                    <input name="mobile_number" value="<?php echo htmlspecialchars($existingInfo['contact_number'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label>Home Address *</label>
                                    <input name="home_address" value="<?php echo htmlspecialchars($existingInfo['address'] ?? ''); ?>" required>
                                </div>
                                
                                <div class="col-md-6">
                                    <label>Last Grade Level Completed *</label>
                                    <input name="last_grade_level_completed" value="<?php echo htmlspecialchars($existingInfo['grade_level'] ?? ''); ?>" required>
                                </div>
                                
                                <!-- Parent/Guardian Information -->
                                <div class="col-12">
                                    <h3>Parent/Guardian Information</h3>
                                    <hr>
                                </div>
                                
                                <!-- Mother -->
                                <div class="col-md-6">
                                    <label>Mother's Full Name *</label>
                                    <input name="mother_name" required>
                                </div>
                                <div class="col-md-6">
                                    <label>Mother's Contact Number *</label>
                                    <input name="mother_contact" required>
                                </div>
                                
                                <!-- Father -->
                                <div class="col-md-6">
                                    <label>Father's Full Name *</label>
                                    <input name="father_name" required>
                                </div>
                                <div class="col-md-6">
                                    <label>Father's Contact Number *</label>
                                    <input name="father_contact" required>
                                </div>
                                
                                <!-- Guardian (optional) -->
                                <div class="col-md-6">
                                    <label>Guardian's Full Name (if applicable)</label>
                                    <input name="guardian_name">
                                </div>
                                <div class="col-md-6">
                                    <label>Guardian's Contact Number (if applicable)</label>
                                    <input name="guardian_contact">
                                </div>
                                
                                <div class="col-12">
                                    <div class="alert alert-info">
                                        <strong>Note:</strong> As an old student, you will proceed directly to enrollment and payment. After submitting this form, you will be redirected to the payment page.
                                    </div>
                                    
                                    <div class="d-grid">
                                        <button type="submit" class="btn">Submit Enrollment</button>
                                        <a href="/MI2/student/student_dashboard.php" class="btn btn-outline-secondary">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function(){
        const form = document.getElementById('enrollmentForm');
        if (form) {
            form.addEventListener('submit', function (event) {
                let isValid = true;
                
                const requiredFields = [
                    'last_name', 'first_name', 'mobile_number', 'home_address', 
                    'last_grade_level_completed', 'mother_name', 'mother_contact', 
                    'father_name', 'father_contact'
                ];

                requiredFields.forEach(function (fieldName) {
                    const field = form.querySelector(`[name="${fieldName}"]`);
                    if (field && field.value.trim() === '') {
                        field.style.borderColor = 'red';
                        isValid = false;
                    } else if (field) {
                        field.style.borderColor = '#ddd';
                    }
                });

                if (!isValid) {
                    event.preventDefault();
                    alert('Please fill in all required fields.');
                }
            });
        }
    });
    </script>

    <?php require_once __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>