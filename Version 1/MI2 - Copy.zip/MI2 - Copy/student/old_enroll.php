<?php
// Old student enrollment - redirect to the new dedicated old student enrollment page
require_once __DIR__ . '/../includes/header.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Redirect to the dedicated old student enrollment page
header('Location: /MI2/student/old_student_enrollment.php');
exit;