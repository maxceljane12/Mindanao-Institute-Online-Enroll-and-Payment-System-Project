<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$userId = $_SESSION['user_id'] ?? null;
$appId = isset($_GET['app_id']) ? (int)$_GET['app_id'] : null;

$response = ['status' => null, 'app_id' => $appId];

if (!$appId) {
    echo json_encode($response);
    exit;
}

try {
    // If user is logged in, ensure application belongs to them (or user_id is NULL for guest applications)
    if ($userId) {
        $stmt = $pdo->prepare('SELECT id, status, user_id FROM applications WHERE id = :app_id AND (user_id = :user_id OR user_id IS NULL) LIMIT 1');
        $stmt->bindParam(':app_id', $appId, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_STR);
    } else {
        $stmt = $pdo->prepare('SELECT id, status FROM applications WHERE id = :app_id LIMIT 1');
        $stmt->bindParam(':app_id', $appId, PDO::PARAM_INT);
    }

    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        $response['status'] = $row['status'];
        
        // If the application is verified and belongs to a user, set auto-redirect flag
        if ($row['status'] === 'verified' && !empty($row['user_id']) && $userId) {
            $_SESSION['auto_redirect_app_id'] = $appId;
        }
    }
} catch (PDOException $e) {
    error_log("Database error in check_application_status.php: " . $e->getMessage());
    // Optionally, set an error status in the response, but typically for a simple check, null status is sufficient
}

echo json_encode($response);

?>