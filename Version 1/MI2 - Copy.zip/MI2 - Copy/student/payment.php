<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Check if user is student or parent
$userRole = strtolower($_SESSION['role'] ?? '');
$userId = $_SESSION['user_id'] ?? null;

if (!$userId || ($userRole !== 'student' && $userRole !== 'parent')) {
    header('Location: ../index.php');
    exit;
}

// For parents, we need to verify they're accessing a bill for their child
$isParent = ($userRole === 'parent');
$student_user_id = $userId; // Default to user's own ID
$pending_bills = [];
$paid_bills = [];
$_SESSION['success_message'] = $_SESSION['success_message'] ?? '';
$_SESSION['error_message'] = $_SESSION['error_message'] ?? '';

// Check if enroll_id is provided (for old students who just filled enrollment form)
$enroll_id = isset($_GET['enroll_id']) ? (int)$_GET['enroll_id'] : null;

// Check if we have an auto-enrollment flag for new students
$autoEnrollAppId = $_SESSION['auto_enroll_app_id'] ?? null;
if ($autoEnrollAppId && !$enroll_id) {
    // Look for the enrollment associated with this application
    try {
        $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE app_id = :app_id AND user_id = :user_id LIMIT 1");
        $stmt->execute(['app_id' => $autoEnrollAppId, 'user_id' => $userId]);
        $enrollment = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($enrollment) {
            $enroll_id = $enrollment['id'];
            // Clear the flag
            unset($_SESSION['auto_enroll_app_id']);
        }
    } catch (PDOException $e) {
        error_log("Error finding enrollment for auto-payment: " . $e->getMessage());
    }
}

try {
    // If enroll_id is provided, check if a bill exists for this enrollment
    if ($enroll_id) {
        // For parents, verify this enrollment was created by them (parents create enrollments for their children)
        if ($isParent) {
            // Check if this enrollment was created by this parent
            $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE id = :enroll_id AND user_id = :parent_id");
            $stmt->execute(['enroll_id' => $enroll_id, 'parent_id' => $userId]);
            $enrollment = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            // For students, verify this enrollment belongs to the current student
            $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE id = :enroll_id AND user_id = :user_id");
            $stmt->execute(['enroll_id' => $enroll_id, 'user_id' => $userId]);
            $enrollment = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        
        if ($enrollment) {
            // Check if a bill already exists for this enrollment
            $stmt = $pdo->prepare("SELECT bill_id FROM bills WHERE enrollment_id = :enroll_id");
            $stmt->execute(['enroll_id' => $enroll_id]);
            $existing_bill = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // If no bill exists, create one
            if (!$existing_bill) {
                // Fetch the latest enrollment fee
                $stmtFetchFee = $pdo->query('SELECT fee_name, amount, description FROM enrollment_fees ORDER BY created_at DESC LIMIT 1');
                $enrollmentFee = $stmtFetchFee->fetch(PDO::FETCH_ASSOC);
                
                if ($enrollmentFee) {
                    // Create a bill for this enrollment
                    $stmtInsertBill = $pdo->prepare('INSERT INTO bills (enrollment_id, bill_type, description, amount, due_date, status) VALUES (:enrollment_id, :bill_type, :description, :amount, :due_date, :status)');
                    $billType = 'enrollment_fee';
                    $dueDate = date('Y-m-d', strtotime('+7 days')); // Due date 7 days from now
                    $billStatus = 'pending';
                    
                    $stmtInsertBill->bindParam(':enrollment_id', $enroll_id, PDO::PARAM_INT);
                    $stmtInsertBill->bindParam(':bill_type', $billType);
                    $stmtInsertBill->bindParam(':description', $enrollmentFee['description']);
                    $stmtInsertBill->bindParam(':amount', $enrollmentFee['amount']);
                    $stmtInsertBill->bindParam(':due_date', $dueDate);
                    $stmtInsertBill->bindParam(':status', $billStatus);
                    $stmtInsertBill->execute();
                    
                    $_SESSION['success_message'] = 'Enrollment bill created successfully. Please proceed with payment at the cashier.';
                    
                    // For new students, set bill to go through cashier verification
                    $bill_id = $pdo->lastInsertId();
                    if (!$isParent) {
                        // Set bill to go through cashier verification
                        try {
                            // Update bill status to pending_verification
                            $stmtUpdateBill = $pdo->prepare("UPDATE bills SET status = 'pending_verification', payment_method = 'walk_in', updated_at = NOW() WHERE bill_id = :bill_id");
                            $stmtUpdateBill->bindParam(':bill_id', $bill_id, PDO::PARAM_INT);
                            $stmtUpdateBill->execute();
                            
                            $_SESSION['success_message'] = 'Enrollment bill created successfully. Please proceed to the cashier for payment verification.';
                        } catch (PDOException $e) {
                            error_log("Error setting bill to pending verification: " . $e->getMessage());
                            $_SESSION['error_message'] = "Could not set bill to pending verification. Please contact support.";
                        }
                    }
                } else {
                    $_SESSION['error_message'] = 'No enrollment fees defined. Please contact administration.';
                }
            }
        } else {
            $_SESSION['error_message'] = 'Invalid enrollment ID.';
        }
    }
    
    // Fetch all bills for the user
    if ($isParent) {
        // For parents, fetch bills for enrollments they created
        $stmt = $pdo->prepare("
            SELECT b.bill_id, b.enrollment_id, b.bill_type, b.description, b.amount, b.due_date, b.status, b.payment_method
            FROM bills b
            JOIN enrollments e ON b.enrollment_id = e.id
            WHERE e.user_id = :parent_id
            ORDER BY b.due_date ASC
        ");
        $stmt->execute(['parent_id' => $userId]);
    } else {
        // For students, fetch bills for their own enrollments
        $stmt = $pdo->prepare("
            SELECT b.bill_id, b.enrollment_id, b.bill_type, b.description, b.amount, b.due_date, b.status, b.payment_method
            FROM bills b
            JOIN enrollments e ON b.enrollment_id = e.id
            WHERE e.user_id = :student_user_id
            ORDER BY b.due_date ASC
        ");
        $stmt->execute(['student_user_id' => $userId]);
    }
    $all_bills = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($all_bills as $bill) {
        if ($bill['status'] === 'pending' || $bill['status'] === 'pending_verification') {
            $pending_bills[] = $bill;
        } elseif ($bill['status'] === 'paid') {
            $paid_bills[] = $bill;
        }
    }

} catch (PDOException $e) {
    error_log("Error fetching bills: " . $e->getMessage());
    $_SESSION['error_message'] .= "Database error: Could not fetch your bills. " . $e->getMessage();
}

?>
<main class="container hero">
  <div class="hero-content">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div style="flex:1;">
      <h3>Payment Center</h3>
      <p class="small-muted">Manage your bills and payments here.</p>

      <?php if (!empty($_SESSION['success_message'])): ?>
        <div class="alert alert-success" role="alert">
          <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
        </div>
      <?php endif; ?>

      <?php if (!empty($_SESSION['error_message'])): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
        </div>
      <?php endif; ?>

      <div class="card shadow-sm mt-4">
        <div class="card-header bg-white">
          <h5 class="mb-0">Pending / Awaiting Verification Bills</h5>
          <p class="mb-0 text-muted"><small>These bills need to be paid. All payments (both walk-in and GCash) require verification by cashier before enrollment.</small></p>
        </div>
        <div class="card-body">
          <?php if (empty($pending_bills)): ?>
            <p>No pending bills at this time.</p>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Bill ID</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Due Date</th>
                    <th>Method</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($pending_bills as $bill): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($bill['bill_id']); ?></td>
                      <td><?php echo htmlspecialchars($bill['bill_type']); ?></td>
                      <td><?php echo htmlspecialchars($bill['description'] ?? 'N/A'); ?></td>
                      <td>₱<?php echo number_format($bill['amount'], 2); ?></td>
                      <td><?php echo htmlspecialchars((new DateTime($bill['due_date']))->format('Y-m-d')); ?></td>
                      <td><?php echo htmlspecialchars(str_replace('_', ' ', $bill['payment_method'] ?? 'N/A')); ?></td>
                      <td><?php echo htmlspecialchars(str_replace('_', ' ', $bill['status'])); ?></td>
                      <td>
                        <?php if ($bill['status'] === 'pending' || $bill['status'] === 'pending_verification'): ?>
                            <button type="button" class="btn btn-sm btn-primary pay-bill-btn"
                                    data-bs-toggle="modal" data-bs-target="#paymentModal"
                                    data-bill-id="<?php echo $bill['bill_id']; ?>"
                                    data-bill-amount="<?php echo $bill['amount']; ?>">
                              Pay Now
                            </button>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>

            <!-- Payment Modal for selecting payment type -->
            <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="paymentModalLabel">Select Payment Method</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <form action="../PHP/process_student_payment.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                      <input type="hidden" name="bill_id" id="modalBillId">
                      <div class="mb-3">
                        <label for="payment_method_select" class="form-label">Payment Method</label>
                        <select class="form-select" id="payment_method_select" name="payment_method" required>
                          <option value="">Select Payment Method</option>
                          <option value="walk_in">Walk-in Payment</option>
                          <option value="gcash">GCash</option>
                        </select>
                      </div>
                      <div id="gcash_details" style="display:none;">
                        <div class="mb-3 text-center">
                            <p>Please scan the QR code to pay via GCash:</p>
                            <img src="/MI2/image/QR.jpg" alt="GCash QR Code" style="max-width: 200px; border: 1px solid #ddd; padding: 5px;">
                            <p class="mt-2"><small class="text-muted">After payment, please upload proof of payment below.</small></p>
                        </div>
                        <div class="mb-3">
                            <label for="receipt_upload" class="form-label">Upload Proof of Payment (GCash)</label>
                            <input class="form-control" type="file" id="receipt_upload" name="receipt_upload" accept="image/*">
                        </div>
                      </div>
                      <div id="walkin_details" style="display:none;">
                        <div class="alert alert-info">
                            <h6>Walk-in Payment Instructions</h6>
                            <p>For walk-in payments:</p>
                            <ol>
                                <li>Proceed to the cashier with this bill information</li>
                                <li>Make payment at the cashier counter</li>
                                <li>Your payment will be verified by the cashier</li>
                                <li>The registrar will then officially enroll you</li>
                            </ol>
                        </div>
                      </div>
                      <div class="mb-3">
                        <label for="modalPaymentAmount" class="form-label">Amount to Pay</label>
                        <input type="number" class="form-control" id="modalPaymentAmount" name="amount_paid" step="0.01" min="0.01" readonly>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                      <button type="submit" class="btn btn-primary" id="confirm_payment_btn">Confirm Payment</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>

            <script>
              document.addEventListener('DOMContentLoaded', function () {
                var paymentModal = document.getElementById('paymentModal');
                var paymentMethodSelect = document.getElementById('payment_method_select');
                var gcashDetails = document.getElementById('gcash_details');
                var confirmPaymentBtn = document.getElementById('confirm_payment_btn');
                var receiptUpload = document.getElementById('receipt_upload');

                paymentModal.addEventListener('show.bs.modal', function (event) {
                  var button = event.relatedTarget; // Button that triggered the modal
                  var billId = button.getAttribute('data-bill-id');
                  var billAmount = button.getAttribute('data-bill-amount');

                  var modalBillId = paymentModal.querySelector('#modalBillId');
                  var modalPaymentAmount = paymentModal.querySelector('#modalPaymentAmount');

                  modalBillId.value = billId;
                  modalPaymentAmount.value = parseFloat(billAmount).toFixed(2);
                  
                  // Reset form and hide gcash details on modal show
                  paymentMethodSelect.value = '';
                  gcashDetails.style.display = 'none';
                  receiptUpload.required = false; // Make receipt upload not required by default
                  confirmPaymentBtn.textContent = 'Confirm Payment';
                });

                paymentMethodSelect.addEventListener('change', function() {
                    // Hide both details sections first
                    gcashDetails.style.display = 'none';
                    document.getElementById('walkin_details').style.display = 'none';
                    
                    if (this.value === 'gcash') {
                        gcashDetails.style.display = 'block';
                        receiptUpload.required = true; // Make receipt upload required for GCash
                        confirmPaymentBtn.textContent = 'Done Paying';
                    } else if (this.value === 'walk_in') {
                        document.getElementById('walkin_details').style.display = 'block';
                        receiptUpload.required = false;
                        confirmPaymentBtn.textContent = 'Confirm Walk-in Payment';
                    } else {
                        receiptUpload.required = false;
                        confirmPaymentBtn.textContent = 'Confirm Payment';
                    }
                });
              });
            </script>

          <?php endif; ?>
        </div>
      </div>

      <div class="card shadow-sm mt-4">
        <div class="card-header bg-white">
          <h5 class="mb-0">Paid Bills</h5>
          <p class="mb-0 text-muted"><small>These bills have been paid and verified by the cashier. You can now be enrolled by the registrar.</small></p>
        </div>
        <div class="card-body">
          <?php if (empty($paid_bills)): ?>
            <p>No paid bills at this time.</p>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Bill ID</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Due Date</th>
                    <th>Method</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($paid_bills as $bill): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($bill['bill_id']); ?></td>
                      <td><?php echo htmlspecialchars($bill['bill_type']); ?></td>
                      <td><?php echo htmlspecialchars($bill['description'] ?? 'N/A'); ?></td>
                      <td>₱<?php echo number_format($bill['amount'], 2); ?></td>
                      <td><?php echo htmlspecialchars((new DateTime($bill['due_date']))->format('Y-m-d')); ?></td>
                      <td><?php echo htmlspecialchars(str_replace('_', ' ', $bill['payment_method'] ?? 'N/A')); ?></td>
                      <td><?php echo htmlspecialchars(str_replace('_', ' ', $bill['status'])); ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>
</main>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
