<?php
// Test script to verify walk-in payment workflow
require_once __DIR__ . '/includes/db.php';

echo "<h1>Walk-in Payment Workflow Test</h1>";

// Create a test enrollment
try {
    $pdo->beginTransaction();
    
    // Insert a test enrollment
    $stmt = $pdo->prepare("
        INSERT INTO enrollments (user_id, first_name, last_name, grade_level, status, created_at) 
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute(['2025-0001', 'John', 'Doe', 'Grade 11', 'pending_payment']);
    $enrollment_id = $pdo->lastInsertId();
    
    // Insert a test bill
    $stmt = $pdo->prepare("
        INSERT INTO bills (enrollment_id, bill_type, description, amount, due_date, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$enrollment_id, 'enrollment_fee', 'Test Enrollment Fee', 500.00, '2025-12-31', 'pending']);
    $bill_id = $pdo->lastInsertId();
    
    $pdo->commit();
    
    echo "<p>Test enrollment and bill created successfully:</p>";
    echo "<ul>";
    echo "<li>Enrollment ID: " . $enrollment_id . "</li>";
    echo "<li>Bill ID: " . $bill_id . "</li>";
    echo "</ul>";
    
    // Simulate walk-in payment processing
    echo "<h2>Simulating Walk-in Payment Processing...</h2>";
    
    $pdo->beginTransaction();
    
    // Update bill as paid with walk-in method and auto-verification
    $stmt = $pdo->prepare("
        UPDATE bills 
        SET status = 'paid', payment_method = 'walk_in', verified_by = 'SYSTEM_AUTO', updated_at = NOW() 
        WHERE bill_id = ?
    ");
    $stmt->execute([$bill_id]);
    
    // Create payment record
    $stmt = $pdo->prepare("
        INSERT INTO payments (bill_id, amount, payment_method, payment_date) 
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([$bill_id, 500.00, 'walk_in']);
    
    // Update enrollment status to paid
    $stmt = $pdo->prepare("
        UPDATE enrollments 
        SET status = 'paid' 
        WHERE id = ?
    ");
    $stmt->execute([$enrollment_id]);
    
    $pdo->commit();
    
    echo "<p>Walk-in payment processed successfully!</p>";
    
    // Verify the results
    echo "<h2>Verification Results:</h2>";
    
    // Check bill status
    $stmt = $pdo->prepare("SELECT * FROM bills WHERE bill_id = ?");
    $stmt->execute([$bill_id]);
    $bill = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<p>Bill Status:</p>";
    echo "<ul>";
    echo "<li>Status: " . $bill['status'] . "</li>";
    echo "<li>Payment Method: " . $bill['payment_method'] . "</li>";
    echo "<li>Verified By: " . $bill['verified_by'] . "</li>";
    echo "</ul>";
    
    // Check enrollment status
    $stmt = $pdo->prepare("SELECT * FROM enrollments WHERE id = ?");
    $stmt->execute([$enrollment_id]);
    $enrollment = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<p>Enrollment Status:</p>";
    echo "<ul>";
    echo "<li>Status: " . $enrollment['status'] . "</li>";
    echo "</ul>";
    
    // Check if this bill would appear in cashier verification
    $stmt = $pdo->prepare("
        SELECT b.*, e.first_name, e.last_name, e.enrollment_number, u.username as student_username
        FROM bills b
        JOIN enrollments e ON b.enrollment_id = e.id
        LEFT JOIN users u ON e.user_id = u.id
        WHERE b.status IN ('pending', 'pending_verification', 'cancelled')
           OR (b.status = 'paid' AND (b.verified_by IS NULL OR b.verified_by != 'SYSTEM_AUTO'))
        ORDER BY b.created_at DESC
    ");
    $stmt->execute();
    $bills_for_verification = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p>Bills that would appear in cashier verification:</p>";
    if (empty($bills_for_verification)) {
        echo "<p><strong>None - Walk-in payment correctly excluded from cashier verification!</strong></p>";
    } else {
        echo "<p>" . count($bills_for_verification) . " bill(s) found:</p>";
        foreach ($bills_for_verification as $b) {
            echo "<ul>";
            echo "<li>Bill ID: " . $b['bill_id'] . " - Status: " . $b['status'] . " - Verified By: " . $b['verified_by'] . "</li>";
            echo "</ul>";
        }
    }
    
    // Check if this enrollment would appear in registrar dashboard
    $stmt = $pdo->prepare("
        SELECT 
            e.id as enrollment_id,
            e.first_name,
            e.last_name,
            e.enrollment_number,
            b.amount,
            b.status as bill_status
        FROM 
            enrollments e
        JOIN 
            bills b ON e.id = b.enrollment_id
        WHERE 
            e.status = 'paid' AND b.status = 'paid'
        ORDER BY 
            e.created_at DESC
    ");
    $stmt->execute();
    $students_for_enrollment = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p>Students that would appear in registrar dashboard:</p>";
    if (empty($students_for_enrollment)) {
        echo "<p><strong>None found - Something is wrong!</strong></p>";
    } else {
        echo "<p>" . count($students_for_enrollment) . " student(s) found:</p>";
        foreach ($students_for_enrollment as $s) {
            echo "<ul>";
            echo "<li>Name: " . $s['first_name'] . " " . $s['last_name'] . " - Enrollment Status: paid - Bill Status: " . $s['bill_status'] . "</li>";
            echo "</ul>";
        }
        echo "<p><strong>Success! Student appears in registrar dashboard and ready for enrollment.</strong></p>";
    }
    
    // Clean up test data
    echo "<h2>Cleaning up test data...</h2>";
    $pdo->beginTransaction();
    
    // Delete payment record
    $stmt = $pdo->prepare("DELETE FROM payments WHERE bill_id = ?");
    $stmt->execute([$bill_id]);
    
    // Delete bill
    $stmt = $pdo->prepare("DELETE FROM bills WHERE bill_id = ?");
    $stmt->execute([$bill_id]);
    
    // Delete enrollment
    $stmt = $pdo->prepare("DELETE FROM enrollments WHERE id = ?");
    $stmt->execute([$enrollment_id]);
    
    $pdo->commit();
    
    echo "<p>Test data cleaned up successfully.</p>";
    
} catch (PDOException $e) {
    $pdo->rollBack();
    echo "<p>Error: " . $e->getMessage() . "</p>";
}

echo "<p><a href='/'>Return to Home</a></p>";
?>