--
-- Database: `mi`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE IF NOT EXISTS `applications` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` VARCHAR(64) DEFAULT NULL,
  `first_name` VARCHAR(150) NOT NULL,
  `last_name` VARCHAR(150) NOT NULL,
  `birthdate` DATE NOT NULL,
  `contact` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admission_note` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE IF NOT EXISTS `enrollments` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `app_id` INT NOT NULL,
  `user_id` VARCHAR(64) DEFAULT NULL,
  `enrollment_number` VARCHAR(64) DEFAULT NULL,
  `first_name` VARCHAR(150) DEFAULT NULL,
  `middle_name` VARCHAR(150) DEFAULT NULL,
  `last_name` VARCHAR(150) DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `contact_number` VARCHAR(255) DEFAULT NULL,
  `guardian_name` VARCHAR(255) DEFAULT NULL,
  `guardian_contact` VARCHAR(255) DEFAULT NULL,
  `grade_level` VARCHAR(64) DEFAULT NULL,
  `strand` VARCHAR(64) DEFAULT NULL,
  `program` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('pending_payment','paid','enrolled','cancelled') NOT NULL DEFAULT 'pending_payment',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_enrollments_app` FOREIGN KEY (`app_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE IF NOT EXISTS `bills` (
  `bill_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `enrollment_id` INT NOT NULL,
  `bill_type` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `amount` DECIMAL(10, 2) NOT NULL,
  `due_date` DATE,
  `status` ENUM('pending', 'paid', 'overdue', 'cancelled','pending_verification') NOT NULL DEFAULT 'pending',
  `verified_by` VARCHAR(20) NULL,
  `verification_note` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_bills_enrollment_id` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bills_verified_by` FOREIGN KEY (`verified_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enrollment_fees`
--

CREATE TABLE IF NOT EXISTS `enrollment_fees` (
  `fee_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `fee_name` VARCHAR(255) NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `school_year` VARCHAR(100) NOT NULL,
  `applicable_to_group` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(20) NOT NULL PRIMARY KEY,
  `first_name` VARCHAR(100) NOT NULL,
  `middle_name` VARCHAR(100) DEFAULT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `suffix` VARCHAR(16) DEFAULT NULL,
  `birthdate` DATE NOT NULL,
  `age` INT NOT NULL,
  `sex` VARCHAR(16) NOT NULL,
  `street` VARCHAR(255) NOT NULL,
  `barangay` VARCHAR(255) NOT NULL,
  `municipal` VARCHAR(255) NOT NULL,
  `province` VARCHAR(255) NOT NULL,
  `country` VARCHAR(128) NOT NULL,
  `zipcode` VARCHAR(16) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(32) NOT NULL,
  `security_question_1` VARCHAR(255) DEFAULT NULL,
  `answer_1` VARCHAR(255) DEFAULT NULL,
  `security_question_2` VARCHAR(255) DEFAULT NULL,
  `answer_2` VARCHAR(255) DEFAULT NULL,
  `security_question_3` VARCHAR(255) DEFAULT NULL,
  `answer_3` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_id_counter`
--

CREATE TABLE IF NOT EXISTS `user_id_counter` (
  `year` INT NOT NULL PRIMARY KEY,
  `counter` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_id_counter`
--

INSERT INTO `user_id_counter` (`year`, `counter`)
SELECT YEAR(CURDATE()), 0
WHERE NOT EXISTS (SELECT 1 FROM `user_id_counter` WHERE `year` = YEAR(CURDATE()));
