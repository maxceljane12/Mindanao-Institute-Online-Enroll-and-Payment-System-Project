<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'registrar') {
    header('Location: ../index.php');
    exit;
}
include __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/db.php';

$message = '';
$enrolled_students = [];
$students_by_year = [];

try {
    $stmt = $pdo->prepare("
        SELECT
            e.id as enrollment_id,
            e.first_name,
            e.middle_name,
            e.last_name,
            e.enrollment_number,
            e.grade_level,
            e.strand,
            e.program,
            e.status,
            e.created_at
        FROM
            enrollments e
        WHERE
            e.status IN ('enrolled', 'paid')
        ORDER BY
            e.grade_level ASC, e.last_name ASC, e.first_name ASC
    ");
    $stmt->execute();
    $enrolled_students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Group students by year level
    foreach ($enrolled_students as $student) {
        $year_level = $student['grade_level'];
        if (!isset($students_by_year[$year_level])) {
            $students_by_year[$year_level] = [];
        }
        $students_by_year[$year_level][] = $student;
    }
    
    // Sort year levels
    ksort($students_by_year);
    
} catch (PDOException $e) {
    $message = "Error fetching enrolled students: " . $e->getMessage();
}
?>

<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="fas fa-users"></i> Enrolled & Paid Students</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-danger" role="alert">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <?php if (empty($enrolled_students)): ?>
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle"></i> No students are currently enrolled or have paid.
                </div>
            <?php else: ?>
                <!-- Summary Card -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-chart-bar"></i> Student Status Summary</h5>
                        <p class="mb-0"><strong>Total Enrolled/Paid Students:</strong> <?= count($enrolled_students) ?></p>
                    </div>
                </div>

                <!-- Students by Year Level -->
                <div class="accordion" id="yearLevelAccordion">
                    <?php $index = 0; ?>
                    <?php foreach ($students_by_year as $year_level => $students): ?>
                        <div class="card mb-3">
                            <div class="card-header" id="heading<?= $index ?>">
                                <h5 class="mb-0">
                                    <button class="btn btn-link w-100 text-start d-flex justify-content-between align-items-center" 
                                            type="button" 
                                            data-bs-toggle="collapse" 
                                            data-bs-target="#collapse<?= $index ?>" 
                                            aria-expanded="<?= $index === 0 ? 'true' : 'false' ?>" 
                                            aria-controls="collapse<?= $index ?>">
                                        <span>
                                            <i class="fas fa-graduation-cap"></i> 
                                            <strong><?= htmlspecialchars($year_level) ?></strong>
                                        </span>
                                        <span class="badge bg-primary rounded-pill"><?= count($students) ?> students</span>
                                    </button>
                                </h5>
                            </div>

                            <div id="collapse<?= $index ?>" 
                                 class="collapse <?= $index === 0 ? 'show' : '' ?>" 
                                 aria-labelledby="heading<?= $index ?>" 
                                 data-bs-parent="#yearLevelAccordion">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Enrollment ID</th>
                                                    <th>Student Name</th>
                                                    <th>Enrollment Number</th>
                                                    <th>Strand</th>
                                                    <th>Program</th>
                                                    <th>Enrolled Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($students as $student): ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($student['enrollment_id']) ?></td>
                                                        <td><?= htmlspecialchars($student['first_name'] . ' ' . $student['middle_name'] . ' ' . $student['last_name']) ?></td>
                                                        <td><?= htmlspecialchars($student['enrollment_number'] ?? 'N/A') ?></td>
                                                        <td><?= htmlspecialchars($student['strand']) ?></td>
                                                        <td><?= htmlspecialchars($student['program'] ?? 'N/A') ?></td>
                                                        <td><?= date('M d, Y', strtotime($student['created_at'])) ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php $index++; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
