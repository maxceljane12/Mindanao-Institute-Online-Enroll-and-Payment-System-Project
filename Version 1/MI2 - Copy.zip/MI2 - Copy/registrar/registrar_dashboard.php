<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'registrar') {
    header('Location: ../index.php');
    exit;
}
require_once __DIR__ . '/../includes/db.php';

// Check if user is still active
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !$user['is_active']) {
        // User is deactivated, log them out
        session_destroy();
        header('Location: ../index.php?error=account_deactivated');
        exit;
    }
}

$message = '';
$students_to_enroll = [];
$enrolled_students_by_year = [];

try {
    // Fetch students who have paid and are ready for official enrollment
    $stmt = $pdo->query("
        SELECT 
            e.id as enrollment_id,
            e.first_name,
            e.last_name,
            e.enrollment_number,
            b.amount,
            b.status as bill_status
        FROM 
            enrollments e
        JOIN 
            bills b ON e.id = b.enrollment_id
        WHERE 
            e.status = 'paid' AND b.status = 'paid'
        ORDER BY 
            e.created_at DESC
    ");
    $students_to_enroll = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Handle enrollment form submission
    if (isset($_POST['enroll_student'])) {
        $enrollment_id = $_POST['enrollment_id'];
        
        try {
            $pdo->beginTransaction();
            
            // Update enrollment status to officially enrolled
            $stmt = $pdo->prepare("UPDATE enrollments SET status = 'enrolled' WHERE id = :enrollment_id");
            $stmt->execute(['enrollment_id' => $enrollment_id]);
            
            $pdo->commit();
            $message = "Student successfully enrolled!";
        } catch (PDOException $e) {
            $pdo->rollBack();
            $message = "Error enrolling student: " . $e->getMessage();
        }
    }

    // Fetch officially enrolled students grouped by year level
    $stmt = $pdo->query("
        SELECT
            e.id,
            e.first_name,
            e.middle_name,
            e.last_name,
            e.enrollment_number,
            e.grade_level
        FROM
            enrollments e
        JOIN
            users u ON e.user_id = u.id
        WHERE
            e.status = 'enrolled'
        ORDER BY
            e.grade_level, u.last_name, u.first_name
    ");
    $stmt->execute();
    $enrolled_students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($enrolled_students as $student) {
        $year_level = $student['grade_level'] ?: 'N/A';
        if (!isset($enrolled_students_by_year[$year_level])) {
            $enrolled_students_by_year[$year_level] = [];
        }
        $enrolled_students_by_year[$year_level][] = $student;
    }

} catch (PDOException $e) {
    $message .= " Error fetching enrolled students: " . $e->getMessage();
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mindanao Institute — Enrollment and Payment Management System</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Registrar Dashboard</h1>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-info" role="alert">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal">Students Ready for Enrollment</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($students_to_enroll)): ?>
                                <p class="text-muted">No students are currently waiting for official enrollment.</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Student Name</th>
                                                <th>Enrollment Number</th>
                                                <th>Amount Paid</th>
                                                <th>Bill Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($students_to_enroll as $student): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></td>
                                                    <td><?= htmlspecialchars($student['enrollment_number'] ?? 'N/A') ?></td>
                                                    <td>₱<?= htmlspecialchars(number_format($student['amount'], 2)) ?></td>
                                                    <td>
                                                        <span class="badge bg-success">
                                                            <?= htmlspecialchars(ucfirst(str_replace('_', ' ', $student['bill_status']))) ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <form method="POST" action="" class="d-inline">
                                                            <input type="hidden" name="enrollment_id" value="<?= $student['enrollment_id'] ?>">
                                                            <button type="submit" name="enroll_student" class="btn btn-sm btn-success">
                                                                <i class="fas fa-user-check"></i> Enroll Student
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal">Officially Enrolled Students by Year Level</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($enrolled_students_by_year)): ?>
                                <p class="text-muted">No students are currently officially enrolled.</p>
                            <?php else: ?>
                                <?php foreach ($enrolled_students_by_year as $year_level => $students): ?>
                                    <h5 class="mt-4"><?= htmlspecialchars($year_level) ?></h5>
                                    <div class="table-responsive mb-4">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Enrollment Number</th>
                                                    <th>Name</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($students as $student): ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($student['enrollment_number'] ?? 'N/A') ?></td>
                                                        <td><?= htmlspecialchars($student['first_name'] . ' ' . ($student['middle_name'] ? $student['middle_name'] . ' ' : '') . $student['last_name']) ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
