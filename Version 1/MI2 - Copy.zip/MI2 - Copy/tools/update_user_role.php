<?php
// tools/update_user_role.php
// Simple admin utility to update a user's role in the `users` table.
// WARNING: this script is intentionally minimal. Run only on a local/dev machine
// or protect it (HTTP auth / move outside webroot) before using in production.

require_once __DIR__ . '/../includes/db.php';

$allowedRoles = ['student','parent','cashier','registrar','admission','admin'];

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? ''); // username or id
    $by = $_POST['by'] ?? 'username'; // 'username' or 'id'
    $role = trim($_POST['role'] ?? '');

    if ($identifier === '' || $role === '') {
        $message = 'Missing identifier or role.';
    } elseif (!in_array(strtolower($role), $allowedRoles, true)) {
        $message = 'Invalid role. Allowed: ' . implode(', ', $allowedRoles);
    } else {
        if ($by === 'id') {
            $sql = 'UPDATE users SET role = ? WHERE id = ? LIMIT 1';
        } else {
            $sql = 'UPDATE users SET role = ? WHERE username = ? LIMIT 1';
        }

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $message = 'Prepare failed: ' . $conn->error;
        } else {
            $roleVal = strtolower($role);
            $stmt->bind_param('ss', $roleVal, $identifier);
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $message = 'Role updated successfully.';
                } else {
                    $message = 'No rows updated. Check identifier.';
                }
            } else {
                $message = 'Execute failed: ' . $stmt->error;
            }
            $stmt->close();
        }
    }
}

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Update User Role</title>
  <link href="/MI2/includes/bootstrap-placeholder.css" rel="stylesheet">
  <style>body{font-family:Arial,Helvetica,sans-serif;padding:18px}label{display:block;margin-top:8px}input,select{padding:6px;width:320px}button{margin-top:12px;padding:8px 12px}</style>
</head>
<body>
  <h2>Update User Role (Admin tool)</h2>
  <p style="color:#666">Run this locally or secure it before putting on a public server.</p>
  <?php if ($message): ?>
    <div style="padding:8px;border:1px solid #ddd;background:#f8f8f8;margin-bottom:10px"><?= htmlspecialchars($message) ?></div>
  <?php endif; ?>

  <form method="post">
    <label for="by">Identify by</label>
    <select name="by" id="by">
      <option value="username">Username</option>
      <option value="id">User ID</option>
    </select>

    <label for="identifier">Username or ID</label>
    <input id="identifier" name="identifier" required>

    <label for="role">New Role</label>
    <select id="role" name="role" required>
      <?php foreach ($allowedRoles as $r): ?>
        <option value="<?= htmlspecialchars($r) ?>"><?= htmlspecialchars(ucfirst($r)) ?></option>
      <?php endforeach; ?>
    </select>

    <div>
      <button type="submit">Update Role</button>
    </div>
  </form>

  <hr>
  <h4>Quick CLI SQL example</h4>
  <pre>UPDATE users SET role = 'student' WHERE username = 'jdoe';</pre>
</body>
</html>
