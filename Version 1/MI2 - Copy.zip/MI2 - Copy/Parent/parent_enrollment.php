<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Check if user is parent
if (!isset($_SESSION['user_id']) || strtolower($_SESSION['role']) !== 'parent') {
    header('Location: ../index.php');
    exit;
}

$userId = $_SESSION['user_id'];
$appId = isset($_GET['app_id']) ? (int)$_GET['app_id'] : null;
$message = '';
$success = false;
$enrollmentActive = false;
$enrollmentPeriod = null;

// Check if enrollment is currently active
try {
    $stmt = $pdo->query("SELECT * FROM enrollment_periods WHERE is_active = 1 LIMIT 1");
    $enrollmentPeriod = $stmt->fetch(PDO::FETCH_ASSOC);
    $enrollmentActive = !empty($enrollmentPeriod);
} catch (PDOException $e) {
    $message = 'Database error: ' . $e->getMessage();
}

// Pre-fill form if we're enrolling a verified application (ready for enrollment)
$approvedAppData = null;
$hasApprovedApplication = false;

// Only check for approved application if app_id is provided and valid
if ($appId && $appId > 0) {
    try {
        // Check if this application belongs to this parent and is verified (ready for enrollment)
        $stmt = $pdo->prepare("SELECT a.*, ad.* FROM applications a 
                              LEFT JOIN application_details ad ON a.id = ad.application_id 
                              WHERE a.id = :app_id AND a.user_id = :user_id AND a.status = 'verified' LIMIT 1");
        $stmt->bindParam(':app_id', $appId, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $approvedAppData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($approvedAppData) {
            $hasApprovedApplication = true;
            error_log("Approved application found: " . print_r($approvedAppData, true));
        } else {
            $message = '<div class="alert alert-warning">Invalid or unverified application. The application must be approved and verified by Admission before enrollment.</div>';
            $appId = null; // Reset to prevent enrollment
        }
    } catch (PDOException $e) {
        $message = '<div class="alert alert-danger">Database error: ' . $e->getMessage() . '</div>';
        $appId = null;
    }
} else {
    // No app_id provided, so this is a fresh enrollment
    $hasApprovedApplication = false;
    $approvedAppData = null;
}

// Debug: Log the status
error_log("Has approved application: " . ($hasApprovedApplication ? 'YES' : 'NO'));
error_log("App ID: " . $appId);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Debug: Log POST data
    error_log("POST data received: " . print_r($_POST, true));
    
    // Check if enrollment is active
    if (!$enrollmentActive) {
        $message = '<div class="alert alert-warning">Enrollment is currently not active. Please contact administration for more information.</div>';
    } else {
        // Get student type - check both possible field names
        $student_type = trim($_POST['student_type'] ?? ($_POST['student_type_select'] ?? ''));
        
        // Debug: Show what student type was received
        error_log("Student type received: " . $student_type);
        
        // For new students, collect all detailed application information
        if ($student_type === 'new') {
            // Personal Information
            $last_name = trim($_POST['last_name'] ?? '');
            $first_name = trim($_POST['first_name'] ?? '');
            $middle_name = trim($_POST['middle_name'] ?? '');
            $suffix = trim($_POST['suffix'] ?? '');
            $sex = trim($_POST['sex'] ?? '');
            $date_of_birth = $_POST['date_of_birth'] ?? null;
            $place_of_birth = trim($_POST['place_of_birth'] ?? '');
            $nationality = trim($_POST['nationality'] ?? '');
            $religion = trim($_POST['religion'] ?? '');
            $lrn = trim($_POST['lrn'] ?? '');
            
            // Contact Information
            $mobile_number = trim($_POST['mobile_number'] ?? '');
            $email_address = trim($_POST['email_address'] ?? '');
            $home_address = trim($_POST['home_address'] ?? '');
            $barangay = trim($_POST['barangay'] ?? '');
            $municipality = trim($_POST['municipality'] ?? '');
            $province = trim($_POST['province'] ?? '');
            $zip_code = trim($_POST['zip_code'] ?? '');
            
            // Application Type
            $application_type = trim($_POST['application_type'] ?? '');
            
            // Educational Background
            $last_school_attended = trim($_POST['last_school_attended'] ?? '');
            $school_address = trim($_POST['school_address'] ?? '');
            $last_grade_level_completed = trim($_POST['last_grade_level_completed'] ?? '');
            $year_completed = trim($_POST['year_completed'] ?? '');
            $awards_received = trim($_POST['awards_received'] ?? '');
            
            // Parent/Guardian Information - Mother
            $mother_name = trim($_POST['mother_name'] ?? '');
            $mother_contact = trim($_POST['mother_contact'] ?? '');
            $mother_occupation = trim($_POST['mother_occupation'] ?? '');
            
            // Parent/Guardian Information - Father
            $father_name = trim($_POST['father_name'] ?? '');
            $father_contact = trim($_POST['father_contact'] ?? '');
            $father_occupation = trim($_POST['father_occupation'] ?? '');
            
            // Parent/Guardian Information - Guardian
            $guardian_name = trim($_POST['guardian_name'] ?? '');
            $guardian_relationship = trim($_POST['guardian_relationship'] ?? '');
            $guardian_contact = trim($_POST['guardian_contact'] ?? '');
            $guardian_address = trim($_POST['guardian_address'] ?? '');
            
            // Emergency Contact
            $emergency_name = trim($_POST['emergency_name'] ?? '');
            $emergency_relationship = trim($_POST['emergency_relationship'] ?? '');
            $emergency_mobile = trim($_POST['emergency_mobile'] ?? '');
            $emergency_address = trim($_POST['emergency_address'] ?? '');

            $errors = [];
            if (empty($last_name)) $errors[] = 'Last name is required.';
            if (empty($first_name)) $errors[] = 'First name is required.';
            if (empty($sex)) $errors[] = 'Sex is required.';
            if (empty($date_of_birth)) $errors[] = 'Date of birth is required.';
            if (empty($mobile_number)) $errors[] = 'Mobile number is required.';
            if (empty($home_address)) $errors[] = 'Home address is required.';
            if (empty($barangay)) $errors[] = 'Barangay is required.';
            if (empty($municipality)) $errors[] = 'Municipality/City is required.';
            if (empty($province)) $errors[] = 'Province is required.';
            if (empty($mother_name)) $errors[] = 'Mother\'s name is required.';
            if (empty($mother_contact)) $errors[] = 'Mother\'s contact number is required.';
            if (empty($father_name)) $errors[] = 'Father\'s name is required.';
            if (empty($father_contact)) $errors[] = 'Father\'s contact number is required.';
            if (empty($emergency_name)) $errors[] = 'Emergency contact name is required.';
            if (empty($emergency_relationship)) $errors[] = 'Emergency contact relationship is required.';
            if (empty($emergency_mobile)) $errors[] = 'Emergency contact mobile number is required.';
            if (empty($emergency_address)) $errors[] = 'Emergency contact address is required.';
            if (empty($application_type)) $errors[] = 'Application type is required.';
            
            // For new students, require educational background
            if (empty($last_school_attended)) $errors[] = 'Last school attended is required for new students.';
            if (empty($last_grade_level_completed)) $errors[] = 'Last grade level completed is required for new students.';
            if (empty($year_completed)) $errors[] = 'Year completed is required for new students.';

            if (!empty($errors)) {
                $message = '<div class="alert alert-danger">' . implode('<br>', $errors) . '</div>';
            } else {
                try {
                    // Check if we're enrolling an approved application or creating a new one
                    if ($hasApprovedApplication && $approvedAppData) {
                        // Use the existing approved application
                        $appIdToUse = $appId;
                        // Update the application with any new information
                        $updateStmt = $pdo->prepare('UPDATE applications SET first_name = :first_name, last_name = :last_name, birthdate = :birthdate, contact = :contact WHERE id = :id');
                        $updateStmt->bindParam(':first_name', $first_name, PDO::PARAM_STR);
                        $updateStmt->bindParam(':last_name', $last_name, PDO::PARAM_STR);
                        $updateStmt->bindParam(':birthdate', $date_of_birth, PDO::PARAM_STR);
                        $updateStmt->bindParam(':contact', $mobile_number, PDO::PARAM_STR);
                        $updateStmt->bindParam(':id', $appId, PDO::PARAM_INT);
                        $updateStmt->execute();
                    } else {
                        // For new applications, create an application first
                        $stmt = $pdo->prepare('INSERT INTO applications (user_id, first_name, last_name, birthdate, contact, status) VALUES (:user_id, :first_name, :last_name, :birthdate, :contact, :status)');
                        $status = 'pending';
                        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
                        $stmt->bindParam(':first_name', $first_name, PDO::PARAM_STR);
                        $stmt->bindParam(':last_name', $last_name, PDO::PARAM_STR);
                        $stmt->bindParam(':birthdate', $date_of_birth, PDO::PARAM_STR);
                        $stmt->bindParam(':contact', $mobile_number, PDO::PARAM_STR);
                        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
                                        
                        if ($stmt->execute()) {
                            $appIdToUse = $pdo->lastInsertId();
                        } else {
                            $message = '<div class="alert alert-danger">Database error: Could not submit application.</div>';
                            $appIdToUse = null;
                        }
                    }
                    
                    if (isset($appIdToUse)) {
                        // Insert detailed application information
                        // For approved applications, update the existing details
                        if ($hasApprovedApplication && $approvedAppData) {
                            $detailStmt = $pdo->prepare('UPDATE application_details SET
                                middle_name = :middle_name, suffix = :suffix, place_of_birth = :place_of_birth, 
                                nationality = :nationality, religion = :religion, lrn = :lrn,
                                email_address = :email_address, home_address = :home_address, barangay = :barangay, 
                                municipality = :municipality, province = :province, zip_code = :zip_code,
                                application_type = :application_type, last_school_attended = :last_school_attended, 
                                school_address = :school_address, last_grade_level_completed = :last_grade_level_completed,
                                year_completed = :year_completed, awards_received = :awards_received, 
                                mother_name = :mother_name, mother_contact = :mother_contact, mother_occupation = :mother_occupation,
                                father_name = :father_name, father_contact = :father_contact, father_occupation = :father_occupation, 
                                guardian_name = :guardian_name, guardian_relationship = :guardian_relationship,
                                guardian_contact = :guardian_contact, guardian_address = :guardian_address, 
                                emergency_name = :emergency_name, emergency_relationship = :emergency_relationship,
                                emergency_mobile = :emergency_mobile, emergency_address = :emergency_address
                                WHERE application_id = :application_id');
                        } else {
                            $detailStmt = $pdo->prepare('INSERT INTO application_details (
                                application_id, middle_name, suffix, place_of_birth, nationality, religion, lrn,
                                email_address, home_address, barangay, municipality, province, zip_code,
                                application_type, last_school_attended, school_address, last_grade_level_completed,
                                year_completed, awards_received, mother_name, mother_contact, mother_occupation,
                                father_name, father_contact, father_occupation, guardian_name, guardian_relationship,
                                guardian_contact, guardian_address, emergency_name, emergency_relationship,
                                emergency_mobile, emergency_address
                            ) VALUES (
                                :application_id, :middle_name, :suffix, :place_of_birth, :nationality, :religion, :lrn,
                                :email_address, :home_address, :barangay, :municipality, :province, :zip_code,
                                :application_type, :last_school_attended, :school_address, :last_grade_level_completed,
                                :year_completed, :awards_received, :mother_name, :mother_contact, :mother_occupation,
                                :father_name, :father_contact, :father_occupation, :guardian_name, :guardian_relationship,
                                :guardian_contact, :guardian_address, :emergency_name, :emergency_relationship,
                                :emergency_mobile, :emergency_address
                            )');
                        }
                        
                        $detailStmt->bindParam(':application_id', $appIdToUse, PDO::PARAM_INT);
                        $detailStmt->bindParam(':middle_name', $middle_name, PDO::PARAM_STR);
                        $detailStmt->bindParam(':suffix', $suffix, PDO::PARAM_STR);
                        $detailStmt->bindParam(':place_of_birth', $place_of_birth, PDO::PARAM_STR);
                        $detailStmt->bindParam(':nationality', $nationality, PDO::PARAM_STR);
                        $detailStmt->bindParam(':religion', $religion, PDO::PARAM_STR);
                        $detailStmt->bindParam(':lrn', $lrn, PDO::PARAM_STR);
                        $detailStmt->bindParam(':email_address', $email_address, PDO::PARAM_STR);
                        $detailStmt->bindParam(':home_address', $home_address, PDO::PARAM_STR);
                        $detailStmt->bindParam(':barangay', $barangay, PDO::PARAM_STR);
                        $detailStmt->bindParam(':municipality', $municipality, PDO::PARAM_STR);
                        $detailStmt->bindParam(':province', $province, PDO::PARAM_STR);
                        $detailStmt->bindParam(':zip_code', $zip_code, PDO::PARAM_STR);
                        $detailStmt->bindParam(':application_type', $application_type, PDO::PARAM_STR);
                        $detailStmt->bindParam(':last_school_attended', $last_school_attended, PDO::PARAM_STR);
                        $detailStmt->bindParam(':school_address', $school_address, PDO::PARAM_STR);
                        $detailStmt->bindParam(':last_grade_level_completed', $last_grade_level_completed, PDO::PARAM_STR);
                        $detailStmt->bindParam(':year_completed', $year_completed, PDO::PARAM_STR);
                        $detailStmt->bindParam(':awards_received', $awards_received, PDO::PARAM_STR);
                        $detailStmt->bindParam(':mother_name', $mother_name, PDO::PARAM_STR);
                        $detailStmt->bindParam(':mother_contact', $mother_contact, PDO::PARAM_STR);
                        $detailStmt->bindParam(':mother_occupation', $mother_occupation, PDO::PARAM_STR);
                        $detailStmt->bindParam(':father_name', $father_name, PDO::PARAM_STR);
                        $detailStmt->bindParam(':father_contact', $father_contact, PDO::PARAM_STR);
                        $detailStmt->bindParam(':father_occupation', $father_occupation, PDO::PARAM_STR);
                        $detailStmt->bindParam(':guardian_name', $guardian_name, PDO::PARAM_STR);
                        $detailStmt->bindParam(':guardian_relationship', $guardian_relationship, PDO::PARAM_STR);
                        $detailStmt->bindParam(':guardian_contact', $guardian_contact, PDO::PARAM_STR);
                        $detailStmt->bindParam(':guardian_address', $guardian_address, PDO::PARAM_STR);
                        $detailStmt->bindParam(':emergency_name', $emergency_name, PDO::PARAM_STR);
                        $detailStmt->bindParam(':emergency_relationship', $emergency_relationship, PDO::PARAM_STR);
                        $detailStmt->bindParam(':emergency_mobile', $emergency_mobile, PDO::PARAM_STR);
                        $detailStmt->bindParam(':emergency_address', $emergency_address, PDO::PARAM_STR);
                        
                        if ($detailStmt->execute()) {
                            $success = true;
                            if ($hasApprovedApplication && $approvedAppData) {
                                // For approved applications, redirect to enrollment form directly
                                $message = '<div class="alert alert-success">Application details updated successfully. Proceeding to enrollment...</div>';
                                // Redirect to enrollment form with the app_id
                                header('Refresh: 3; url=/MI2/student/enrollment_form.php?app_id=' . urlencode($appId));
                                exit;
                            } else {
                                // For new applications, inform parent to wait for admission approval
                                $message = '<div class="alert alert-success">New student application submitted successfully. Please wait for admission verification before proceeding to enrollment and payment.</div>';
                            }
                        } else {
                            $message = '<div class="alert alert-danger">Database error: Could not save application details.</div>';
                        }
                    } else {
                        $message = '<div class="alert alert-danger">Database error: Could not submit application.</div>';
                    }
                } catch (PDOException $e) {
                    $message = '<div class="alert alert-danger">Database error: ' . $e->getMessage() . '</div>';
                }
            }
        } 
        // For old students, only collect enrollment information
        else if ($student_type === 'old') {
            // ... (old student code remains the same)
            // [Keep the existing old student code here]
        } else {
            $message = '<div class="alert alert-danger">Please select a student type (new or old).</div>';
        }
    }
}
?>

<main class="container hero">
  <div class="hero-content">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div style="flex:1;">
      <h3>Parent Student Enrollment</h3>
      <p class="small-muted">Enroll a student as a parent.</p>
      
      <!-- Multiple Children Notice -->
      <div class="alert alert-info">
        <i class="fas fa-info-circle"></i> <strong>Multiple Children Enrollment:</strong> 
        You can enroll multiple children individually. Each child will have their own enrollment record and payment. 
        After completing this form, you can return to enroll another child.
      </div>
      
      <?= $message ?>

      <?php if (!$success): ?>
        <?php if (!$enrollmentActive): ?>
          <div class="alert alert-warning">
            <strong>Enrollment is currently not active.</strong> 
            <?php if ($enrollmentPeriod): ?>
              Enrollment for <?= htmlspecialchars($enrollmentPeriod['school_year']) ?> will be active from 
              <?= htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['start_date']))) ?> to 
              <?= htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['end_date']))) ?>.
            <?php else: ?>
              Please contact administration for more information about enrollment periods.
            <?php endif; ?>
          </div>
        <?php else: ?>
          <form method="post" id="enrollmentForm" action="">
            <input type="hidden" name="student_type" id="studentTypeHidden" value="<?= $hasApprovedApplication ? 'new' : '' ?>">
            <div class="row g-3">
              <?php if (!$hasApprovedApplication): ?>
              <div class="col-md-12">
                <label class="form-label">Student Type *</label>
                <select name="student_type_select" class="form-control" id="studentType" required>
                  <option value="">-- Select Student Type --</option>
                  <option value="new">New Student</option>
                  <option value="old">Old Student</option>
                </select>
              </div>
              <?php endif; ?>
              
              <!-- Application Form (only for new students or approved applications) -->
              <div id="applicationForm" style="display: <?= $hasApprovedApplication ? 'block' : 'none' ?>;">
                <?php if ($hasApprovedApplication): ?>
                <div class="alert alert-info">
                  <strong>Approved Application Detected:</strong> You are enrolling a student whose application has been approved by Admission.
                  Please review and update the information below as needed.
                </div>
                <?php else: ?>
                <div class="alert alert-primary">
                  <strong>New Student Application:</strong> Please fill out all required information for the new student application.
                </div>
                <?php endif; ?>
                
                <!-- A. APPLICANT INFORMATION -->
                <div class="col-12">
                  <h4 class="mt-4">A. APPLICANT INFORMATION</h4>
                  <hr>
                </div>
                
                <!-- 1. Personal Information -->
                <div class="col-12">
                  <h5>1. Personal Information</h5>
                </div>
                
                <div class="col-md-4">
                  <label class="form-label">Last Name *</label>
                  <input name="last_name" class="form-control" required value="<?= htmlspecialchars($approvedAppData['last_name'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                  <label class="form-label">First Name *</label>
                  <input name="first_name" class="form-control" required value="<?= htmlspecialchars($approvedAppData['first_name'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                  <label class="form-label">Middle Name</label>
                  <input name="middle_name" class="form-control" value="<?= htmlspecialchars($approvedAppData['middle_name'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                  <label class="form-label">Suffix (Jr./III)</label>
                  <input name="suffix" class="form-control" value="<?= htmlspecialchars($approvedAppData['suffix'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                  <label class="form-label">Sex *</label>
                  <select name="sex" class="form-control" required>
                    <option value="">-- Select --</option>
                    <option value="Male" <?= isset($approvedAppData['sex']) && $approvedAppData['sex'] === 'Male' ? 'selected' : '' ?>>Male</option>
                    <option value="Female" <?= isset($approvedAppData['sex']) && $approvedAppData['sex'] === 'Female' ? 'selected' : '' ?>>Female</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="form-label">Date of Birth *</label>
                  <input type="date" name="date_of_birth" class="form-control" required value="<?= htmlspecialchars($approvedAppData['birthdate'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Place of Birth</label>
                  <input name="place_of_birth" class="form-control" value="<?= htmlspecialchars($approvedAppData['place_of_birth'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Nationality</label>
                  <input name="nationality" class="form-control" value="<?= htmlspecialchars($approvedAppData['nationality'] ?? 'Filipino') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Religion</label>
                  <input name="religion" class="form-control" value="<?= htmlspecialchars($approvedAppData['religion'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Learner Reference Number (LRN)</label>
                  <input name="lrn" class="form-control" value="<?= htmlspecialchars($approvedAppData['lrn'] ?? '') ?>">
                </div>
                
                <!-- 2. Contact Information -->
                <div class="col-12">
                  <h5 class="mt-4">2. Contact Information</h5>
                </div>
                
                <div class="col-md-6">
                  <label class="form-label">Mobile Number *</label>
                  <input name="mobile_number" class="form-control" required value="<?= htmlspecialchars($approvedAppData['contact'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Email Address</label>
                  <input type="email" name="email_address" class="form-control" value="<?= htmlspecialchars($approvedAppData['email_address'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Home Address *</label>
                  <input name="home_address" class="form-control" required value="<?= htmlspecialchars($approvedAppData['home_address'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Barangay *</label>
                  <input name="barangay" class="form-control" required value="<?= htmlspecialchars($approvedAppData['barangay'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                  <label class="form-label">Municipality/City *</label>
                  <input name="municipality" class="form-control" required value="<?= htmlspecialchars($approvedAppData['municipality'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                  <label class="form-label">Province *</label>
                  <input name="province" class="form-control" required value="<?= htmlspecialchars($approvedAppData['province'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                  <label class="form-label">ZIP Code</label>
                  <input name="zip_code" class="form-control" value="<?= htmlspecialchars($approvedAppData['zip_code'] ?? '') ?>">
                </div>
                
                <!-- B. APPLICATION TYPE -->
                <div class="col-12">
                  <h4 class="mt-4">B. APPLICATION TYPE</h4>
                  <hr>
                  <p>(Select one)</p>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="application_type" value="New Student" id="new_student" required <?= isset($approvedAppData['application_type']) && $approvedAppData['application_type'] === 'New Student' ? 'checked' : '' ?>>
                    <label class="form-check-label" for="new_student">New Student</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="application_type" value="Transferee" id="transferee" <?= isset($approvedAppData['application_type']) && $approvedAppData['application_type'] === 'Transferee' ? 'checked' : '' ?>>
                    <label class="form-check-label" for="transferee">Transferee</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="application_type" value="Returning / Balik-Aral" id="balik_aral" <?= isset($approvedAppData['application_type']) && $approvedAppData['application_type'] === 'Returning / Balik-Aral' ? 'checked' : '' ?>>
                    <label class="form-check-label" for="balik_aral">Returning / Balik-Aral</label>
                  </div>
                </div>
                
                <!-- C. EDUCATIONAL BACKGROUND -->
                <div class="col-12">
                  <h4 class="mt-4">C. EDUCATIONAL BACKGROUND</h4>
                  <hr>
                </div>
                
                <div class="col-md-6">
                  <label class="form-label">Last School Attended *</label>
                  <input name="last_school_attended" class="form-control" required value="<?= htmlspecialchars($approvedAppData['last_school_attended'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">School Address</label>
                  <input name="school_address" class="form-control" value="<?= htmlspecialchars($approvedAppData['school_address'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Last Grade Level Completed *</label>
                  <input name="last_grade_level_completed" class="form-control" required value="<?= htmlspecialchars($approvedAppData['last_grade_level_completed'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Year Completed *</label>
                  <input name="year_completed" class="form-control" required value="<?= htmlspecialchars($approvedAppData['year_completed'] ?? '') ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Awards / Honors Received (if any)</label>
                  <input name="awards_received" class="form-control" value="<?= htmlspecialchars($approvedAppData['awards_received'] ?? '') ?>">
                </div>
                
                <!-- D. PARENT / GUARDIAN INFORMATION -->
                <div class="col-12">
                  <h4 class="mt-4">D. PARENT / GUARDIAN INFORMATION</h4>
                  <hr>
                </div>
                
                <!-- Mother -->
                <div class="col-12">
                  <h5>1. Mother</h5>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Full Name *</label>
                  <input name="mother_name" class="form-control" required value="<?= htmlspecialchars($approvedAppData['mother_name'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Contact Number *</label>
                  <input name="mother_contact" class="form-control" required value="<?= htmlspecialchars($approvedAppData['mother_contact'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Occupation</label>
                  <input name="mother_occupation" class="form-control" value="<?= htmlspecialchars($approvedAppData['mother_occupation'] ?? '') ?>">
                </div>
                
                <!-- Father -->
                <div class="col-12">
                  <h5 class="mt-4">2. Father</h5>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Full Name *</label>
                  <input name="father_name" class="form-control" required value="<?= htmlspecialchars($approvedAppData['father_name'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Contact Number *</label>
                  <input name="father_contact" class="form-control" required value="<?= htmlspecialchars($approvedAppData['father_contact'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Occupation</label>
                  <input name="father_occupation" class="form-control" value="<?= htmlspecialchars($approvedAppData['father_occupation'] ?? '') ?>">
                </div>
                
                <!-- Guardian -->
                <div class="col-12">
                  <h5 class="mt-4">3. Guardian (if not living with parents)</h5>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Full Name</label>
                  <input name="guardian_name" class="form-control" value="<?= htmlspecialchars($approvedAppData['guardian_name'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Relationship to Applicant</label>
                  <input name="guardian_relationship" class="form-control" value="<?= htmlspecialchars($approvedAppData['guardian_relationship'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Contact Number</label>
                  <input name="guardian_contact" class="form-control" value="<?= htmlspecialchars($approvedAppData['guardian_contact'] ?? '') ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Address</label>
                  <input name="guardian_address" class="form-control" value="<?= htmlspecialchars($approvedAppData['guardian_address'] ?? '') ?>">
                </div>
                
                <!-- E. EMERGENCY CONTACT -->
                <div class="col-12">
                  <h4 class="mt-4">E. EMERGENCY CONTACT</h4>
                  <hr>
                </div>
                
                <div class="col-md-6">
                  <label class="form-label">Name *</label>
                  <input name="emergency_name" class="form-control" required value="<?= htmlspecialchars($approvedAppData['emergency_name'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Relationship *</label>
                  <input name="emergency_relationship" class="form-control" required value="<?= htmlspecialchars($approvedAppData['emergency_relationship'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Mobile Number *</label>
                  <input name="emergency_mobile" class="form-control" required value="<?= htmlspecialchars($approvedAppData['emergency_mobile'] ?? '') ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Address *</label>
                  <input name="emergency_address" class="form-control" required value="<?= htmlspecialchars($approvedAppData['emergency_address'] ?? '') ?>">
                </div>
              </div>
              
              <!-- Enrollment Form (only for old students) -->
              <div id="enrollmentFormFields" style="display: none;">
                <!-- ... (old student form fields remain the same) ... -->
              </div>
              
              <div class="col-12">
                <div class="alert alert-info">
                  <strong>Note:</strong> 
                  <ul>
                    <li><strong>New Student</strong>: Will go through the detailed application process and wait for admission approval</li>
                    <li><strong>Old Student</strong>: Will proceed directly to enrollment and payment</li>
                  </ul>
                </div>
              </div>

              <div class="col-12 d-flex justify-content-end">
                <button class="btn btn-primary" type="submit" id="submitButton">
                  <?= $hasApprovedApplication ? 'Update and Proceed to Enrollment' : 'Submit Application' ?>
                </button>
              </div>
            </div>
          </form>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</main>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function(){
  const studentType = document.getElementById('studentType');
  const studentTypeHidden = document.getElementById('studentTypeHidden');
  const applicationForm = document.getElementById('applicationForm');
  const enrollmentFormFields = document.getElementById('enrollmentFormFields');
  const form = document.getElementById('enrollmentForm');
  
  // If we have an approved application, automatically show the new student form
  <?php if ($hasApprovedApplication): ?>
    if (applicationForm) {
      applicationForm.style.display = 'block';
    }
    // Set the student type to 'new' since we're enrolling an approved new student application
    if (studentTypeHidden) {
      studentTypeHidden.value = 'new';
    }
  <?php endif; ?>
  
  // Show appropriate form based on student type
  if (studentType) {
    studentType.addEventListener('change', function() {
      const selectedValue = this.value;
      if (studentTypeHidden) {
        studentTypeHidden.value = selectedValue;
      }
      
      if (selectedValue === 'new') {
        if (applicationForm) applicationForm.style.display = 'block';
        if (enrollmentFormFields) enrollmentFormFields.style.display = 'none';
      } else if (selectedValue === 'old') {
        if (applicationForm) applicationForm.style.display = 'none';
        if (enrollmentFormFields) enrollmentFormFields.style.display = 'block';
      } else {
        if (applicationForm) applicationForm.style.display = 'none';
        if (enrollmentFormFields) enrollmentFormFields.style.display = 'none';
      }
    });
  }
  
  // Form validation
  if (form) {
    form.addEventListener('submit', function (event) {
        console.log('Form submission started...');
        
        // Get the current student type
        const studentTypeValue = studentType ? studentType.value : 'new';
        
        // Validate student type selection (only if student type selector is visible)
        if (studentType && !studentTypeValue) {
            event.preventDefault();
            studentType.classList.add('is-invalid');
            alert('Please select a student type (new or old).');
            studentType.focus();
            return false;
        }
        
        // Remove any previous invalid classes
        const allFields = form.querySelectorAll('.is-invalid');
        allFields.forEach(field => field.classList.remove('is-invalid'));
        
        // Validate visible required fields
        let isValid = true;
        let firstInvalidField = null;
        
        if (studentTypeValue === 'new' && applicationForm) {
            // Validate new student form
            const requiredFields = applicationForm.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('is-invalid');
                    isValid = false;
                    if (!firstInvalidField) {
                        firstInvalidField = field;
                    }
                }
            });
        } else if (studentTypeValue === 'old' && enrollmentFormFields) {
            // Validate old student form
            const requiredFields = enrollmentFormFields.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('is-invalid');
                    isValid = false;
                    if (!firstInvalidField) {
                        firstInvalidField = field;
                    }
                }
            });
        }
        
        if (!isValid) {
            event.preventDefault();
            if (firstInvalidField) {
                firstInvalidField.scrollIntoView({ behavior: 'smooth', block: 'center' });
                firstInvalidField.focus();
            }
            alert('Please fill in all required fields.');
            return false;
        }
        
        // If validation passes, show loading state
        const submitButton = document.getElementById('submitButton');
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent = 'Submitting...';
        }
        
        return true;
    });
  }
});
</script>