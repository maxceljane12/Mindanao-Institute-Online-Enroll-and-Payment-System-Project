<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'parent') {
	header('Location: ../index.php');
	exit;
}

require_once __DIR__ . '/../includes/db.php';

// Check if user is still active
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !$user['is_active']) {
        // User is deactivated, log them out
        session_destroy();
        header('Location: ../index.php?error=account_deactivated');
        exit;
    }
}

$pendingApplications = [];
$approvedApplications = [];
$verifiedApplications = [];
$parentEnrollments = [];
$message = '';
$enrollmentActive = false;
$enrollmentPeriod = null;

// Check if enrollment is currently active
try {
    $stmt = $pdo->query("SELECT * FROM enrollment_periods WHERE is_active = 1 LIMIT 1");
    $enrollmentPeriod = $stmt->fetch(PDO::FETCH_ASSOC);
    $enrollmentActive = !empty($enrollmentPeriod);
} catch (PDOException $e) {
    $message = 'Database error: ' . $e->getMessage();
}

try {
    // Fetch pending applications
    $stmt = $pdo->prepare("
        SELECT 
            id,
            first_name,
            last_name,
            birthdate,
            contact,
            status,
            created_at
        FROM applications 
        WHERE user_id = :parent_id 
        AND status = 'pending'
        ORDER BY created_at DESC
    ");
    $stmt->execute(['parent_id' => $_SESSION['user_id']]);
    $pendingApplications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Fetch approved applications (awaiting verification)
    $stmt = $pdo->prepare("
        SELECT 
            id,
            first_name,
            last_name,
            birthdate,
            contact,
            status,
            created_at
        FROM applications 
        WHERE user_id = :parent_id 
        AND status = 'approved'
        ORDER BY created_at DESC
    ");
    $stmt->execute(['parent_id' => $_SESSION['user_id']]);
    $approvedApplications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Fetch verified applications that are ready for enrollment
    $stmt = $pdo->prepare("
        SELECT 
            id,
            first_name,
            last_name,
            birthdate,
            contact,
            status,
            created_at
        FROM applications 
        WHERE user_id = :parent_id 
        AND status = 'verified'
        ORDER BY created_at DESC
    ");
    $stmt->execute(['parent_id' => $_SESSION['user_id']]);
    $verifiedApplications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Fetch parent's enrollments with payment info
    $stmt = $pdo->prepare("
        SELECT 
            e.id,
            e.enrollment_number,
            e.first_name,
            e.last_name,
            e.grade_level,
            e.status,
            e.created_at,
            b.bill_id,
            b.amount,
            b.status as payment_status,
            b.receipt_path
        FROM enrollments e
        LEFT JOIN bills b ON e.id = b.enrollment_id
        WHERE e.user_id = :parent_id
        ORDER BY e.created_at DESC
    ");
    $stmt->execute(['parent_id' => $_SESSION['user_id']]);
    $parentEnrollments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // Handle error silently
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mindanao Institute — Enrollment and Payment Management System</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<main class="container-fluid">
	<div class="row">
		<?php include __DIR__ . '/../includes/sidebar.php'; ?>
		<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mi-dashboard-content">
			<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
				<h1 class="h2">Parent Dashboard</h1>
				<div class="btn-toolbar mb-2 mb-md-0">
					<div class="btn-group me-2">
						<?php if ($enrollmentActive): ?>
							<a href="/MI2/Parent/parent_enrollment.php" class="btn btn-sm btn-outline-primary">
								<i class="fas fa-user-plus"></i> Enroll a Student
							</a>
						<?php endif; ?>
					</div>
				</div>
			</div>

			<?php if ($message): ?>
				<div class="alert alert-warning"><?= htmlspecialchars($message) ?></div>
			<?php endif; ?>
			
			<!-- Enrollment Flow Indicator -->
			<div class="card mb-4">
				<div class="card-header bg-info text-white">
					<h5 class="my-0"><i class="fas fa-project-diagram"></i> Enrollment Process Flow</h5>
				</div>
				<div class="card-body">
					<div class="row text-center mb-3">
						<div class="col-md-4 mb-3">
							<div class="p-3 bg-light rounded">
								<i class="fas fa-file-alt fa-2x text-primary mb-2"></i>
								<h6>1. Registration</h6>
								<p class="small mb-0">Fill out registration form</p>
							</div>
						</div>
						<div class="col-md-4 mb-3">
							<div class="p-3 bg-light rounded">
								<i class="fas fa-money-bill-wave fa-2x text-info mb-2"></i>
								<h6>2. Payment</h6>
								<p class="small mb-0">Proceed to payment</p>
							</div>
						</div>
						<div class="col-md-4 mb-3">
							<div class="p-3 bg-light rounded">
								<i class="fas fa-user-check fa-2x text-success mb-2"></i>
								<h6>3. Verification</h6>
								<p class="small mb-0">Registrar verification for enrollment</p>
							</div>
						</div>
					</div>
					<p class="text-muted small mb-0">For new students: Application → Admission Verification → Enrollment → Payment</p>
					<p class="text-muted small mb-0">For old students: Registration → Payment → Registrar Verification</p>
				</div>
				</div>
			</div>
			
			<?php if (!$enrollmentActive): ?>
				<div class="alert alert-warning">
					<strong>Enrollment is currently not active.</strong> 
					<?php if ($enrollmentPeriod): ?>
						Enrollment for <?= htmlspecialchars($enrollmentPeriod['school_year']) ?> will be active from 
						<?= htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['start_date']))) ?> to 
						<?= htmlspecialchars(date('F j, Y', strtotime($enrollmentPeriod['end_date']))) ?>.
					<?php else: ?>
						Please contact administration for more information about enrollment periods.
					<?php endif; ?>
				</div>
			<?php endif; ?>
			
			<div class="row">
				<div class="col-md-12">
					<div class="card mb-4 shadow-sm">
						<div class="card-header">
							<h5 class="my-0 fw-normal">Pending Applications</h5>
						</div>
						<div class="card-body">
							<?php if (empty($pendingApplications)): ?>
								<p class="text-muted">You don't have any pending applications.</p>
							<?php else: ?>
								<div class="table-responsive">
									<table class="table table-striped table-hover">
										<thead>
											<tr>
												<th>Child Name</th>
												<th>Birthdate</th>
												<th>Contact</th>
												<th>Status</th>
												<th>Date</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($pendingApplications as $application): ?>
												<tr>
													<td><?= htmlspecialchars($application['first_name'] . ' ' . $application['last_name']) ?></td>
													<td><?= htmlspecialchars(date('M j, Y', strtotime($application['birthdate']))) ?></td>
													<td><?= htmlspecialchars($application['contact']) ?></td>
													<td>
														<?php
															$status = $application['status'];
															$statusClass = '';
															switch ($status) {
																case 'pending':
																	$statusClass = 'badge bg-warning';
																	$statusText = 'Pending Review';
																	break;
																default:
																	$statusClass = 'badge bg-secondary';
																	$statusText = ucfirst($status);
															}
														?>
														<span class="<?= $statusClass ?>"><?= htmlspecialchars($statusText) ?></span>
													</td>
													<td><?= htmlspecialchars(date('M j, Y', strtotime($application['created_at']))) ?></td>
													<td>
														<a href="/MI2/student/application_status.php?app_id=<?= $application['id'] ?>" class="btn btn-sm btn-outline-primary">Check Status</a>
													</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<div class="card mb-4 shadow-sm">
						<div class="card-header">
							<h5 class="my-0 fw-normal">Approved Applications - Awaiting Verification</h5>
						</div>
						<div class="card-body">
							<?php if (empty($approvedApplications)): ?>
								<p class="text-muted">You don't have any applications awaiting verification.</p>
							<?php else: ?>
								<div class="alert alert-info">
									<strong>Status:</strong> Your child's application has been approved by Admission. 
									Please wait for the admission office to verify the application before you can proceed with enrollment.
								</div>
								<div class="table-responsive">
									<table class="table table-striped table-hover">
										<thead>
											<tr>
												<th>Child Name</th>
												<th>Birthdate</th>
												<th>Contact</th>
												<th>Status</th>
												<th>Date</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($approvedApplications as $application): ?>
												<tr>
													<td><?= htmlspecialchars($application['first_name'] . ' ' . $application['last_name']) ?></td>
													<td><?= htmlspecialchars(date('M j, Y', strtotime($application['birthdate']))) ?></td>
													<td><?= htmlspecialchars($application['contact']) ?></td>
													<td>
														<span class="badge bg-info">Approved - Awaiting Verification</span>
														<div class="small text-muted mt-1">Please wait for verification</div>
													</td>
													<td><?= htmlspecialchars(date('M j, Y', strtotime($application['created_at']))) ?></td>
													<td>
														<a href="/MI2/student/application_status.php?app_id=<?= $application['id'] ?>" class="btn btn-sm btn-outline-primary">Check Status</a>
													</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<div class="card mb-4 shadow-sm">
						<div class="card-header">
							<h5 class="my-0 fw-normal">Verified Applications - Ready for Enrollment</h5>
						</div>
						<div class="card-body">
							<?php if (empty($verifiedApplications)): ?>
								<p class="text-muted">You don't have any verified applications ready for enrollment.</p>
							<?php else: ?>
								<div class="alert alert-success">
									<strong>Next Steps:</strong> Your child's application has been approved and verified by Admission. 
									Click "Enroll Now" to proceed with the enrollment process.
								</div>
								<div class="table-responsive">
									<table class="table table-striped table-hover">
										<thead>
											<tr>
												<th>Child Name</th>
												<th>Birthdate</th>
												<th>Contact</th>
												<th>Status</th>
												<th>Date</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($verifiedApplications as $application): ?>
												<tr>
													<td><?= htmlspecialchars($application['first_name'] . ' ' . $application['last_name']) ?></td>
													<td><?= htmlspecialchars(date('M j, Y', strtotime($application['birthdate']))) ?></td>
													<td><?= htmlspecialchars($application['contact']) ?></td>
													<td>
														<span class="badge bg-success">Verified - Ready for Enrollment</span>
														<div class="small text-muted mt-1">Click "Enroll Now" to proceed</div>
													</td>
													<td><?= htmlspecialchars(date('M j, Y', strtotime($application['created_at']))) ?></td>
													<td>
														<a href="/MI2/Parent/parent_enrollment.php?app_id=<?= $application['id'] ?>" class="btn btn-sm btn-primary">Enroll Now</a>
														<div class="small text-muted mt-1">This will take you to the enrollment form</div>
													</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<div class="card mb-4 shadow-sm">
						<div class="card-header bg-primary text-white">
							<h5 class="my-0 fw-normal"><i class="fas fa-children"></i> My Children - Enrollment Status</h5>
						</div>
						<div class="card-body">
							<?php if (empty($parentEnrollments)): ?>
								<p class="text-muted">You don't have any enrollments yet.</p>
							<?php else: ?>
								<div class="table-responsive">
									<table class="table table-hover">
										<thead>
											<tr>
												<th>Child Name</th>
												<th>Enrollment #</th>
												<th>Grade Level</th>
												<th>Enrollment Status</th>
												<th>Payment Status</th>
												<th>Amount</th>
												<th>Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($parentEnrollments as $enrollment): ?>
												<tr>
													<td>
														<strong><?= htmlspecialchars($enrollment['first_name'] . ' ' . $enrollment['last_name']) ?></strong>
													</td>
													<td><?= htmlspecialchars($enrollment['enrollment_number'] ?? 'N/A') ?></td>
													<td><?= htmlspecialchars($enrollment['grade_level'] ?? 'N/A') ?></td>
													<td>
														<?php
															$status = $enrollment['status'];
															$statusClass = '';
															switch ($status) {
																case 'pending_payment':
																	$statusClass = 'badge bg-warning text-dark';
																	$statusText = 'Pending Payment';
																	break;
																case 'paid':
																	$statusClass = 'badge bg-info';
																	$statusText = 'Payment Submitted';
																	break;
																case 'enrolled':
																	$statusClass = 'badge bg-success';
																	$statusText = 'Officially Enrolled';
																	break;
																case 'not_enrolled':
																	$statusClass = 'badge bg-secondary';
																	$statusText = 'Not Enrolled';
																	break;
																default:
																	$statusClass = 'badge bg-secondary';
																	$statusText = ucfirst(str_replace('_', ' ', $status));
															}
														?>
														<span class="<?= $statusClass ?>"><?= htmlspecialchars($statusText) ?></span>
													</td>
													<td>
														<?php
															$paymentStatus = $enrollment['payment_status'] ?? 'pending';
															$paymentClass = '';
															$paymentText = '';
															switch ($paymentStatus) {
																case 'pending':
																	$paymentClass = 'badge bg-warning text-dark';
																	$paymentText = 'Not Paid';
																	break;
																case 'pending_verification':
																	$paymentClass = 'badge bg-info';
																	$paymentText = 'Awaiting Verification';
																	break;
																case 'paid':
																	$paymentClass = 'badge bg-success';
																	$paymentText = 'Verified & Paid';
																	break;
																default:
																	$paymentClass = 'badge bg-secondary';
																	$paymentText = ucfirst($paymentStatus);
															}
														?>
														<span class="<?= $paymentClass ?>"><?= htmlspecialchars($paymentText) ?></span>
													</td>
													<td>
														<?php if (!empty($enrollment['amount'])): ?>
															<strong>₱<?= number_format($enrollment['amount'], 2) ?></strong>
														<?php else: ?>
															<span class="text-muted">Not set</span>
														<?php endif; ?>
													</td>
													<td>
														<div class="btn-group-vertical btn-group-sm" role="group">
															<!-- View Details -->
															<a href="/MI2/student/enrollment_form.php?enroll_id=<?= $enrollment['id'] ?>" 
															   class="btn btn-outline-primary btn-sm mb-1">
																<i class="fas fa-eye"></i> View Details
															</a>
																		
															<!-- Pay Now (if pending payment) -->
															<?php if ($paymentStatus === 'pending' && !empty($enrollment['bill_id'])): ?>
																<a href="/MI2/student/pay_bill.php?bill_id=<?= $enrollment['bill_id'] ?>" 
																   class="btn btn-success btn-sm mb-1">
																	<i class="fas fa-money-bill-wave"></i> Pay Now
																</a>
															<?php endif; ?>
																		
															<!-- Upload Payment Proof (if pending verification) -->
															<?php if ($paymentStatus === 'pending_verification' && !empty($enrollment['bill_id'])): ?>
																<a href="/MI2/student/pay_bill.php?bill_id=<?= $enrollment['bill_id'] ?>" 
																   class="btn btn-info btn-sm mb-1">
																	<i class="fas fa-receipt"></i> View Payment
																</a>
															<?php endif; ?>
																		
															<!-- Download Receipt (if paid) -->
															<?php if ($paymentStatus === 'paid' && !empty($enrollment['receipt_path'])): ?>
																<a href="<?= htmlspecialchars($enrollment['receipt_path']) ?>" 
																   target="_blank" 
																   class="btn btn-outline-success btn-sm mb-1">
																	<i class="fas fa-download"></i> Receipt
																</a>
															<?php endif; ?>
														</div>
													</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
											
								<!-- Summary Info -->
								<div class="mt-3 p-3 bg-light rounded">
									<div class="row">
										<div class="col-md-3">
											<strong>Total Children:</strong> <?= count($parentEnrollments) ?>
										</div>
										<div class="col-md-3">
											<strong>Enrolled:</strong> 
											<?php 
												$enrolledCount = count(array_filter($parentEnrollments, function($e) {
													return $e['status'] === 'enrolled';
												}));
												echo $enrolledCount;
											?>
										</div>
										<div class="col-md-3">
											<strong>Not Enrolled:</strong> 
											<?php 
												$notEnrolledCount = count(array_filter($parentEnrollments, function($e) {
													return $e['status'] === 'not_enrolled';
												}));
												echo $notEnrolledCount;
											?>
										</div>
										<div class="col-md-3">
											<strong>Pending Payment:</strong> 
											<?php 
												$pendingPaymentCount = count(array_filter($parentEnrollments, function($e) {
													return ($e['payment_status'] ?? 'pending') === 'pending';
												}));
												echo $pendingPaymentCount;
											?>
										</div>
									</div>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<div class="card mb-4 shadow-sm">
						<div class="card-header">
							<h5 class="my-0 fw-normal">Quick Actions</h5>
						</div>
						<div class="card-body">
							<div class="row">
								<?php if ($enrollmentActive): ?>
									<div class="col-md-6 mb-3">
										<div class="card border-primary">
											<div class="card-body text-center">
												<i class="fas fa-user-plus fa-3x text-primary mb-3"></i>
												<h5 class="card-title">Enroll a Child</h5>
												<p class="card-text text-muted">You can enroll multiple children individually</p>
												<a href="/MI2/Parent/parent_enrollment.php" class="btn btn-primary">
													<i class="fas fa-plus-circle"></i> Enroll New Child
												</a>
											</div>
										</div>
									</div>
									<div class="col-md-6 mb-3">
										<div class="card border-info">
											<div class="card-body text-center">
												<i class="fas fa-info-circle fa-3x text-info mb-3"></i>
												<h5 class="card-title">Multiple Enrollments</h5>
												<p class="card-text">As a parent, you can enroll multiple children. Each child will have their own enrollment record and payment.</p>
											</div>
										</div>
									</div>
								<?php else: ?>
									<div class="col-12">
										<div class="alert alert-warning">
											<i class="fas fa-exclamation-triangle"></i> Enrollment is not currently active.
										</div>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>