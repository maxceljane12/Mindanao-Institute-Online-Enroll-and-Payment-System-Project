<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || (strtolower($_SESSION['role']) !== 'cashier' && strtolower($_SESSION['role']) !== 'admin')) {
    header('Location: ../index.php');
    exit;
}

require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
    $fee_id = filter_input(INPUT_POST, 'fee_id', FILTER_VALIDATE_INT);
    $fee_name = filter_input(INPUT_POST, 'fee_name', FILTER_SANITIZE_STRING);
    $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
    $school_year = filter_input(INPUT_POST, 'school_year', FILTER_SANITIZE_STRING);
    $applicable_to_group = filter_input(INPUT_POST, 'applicable_to_group', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

    $errors = [];

    if ($action === 'add' || $action === 'update') {
        if (empty($fee_name)) {
            $errors[] = "Fee Name is required.";
        }
        if (!$amount || $amount <= 0) {
            $errors[] = "Amount must be a positive number.";
        }
        if (empty($school_year)) {
            $errors[] = "School Year is required.";
        }
        if (empty($applicable_to_group)) {
            $errors[] = "Applicable To Group is required.";
        }
    }

    if (!empty($errors)) {
        $_SESSION['error_message'] = implode("<br>", $errors);
        // Redirect based on user role
        if (strtolower($_SESSION['role']) === 'admin') {
            header('Location: ../admin/manage_enrollment_fees.php');
        } else {
            header('Location: ../cashier/manage_enrollment_fees.php');
        }
        exit;
    }

    try {
        switch ($action) {
            case 'add':
                $stmt = $pdo->prepare("INSERT INTO enrollment_fees (fee_name, amount, school_year, applicable_to_group, description) VALUES (:fee_name, :amount, :school_year, :applicable_to_group, :description)");
                $stmt->execute([
                    'fee_name' => $fee_name,
                    'amount' => $amount,
                    'school_year' => $school_year,
                    'applicable_to_group' => $applicable_to_group,
                    'description' => $description
                ]);
                $_SESSION['success_message'] = "Enrollment fee added successfully!";
                break;

            case 'update':
                if (!$fee_id) {
                    $errors[] = "Fee ID is required for update.";
                }
                if (!empty($errors)) {
                    $_SESSION['error_message'] = implode("<br>", $errors);
                    // Redirect based on user role
                    if (strtolower($_SESSION['role']) === 'admin') {
                        header('Location: ../admin/manage_enrollment_fees.php');
                    } else {
                        header('Location: ../cashier/manage_enrollment_fees.php');
                    }
                    exit;
                }
                $stmt = $pdo->prepare("UPDATE enrollment_fees SET fee_name = :fee_name, amount = :amount, school_year = :school_year, applicable_to_group = :applicable_to_group, description = :description, updated_at = NOW() WHERE fee_id = :fee_id");
                $stmt->execute([
                    'fee_name' => $fee_name,
                    'amount' => $amount,
                    'school_year' => $school_year,
                    'applicable_to_group' => $applicable_to_group,
                    'description' => $description,
                    'fee_id' => $fee_id
                ]);
                $_SESSION['success_message'] = "Enrollment fee updated successfully!";
                break;

            case 'delete':
                if (!$fee_id) {
                    $errors[] = "Fee ID is required for delete.";
                }
                if (!empty($errors)) {
                    $_SESSION['error_message'] = implode("<br>", $errors);
                    // Redirect based on user role
                    if (strtolower($_SESSION['role']) === 'admin') {
                        header('Location: ../admin/manage_enrollment_fees.php');
                    } else {
                        header('Location: ../cashier/manage_enrollment_fees.php');
                    }
                    exit;
                }
                $stmt = $pdo->prepare("DELETE FROM enrollment_fees WHERE fee_id = :fee_id");
                $stmt->execute(['fee_id' => $fee_id]);
                $_SESSION['success_message'] = "Enrollment fee deleted successfully!";
                break;

            default:
                $_SESSION['error_message'] = "Invalid action specified.";
                break;
        }

    } catch (PDOException $e) {
        error_log("Error processing enrollment fee: " . $e->getMessage());
        $_SESSION['error_message'] = "Database error: Could not process enrollment fee. " . $e->getMessage();
    }
    
    // Redirect based on user role
    if (strtolower($_SESSION['role']) === 'admin') {
        header('Location: ../admin/manage_enrollment_fees.php');
    } else {
        header('Location: ../cashier/manage_enrollment_fees.php');
    }
    exit;
} else {
    $_SESSION['error_message'] = "Invalid request method.";
    // Redirect based on user role
    if (strtolower($_SESSION['role']) === 'admin') {
        header('Location: ../admin/manage_enrollment_fees.php');
    } else {
        header('Location: ../cashier/manage_enrollment_fees.php');
    }
    exit;
}
?>