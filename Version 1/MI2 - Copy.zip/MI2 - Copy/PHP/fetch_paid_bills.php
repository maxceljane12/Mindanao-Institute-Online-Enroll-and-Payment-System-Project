<?php
// Path: PHP/fetch_paid_bills.php

include_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php'; // Include the database connection

// Fetch all paid bills
$paidBills = [];
$error_message = '';

try {
    $stmt = $pdo->prepare("
        SELECT
            b.bill_id,
            e.first_name,
            e.last_name,
            e.enrollment_number,
            b.bill_type,
            b.description,
            b.amount,
            b.status,
            b.created_at,
            b.updated_at,
            u_verifier.username AS verified_by_username,
            b.verification_note
        FROM
            bills b
        JOIN
            enrollments e ON b.enrollment_id = e.id
        LEFT JOIN
            users u_verifier ON b.verified_by = u_verifier.id
        WHERE
            b.status = 'paid'
        ORDER BY
            b.updated_at DESC
    ");
    $stmt->execute();
    $paidBills = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error_message = "Database error: Could not fetch paid bills. " . $e->getMessage();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paid Bills Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body { font-family: sans-serif; }
        .container { margin-top: 20px; }
        table th, table td { vertical-align: middle; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4">Paid Bills Report</h1>

        <?php if ($error_message): ?>
            <div class="alert alert-danger" role="alert">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <?php if (empty($paidBills)): ?>
            <p>No paid bills found in the database.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Bill ID</th>
                            <th>Student Name</th>
                            <th>Enrollment No.</th>
                            <th>Bill Type</th>
                            <th>Description</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date Paid</th>
                            <th>Verified By</th>
                            <th>Verification Note</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($paidBills as $bill): ?>
                            <tr>
                                <td><?= htmlspecialchars($bill['bill_id']) ?></td>
                                <td><?= htmlspecialchars($bill['first_name'] . ' ' . $bill['last_name']) ?></td>
                                <td><?= htmlspecialchars($bill['enrollment_number'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($bill['bill_type']) ?></td>
                                <td><?= htmlspecialchars($bill['description'] ?? 'N/A') ?></td>
                                <td>₱<?= htmlspecialchars(number_format($bill['amount'], 2)) ?></td>
                                <td><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $bill['status']))) ?></td>
                                <td><?= htmlspecialchars(date('M d, Y H:i', strtotime($bill['updated_at']))) ?></td>
                                <td><?= htmlspecialchars($bill['verified_by_username'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($bill['verification_note'] ?? 'N/A') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
