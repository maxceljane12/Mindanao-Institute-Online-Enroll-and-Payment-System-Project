<?php
if (session_status() === PHP_SESSION_NONE) session_start();

// Only students and parents can access this page
if (!isset($_SESSION['role']) || (strtolower($_SESSION['role']) !== 'student' && strtolower($_SESSION['role']) !== 'parent')) {
    header('Location: ../index.php');
    exit;
}

require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bill_id = filter_input(INPUT_POST, 'bill_id', FILTER_VALIDATE_INT);
    $payment_method = filter_input(INPUT_POST, 'payment_method', FILTER_SANITIZE_STRING);
    $amount_paid = filter_input(INPUT_POST, 'amount_paid', FILTER_VALIDATE_FLOAT);
    
    // Validate required fields
    if (!$bill_id || !$payment_method || !$amount_paid) {
        $_SESSION['error_message'] = "Missing required payment information.";
        header('Location: ../student/payment.php');
        exit;
    }
    
    // Validate payment method
    if (!in_array($payment_method, ['walk_in', 'gcash'])) {
        $_SESSION['error_message'] = "Invalid payment method.";
        header('Location: ../student/payment.php');
        exit;
    }
    
    try {
        $pdo->beginTransaction();
        
        // Get bill details
        $stmt = $pdo->prepare("SELECT * FROM bills WHERE bill_id = :bill_id");
        $stmt->execute(['bill_id' => $bill_id]);
        $bill = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$bill) {
            throw new Exception("Bill not found.");
        }
        
        // For both walk-in and GCash payments, set status to pending_verification
        // This ensures all payments go through cashier verification
        $new_bill_status = 'pending_verification';
        $verified_by = NULL;
        
        // Update bill status, payment method, and verification info if applicable
        $updateSql = "UPDATE bills SET status = :status, payment_method = :payment_method, updated_at = NOW()";
        if ($payment_method === 'walk_in') {
            // For walk-in payments, we don't set verified_by since it has a foreign key constraint
            // The payment record itself serves as proof of payment
        }
        if (isset($_FILES['receipt_upload']) && $_FILES['receipt_upload']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = __DIR__ . '/../uploads/receipts/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $fileExtension = strtolower(pathinfo($_FILES['receipt_upload']['name'], PATHINFO_EXTENSION));
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
            
            if (in_array($fileExtension, $allowedExtensions)) {
                $newFileName = 'receipt_' . $bill_id . '_' . time() . '.' . $fileExtension;
                $uploadPath = $uploadDir . $newFileName;
                
                if (move_uploaded_file($_FILES['receipt_upload']['tmp_name'], $uploadPath)) {
                    $receipt_path = '/MI2/uploads/receipts/' . $newFileName;
                    $updateSql .= ", receipt_path = :receipt_path";
                }
            }
        }
        $updateSql .= " WHERE bill_id = :bill_id";
        
        $stmt = $pdo->prepare($updateSql);
        $stmt->bindParam(':status', $new_bill_status);
        $stmt->bindParam(':payment_method', $payment_method);
        if (isset($receipt_path)) {
            $stmt->bindParam(':receipt_path', $receipt_path);
        }
        $stmt->bindParam(':bill_id', $bill_id);
        $stmt->execute();
        
        $pdo->commit();
        
        $_SESSION['success_message'] = ucfirst($payment_method) . " payment for Bill ID " . $bill_id . " submitted successfully. Please proceed to the cashier for verification and then wait for registrar enrollment.";
        header('Location: ../student/payment.php');
        exit;
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Error processing student payment: " . $e->getMessage());
        $_SESSION['error_message'] = "Database error: Could not process payment.";
        // If GCash receipt was uploaded, delete it on database error
        if (isset($receipt_path) && file_exists($receipt_path)) {
            unlink($receipt_path);
        }
        header('Location: ../student/payment.php');
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Error processing student payment: " . $e->getMessage());
        $_SESSION['error_message'] = "Error: " . $e->getMessage();
        header('Location: ../student/payment.php');
        exit;
    }
} else {
    $_SESSION['error_message'] = "Invalid request method.";
    header('Location: ../student/payment.php');
    exit;
}
?>