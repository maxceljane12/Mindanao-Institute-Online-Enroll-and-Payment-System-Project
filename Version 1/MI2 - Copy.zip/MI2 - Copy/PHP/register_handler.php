<?php
// Cleaned server-side registration handler
// Path: PHP/register_handler.php

include_once __DIR__ . '/../includes/config.php';
session_start();
include __DIR__ . '/../includes/db.php';

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
}

// Helper: sanitize input
function sanitizeInput($data) {
    $fields = [
        'first_name','middle_name','last_name','extension','birthdate',
        'age','sex','street','barangay','municipal','province','country','zipcode',
        'email','username','password','confirm_password','role'
    ];

    $clean = [];
    foreach ($fields as $f) {
        $value = isset($data[$f]) ? trim($data[$f]) : '';
        if (in_array($f, ['first_name','middle_name','last_name','street','barangay','municipal','province','country'])) {
            $value = preg_replace('/\s+/', ' ', $value);
        }
        $clean[$f] = $value;
    }
    $clean['age'] = intval($clean['age']);
    if (empty($clean['country'])) $clean['country'] = 'Philippines';

    if (isset($data['security_question']) && is_array($data['security_question'])) {
        $clean['security_question'] = array_map('trim', $data['security_question']);
    }
    if (isset($data['security_answer']) && is_array($data['security_answer'])) {
        $clean['security_answer'] = array_map('trim', $data['security_answer']);
    }

    return $clean;
}

// Helper: validate
function validateRegistrationData($data) {
    $errors = [];

    $required = [
        'first_name','last_name','birthdate','age','sex',
        'street','barangay','municipal','province','country','zipcode',
        'email','username','password','confirm_password','role'
    ];

    foreach ($required as $field) {
        if (empty($data[$field])) {
            $errors[$field] = ucfirst(str_replace('_',' ',$field)) . ' is required.';
        }
    }

    if (!empty($data['role']) && !in_array($data['role'], ['student','parent'])) {
        $errors['role'] = 'Invalid role selected.';
    }

    if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format.';
    }

    if (!empty($data['password']) && strlen($data['password']) < 8) {
        $errors['password'] = 'Password must be at least 8 characters.';
    }

    if (isset($data['password']) && isset($data['confirm_password']) && $data['password'] !== $data['confirm_password']) {
        $errors['confirm_password'] = 'Passwords do not match.';
    }

    if (!isset($data['security_question']) || !is_array($data['security_question']) || count($data['security_question']) !== 3) {
        $errors['security_questions'] = 'Please select exactly 3 security questions.';
    } else {
        $unique = array_unique($data['security_question']);
        if (count($unique) !== 3) {
            $errors['security_questions'] = 'Please select 3 unique security questions.';
        }
    }

    if (!isset($data['security_answer']) || !is_array($data['security_answer']) || count($data['security_answer']) !== 3) {
        $errors['security_answers'] = 'Please answer all 3 security questions.';
    } else {
        foreach ($data['security_answer'] as $ans) {
            if (trim($ans) === '') {
                $errors['security_answers'] = 'Please answer all 3 security questions.';
                break;
            }
        }
    }

    return ['valid' => empty($errors), 'errors' => $errors];
}

// Helper: check duplicate user
function checkDuplicateUser($pdo, $field, $value) {
    $allowed = ['username', 'email'];
    if (!in_array($field, $allowed)) return false;
    // Use backticks for the field name to be safe, although it's from a whitelist
    $stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM users WHERE `{$field}` = ?");
    $stmt->execute([$value]);
    $row = $stmt->fetch();
    return ($row && $row['cnt'] > 0);
}

// Generate user id safely (transaction + SELECT ... FOR UPDATE)
function generateNewUserId($pdo) {
    $year = intval(date('Y'));
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("SELECT counter FROM user_id_counter WHERE `year` = ? FOR UPDATE");
        $stmt->execute([$year]);
        $row = $stmt->fetch();

        if ($row) {
            $counter = $row['counter'] + 1;
            $upd = $pdo->prepare("UPDATE user_id_counter SET counter = ? WHERE `year` = ?");
            $upd->execute([$counter, $year]);
        } else {
            $counter = 1;
            $ins = $pdo->prepare("INSERT INTO user_id_counter (`year`, `counter`) VALUES (?, ?)");
            $ins->execute([$year, $counter]);
        }

        $pdo->commit();
        return sprintf('%d-%04d', $year, $counter);
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// Start processing
$data = sanitizeInput($_POST);
$validation = validateRegistrationData($data);
if (!$validation['valid']) {
    $_SESSION['form_data'] = $data;
    $_SESSION['current_step'] = isset($_POST['current_step']) ? (int)$_POST['current_step'] : 1;
    $_SESSION['registration_errors'] = $validation['errors'];
    header('Location: ../registration.php?error=' . urlencode(reset($validation['errors'])));
    exit;
}

// Duplicate checks
foreach (['username', 'email'] as $field) {
    if (checkDuplicateUser($pdo, $field, $data[$field])) {
        $_SESSION['form_data'] = $data;
        $_SESSION['current_step'] = isset($_POST['current_step']) ? (int)$_POST['current_step'] : 1;
        $_SESSION['registration_errors'][$field] = ucfirst($field) . ' already exists.';
        header('Location: ../registration.php');
        exit;
    }
}

// Hash password and answers
$hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
$hashed_answers = array_map(function($a){ return password_hash(strtolower(trim($a)), PASSWORD_DEFAULT); }, $data['security_answer']);

// Prepare insert
try {
    $new_user_id = generateNewUserId($pdo);

    $sql = "INSERT INTO users (
        id, first_name, middle_name, last_name, suffix, birthdate, age, sex,
        street, barangay, municipal, province, country, zipcode,
        email, username, password, role,
        security_question_1, answer_1, security_question_2, answer_2, security_question_3, answer_3,
        created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

    $stmt = $pdo->prepare($sql);

    $params = [
        $new_user_id,
        $data['first_name'],
        $data['middle_name'],
        $data['last_name'],
        $data['extension'],
        $data['birthdate'],
        $data['age'],
        $data['sex'],
        $data['street'],
        $data['barangay'],
        $data['municipal'],
        $data['province'],
        $data['country'],
        $data['zipcode'],
        $data['email'],
        $data['username'],
        $hashedPassword,
        $data['role'],
        $data['security_question'][0], $hashed_answers[0],
        $data['security_question'][1], $hashed_answers[1],
        $data['security_question'][2], $hashed_answers[2]
    ];

    if ($stmt->execute($params)) {
        header('Location: ../index.php?registration_success=true');
        exit;
    } else {
        throw new Exception('Execution failed.');
    }

} catch (Exception $e) {
    error_log('Registration handler error: ' . $e->getMessage());
    $_SESSION['form_data'] = $data;
    $_SESSION['current_step'] = isset($_POST['current_step']) ? (int)$_POST['current_step'] : 1;
    $_SESSION['registration_errors'] = ['server' => 'Registration failed. Please try again.'];
    header('Location: ../registration.php?error=' . urlencode($e->getMessage()));
    exit;
}

?>
