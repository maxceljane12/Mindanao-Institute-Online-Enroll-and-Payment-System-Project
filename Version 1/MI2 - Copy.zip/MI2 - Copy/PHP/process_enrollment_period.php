<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
    header('Location: ../index.php');
    exit;
}

require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
    $period_id = filter_input(INPUT_POST, 'period_id', FILTER_VALIDATE_INT);
    $school_year = filter_input(INPUT_POST, 'school_year', FILTER_SANITIZE_STRING);
    $start_date = filter_input(INPUT_POST, 'start_date', FILTER_SANITIZE_STRING);
    $end_date = filter_input(INPUT_POST, 'end_date', FILTER_SANITIZE_STRING);
    $is_active = filter_input(INPUT_POST, 'is_active', FILTER_VALIDATE_INT) ?: 0;

    $errors = [];

    if ($action === 'add' || $action === 'update') {
        if (empty($school_year)) {
            $errors[] = "School Year is required.";
        }
        if (empty($start_date)) {
            $errors[] = "Start Date is required.";
        }
        if (empty($end_date)) {
            $errors[] = "End Date is required.";
        }
        
        // Validate date format
        if (!empty($start_date) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
            $errors[] = "Start Date must be in YYYY-MM-DD format.";
        }
        if (!empty($end_date) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
            $errors[] = "End Date must be in YYYY-MM-DD format.";
        }
        
        // Check if start date is before end date
        if (!empty($start_date) && !empty($end_date)) {
            $start = new DateTime($start_date);
            $end = new DateTime($end_date);
            if ($start >= $end) {
                $errors[] = "Start Date must be before End Date.";
            }
        }
    }

    if (!empty($errors)) {
        $_SESSION['error_message'] = implode("<br>", $errors);
        header('Location: ../admin/manage_enrollment_periods.php');
        exit;
    }

    try {
        switch ($action) {
            case 'add':
                // Check if school year already exists
                $stmt = $pdo->prepare("SELECT id FROM enrollment_periods WHERE school_year = ?");
                $stmt->execute([$school_year]);
                $existing_period = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($existing_period) {
                    $errors[] = "An enrollment period for school year '$school_year' already exists.";
                    $_SESSION['error_message'] = implode("<br>", $errors);
                    header('Location: ../admin/manage_enrollment_periods.php');
                    exit;
                }
                
                // If setting as active, deactivate all others first
                if ($is_active) {
                    $stmt = $pdo->prepare("UPDATE enrollment_periods SET is_active = 0");
                    $stmt->execute();
                    
                    // Set all current enrollments to 'not_enrolled' status
                    $stmt = $pdo->prepare("UPDATE enrollments SET status = 'not_enrolled' WHERE status = 'enrolled'");
                    $stmt->execute();
                }
                
                $stmt = $pdo->prepare("INSERT INTO enrollment_periods (school_year, start_date, end_date, is_active) VALUES (?, ?, ?, ?)");
                $stmt->execute([$school_year, $start_date, $end_date, $is_active]);
                $_SESSION['success_message'] = $is_active ? 
                    "Enrollment period added and activated successfully! All previously enrolled students have been set to 'Not Enrolled' status and need to re-enroll for the new school year." :
                    "Enrollment period added successfully!";
                break;

            case 'update':
                if (!$period_id) {
                    $errors[] = "Period ID is required for update.";
                }
                if (!empty($errors)) {
                    $_SESSION['error_message'] = implode("<br>", $errors);
                    header('Location: ../admin/manage_enrollment_periods.php');
                    exit;
                }
                
                // Check if another period with same school year exists
                $stmt = $pdo->prepare("SELECT id FROM enrollment_periods WHERE school_year = ? AND id != ?");
                $stmt->execute([$school_year, $period_id]);
                $existing_period = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($existing_period) {
                    $errors[] = "Another enrollment period for school year '$school_year' already exists.";
                    $_SESSION['error_message'] = implode("<br>", $errors);
                    header('Location: ../admin/manage_enrollment_periods.php');
                    exit;
                }
                
                // If setting as active, deactivate all others first
                if ($is_active) {
                    $stmt = $pdo->prepare("UPDATE enrollment_periods SET is_active = 0");
                    $stmt->execute();
                }
                
                $stmt = $pdo->prepare("UPDATE enrollment_periods SET school_year = ?, start_date = ?, end_date = ?, is_active = ? WHERE id = ?");
                $stmt->execute([$school_year, $start_date, $end_date, $is_active, $period_id]);
                $_SESSION['success_message'] = $is_active ? 
                    "Enrollment period updated and activated successfully! All previously enrolled students have been set to 'Not Enrolled' status and need to re-enroll for the new school year." :
                    "Enrollment period updated successfully!";
                break;

            case 'delete':
                if (!$period_id) {
                    $errors[] = "Period ID is required for delete.";
                }
                if (!empty($errors)) {
                    $_SESSION['error_message'] = implode("<br>", $errors);
                    header('Location: ../admin/manage_enrollment_periods.php');
                    exit;
                }
                
                // Don't allow deletion of active period
                $stmt = $pdo->prepare("SELECT is_active FROM enrollment_periods WHERE id = ?");
                $stmt->execute([$period_id]);
                $period = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($period && $period['is_active']) {
                    $errors[] = "Cannot delete the active enrollment period. Please activate another period first.";
                    $_SESSION['error_message'] = implode("<br>", $errors);
                    header('Location: ../admin/manage_enrollment_periods.php');
                    exit;
                }
                
                $stmt = $pdo->prepare("DELETE FROM enrollment_periods WHERE id = ?");
                $stmt->execute([$period_id]);
                $_SESSION['success_message'] = "Enrollment period deleted successfully!";
                break;

            case 'toggle_active':
                if (!$period_id) {
                    $errors[] = "Period ID is required.";
                }
                if (!empty($errors)) {
                    $_SESSION['error_message'] = implode("<br>", $errors);
                    header('Location: ../admin/manage_enrollment_periods.php');
                    exit;
                }
                
                // Deactivate all periods first
                $stmt = $pdo->prepare("UPDATE enrollment_periods SET is_active = 0");
                $stmt->execute();
                
                // Set all current enrollments to 'not_enrolled' status
                $stmt = $pdo->prepare("UPDATE enrollments SET status = 'not_enrolled' WHERE status = 'enrolled'");
                $stmt->execute();
                
                // Activate the selected period
                $stmt = $pdo->prepare("UPDATE enrollment_periods SET is_active = 1 WHERE id = ?");
                $stmt->execute([$period_id]);
                $_SESSION['success_message'] = "Enrollment period activated successfully! All previously enrolled students have been set to 'Not Enrolled' status and need to re-enroll for the new school year.";
                break;

            default:
                $_SESSION['error_message'] = "Invalid action specified.";
                break;
        }

    } catch (PDOException $e) {
        error_log("Error processing enrollment period: " . $e->getMessage());
        $_SESSION['error_message'] = "Database error: Could not process enrollment period. " . $e->getMessage();
    }
    
    header('Location: ../admin/manage_enrollment_periods.php');
    exit;
} else {
    $_SESSION['error_message'] = "Invalid request method.";
    header('Location: ../admin/manage_enrollment_periods.php');
    exit;
}
?>