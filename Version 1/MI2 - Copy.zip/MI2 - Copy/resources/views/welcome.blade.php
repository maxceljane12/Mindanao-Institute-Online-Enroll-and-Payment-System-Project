@extends('layouts.app')

@section('title','Welcome')

@section('content')
  <main class="container hero">
    <div class="hero-content d-flex" style="gap:24px;align-items:flex-start">
      <div style="flex:1;">
        <h1 class="display-6" style="color:var(--maroon);font-weight:700">
          Welcome to<br>Mindanao Institute
        </h1>
        <p class="small-muted">
          Nurturing Knowledge, Cultivating Character, and Building Leaders for Tomorrow
        </p>

        <div class="mt-4 mb-4">
          <a href="registration.php" class="btn btn-warning btn-lg"
             style="background:var(--accent);border:none;color:#000;border-radius:8px;padding:10px 18px">
            Get Started
          </a>
        </div>

        <div class="row g-3">
          <div class="col-md-4">
            <div class="p-4 card-feature">
              <div class="mb-2" style="font-size:1.4rem">🎓</div>
              <div class="small-muted">Building minds with knowledge, integrity, and innovation.</div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="p-4 card-feature">
              <div class="mb-2" style="font-size:1.4rem">🏃‍♂️</div>
              <div class="small-muted">Shaping discipline, teamwork, and resilience through play.</div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="p-4 card-feature">
              <div class="mb-2" style="font-size:1.4rem">🎭</div>
              <div class="small-muted">Inspiring creativity, culture, and self-expression.</div>
            </div>
          </div>
        </div>

      </div>

      <aside style="width:380px">
        <div class="p-4 bg-white login-card">
          <h5 style="color:var(--maroon);font-weight:700">Login to Your Account</h5>

          <form method="POST" action="login.php" class="mt-3">

            <div class="mb-3">
              <label class="form-label">Username <span class="text-danger">*</span></label>
              <input name="username" type="text" class="form-control" value="{{ $username ?? 'root' }}" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Password <span class="text-danger">*</span></label>
              <input name="password" type="password" class="form-control" required>
            </div>

            <div class="d-grid">
              <button type="submit" class="btn btn-accent">Login</button>
            </div>
          </form>

          <p class="mt-3 small-muted text-center">
            Don't have an account? <a href="registration.php">Please register here</a>
          </p>
        </div>
      </aside>
    </div>
  </main>
@endsection
