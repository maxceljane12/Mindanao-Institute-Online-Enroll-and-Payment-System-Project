@extends('layouts.app')

@section('title','Registrar Dashboard')

@section('content')
  <div class="container">
    <h1>Registrar Dashboard</h1>
    <p class="small-muted">Placeholder: original `registrar/registrar_dashboard.php` was empty.</p>
  </div>
@endsection
