<header class="site-header py-3 mb-4">
  <div class="container d-flex align-items-center justify-content-between">
    <div class="d-flex align-items-center gap-3">

       <img src="/image/logo.png" alt="Mindanao Institute" 
         style="height:48px;object-fit:contain;border-radius:6px">

      <div>
        <div class="brand">Mindanao Institute</div>
        <div class="tagline">Enrollment and Payment Management System</div>
      </div>
    </div>

    <nav>
      <a href="index.php" class="me-3 small-muted">Home</a>
      <a href="#register" class="small-muted">Register</a>
    </nav>
  </div>
</header>
