@extends('layouts.app')

@section('title','Cashier Dashboard')

@section('content')
<div class="container">
    <h1>Cashier Dashboard</h1>
    <p class="small-muted">Welcome to the cashier area. Here's a summary of the financial activity.</p>
    
    <div class="no-print">
        <div style="text-align: right; margin-bottom: 15px;">
            <button onclick="window.print()" class="btn btn-outline-primary">
                <i class="fas fa-print"></i> Print Revenue Report
            </button>
        </div>
    </div>
    
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <h5 class="card-title">Total Revenue</h5>
                    <p class="card-text fs-4">₱{{ number_format($total_paid ?? 0, 2) }}</p>
                    <small>All time collected payments</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <h5 class="card-title">Pending Verification</h5>
                    <p class="card-text fs-4">₱{{ number_format($total_pending_verification ?? 0, 2) }}</p>
                    <small>Paid awaiting verification</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <h5 class="card-title">Pending Payments</h5>
                    <p class="card-text fs-4">{{ $pending_count ?? 0 }}</p>
                    <a href="/MI2/cashier/verify_payments.php" class="text-white">View Details &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    
    <h2 class="mt-4">Recent Transactions</h2>
    @if(empty($paid_bills))
        <p>No transactions found.</p>
    @else
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Bill ID</th>
                        <th>Student Name</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date Submitted</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($paid_bills as $bill)
                        <tr>
                            <td>{{ $bill['bill_id'] }}</td>
                            <td>{{ $bill['first_name'] }} {{ $bill['last_name'] }}</td>
                            <td>₱{{ number_format($bill['amount'], 2) }}</td>
                            <td>{{ ucfirst(str_replace('_', ' ', $bill['status'])) }}</td>
                            <td>{{ date('M d, Y', strtotime($bill['created_at'])) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
    
    <div class="no-print mt-4">
        <button onclick="window.print()" class="btn btn-primary">
            <i class="fas fa-print"></i> Print Revenue Report
        </button>
    </div>
</div>

<style>
@media print {
    .no-print {
        display: none !important;
    }
    
    body {
        font-size: 12pt;
    }
    
    .card {
        border: 1px solid #000;
        page-break-inside: avoid;
    }
    
    table {
        border-collapse: collapse;
        width: 100%;
        margin-top: 20px;
    }
    
    th, td {
        border: 1px solid #000;
        padding: 8px;
        text-align: left;
    }
    
    th {
        background-color: #f2f2f2;
    }
    
    .print-header {
        text-align: center;
        margin-bottom: 20px;
        border-bottom: 2px solid #000;
        padding-bottom: 10px;
    }
    
    .print-header h1 {
        margin: 0;
        font-size: 24px;
    }
    
    .print-header p {
        margin: 5px 0 0 0;
    }
    
    .stats-container {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }
    
    .stat-box {
        border: 1px solid #000;
        padding: 10px;
        text-align: center;
        flex: 1;
        margin: 0 5px;
    }
    
    .stat-box h3 {
        margin-top: 0;
        font-size: 16px;
    }
    
    .stat-value {
        font-size: 18px;
        font-weight: bold;
    }
}
</style>

<script>
// Add print header when printing
window.onbeforeprint = function() {
    // Create a print header
    var printHeader = document.createElement('div');
    printHeader.className = 'print-header';
    printHeader.innerHTML = `
        <h1>Mindanao Institute</h1>
        <h2>Cashier Revenue Report</h2>
        <p>Generated on ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}</p>
    `;
    
    // Create stats summary for print
    var statsContainer = document.createElement('div');
    statsContainer.className = 'stats-container';
    statsContainer.innerHTML = `
        <div class="stat-box">
            <h3>Total Revenue</h3>
            <div class="stat-value">₱<?= number_format($total_paid ?? 0, 2) ?></div>
        </div>
        <div class="stat-box">
            <h3>Pending Verification</h3>
            <div class="stat-value">₱<?= number_format($total_pending_verification ?? 0, 2) ?></div>
        </div>
        <div class="stat-box">
            <h3>Pending Payments</h3>
            <div class="stat-value"><?= $pending_count ?? 0 ?></div>
        </div>
    `;
    
    // Insert at the beginning of the container
    var container = document.querySelector('.container');
    container.insertBefore(statsContainer, container.firstChild);
    container.insertBefore(printHeader, container.firstChild);
};

window.onafterprint = function() {
    // Remove print header after printing
    var printHeaders = document.querySelectorAll('.print-header, .stats-container');
    printHeaders.forEach(function(el) {
        el.remove();
    });
};
</script>
@endsection