@extends('layouts.app')

@section('title','Student Dashboard')

@section('content')
  <div class="container">
    <h1>Student Dashboard</h1>
    <p class="small-muted">Placeholder: original `student/student_dashboard.php` was empty.</p>
  </div>
@endsection
