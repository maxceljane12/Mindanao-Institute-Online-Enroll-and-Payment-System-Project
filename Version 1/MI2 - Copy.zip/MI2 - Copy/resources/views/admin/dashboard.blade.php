@extends('layouts.app')

@section('title','Admin Dashboard')

@section('content')
  <div class="container">
    <h1>Admin Dashboard</h1>
    <p class="small-muted">Placeholder: original `admin/admin_dashboard.php` was empty.</p>
  </div>
@endsection
