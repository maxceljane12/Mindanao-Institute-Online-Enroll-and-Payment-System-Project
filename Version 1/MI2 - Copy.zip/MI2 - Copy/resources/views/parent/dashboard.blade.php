@extends('layouts.app')

@section('title','Parent Dashboard')

@section('content')
  <div class="container">
    <h1>Parent Dashboard</h1>
    <p class="small-muted">Placeholder: original `Parent/parent_dashboard.php` was empty.</p>
  </div>
@endsection
