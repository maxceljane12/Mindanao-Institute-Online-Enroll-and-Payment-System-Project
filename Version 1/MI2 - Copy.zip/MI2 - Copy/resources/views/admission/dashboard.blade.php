@extends('layouts.app')

@section('title','Admission Dashboard')

@section('content')
  <div class="container">
    <h1>Admission Dashboard</h1>
    <p class="small-muted">Placeholder: original `admission/admission_dashboard.php` was empty.</p>
  </div>
@endsection
