<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title', 'Mindanao Institute — Enrollment and Payment Management System')</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    :root{--maroon:#6b0f0f;--accent:#f6c84c}
    body{font-family: Inter, system-ui, -apple-system, 'Segoe UI', Roboto, Arial;}
    .site-header{border-bottom:1px solid #eee}
    .brand {color:var(--maroon);font-weight:700;font-size:1.35rem}
    .tagline{font-size:0.80rem bold;color:#666;margin-top:3px}
    .hero{padding:48px 0}
    .card-feature{border-radius:12px;box-shadow:0 6px 18px rgba(30,30,30,0.04);}
    .login-card{border-radius:12px;box-shadow:0 10px 30px rgba(30,30,30,0.06);}
    .btn-accent{background:var(--maroon);color:#fff;border-radius:8px;padding:8px 16px}
    .small-muted{color:#777;font-size:0.95rem}
    footer{padding:18px 0;color:#999;border-top:1px solid #f0f0f0;margin-top:48px}
    @media(min-width: 992px){
      .hero-content{display:flex;gap:28px;align-items:flex-start}
    }
  </style>
</head>
<body>
  @include('partials.header')

  <main class="container">
    @yield('content')
  </main>

  @include('partials.footer')

  <!-- Optional: add your app bundle at `public/js/app.js` and include here -->
</body>
</html>
