<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sidebar Test</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <div class="sidebar" id="testSidebar">
        <div class="sidebar-toggle-wrapper">
          <button class="sidebar-toggle-btn" id="testToggle">
            <i class="fas fa-bars"></i>
          </button>
        </div>
        <div class="sidebar-user">
          <div class="sidebar-icon-wrapper">
            <i class="fas fa-user-circle"></i>
          </div>
          <div class="sidebar-user-info">
            <h3>User Info</h3>
            <div class="sidebar-user-name">Test User</div>
            <div class="sidebar-user-role">Administrator</div>
            <div class="sidebar-user-id">ID: TEST-001</div>
          </div>
        </div>
        <hr class="sidebar-divider">
        <div class="sidebar-section-title">Navigation</div>
        <nav class="sidebar-nav">
          <a href="#" class="sidebar-link">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
          </a>
          <a href="#" class="sidebar-link">
            <i class="fas fa-users"></i>
            <span>Manage Users</span>
          </a>
        </nav>
      </div>
      <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="margin-left: 60px;">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h1>Sidebar Test Page</h1>
        </div>
        <div class="card">
          <div class="card-header">
            <h5>Test Content</h5>
          </div>
          <div class="card-body">
            <p>This is a test page to verify the sidebar toggle functionality.</p>
            <p>Click the toggle button in the sidebar to expand/collapse it.</p>
            <p>The content should move smoothly with the sidebar.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Test sidebar toggle functionality
    document.addEventListener('DOMContentLoaded', function() {
      const sidebar = document.getElementById('testSidebar');
      const toggleBtn = document.getElementById('testToggle');
      
      // Check for saved sidebar state
      const isExpanded = localStorage.getItem('sidebarExpanded') === 'true';
      if (isExpanded) {
        sidebar.classList.add('expanded');
      }
      
      // Toggle sidebar on button click
      toggleBtn.addEventListener('click', function() {
        sidebar.classList.toggle('expanded');
        
        // Save state to localStorage
        const isCurrentlyExpanded = sidebar.classList.contains('expanded');
        localStorage.setItem('sidebarExpanded', isCurrentlyExpanded);
      });
    });
  </script>
</body>
</html>