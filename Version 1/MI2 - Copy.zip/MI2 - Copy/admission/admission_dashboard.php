<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admission') {
    header('Location: ../index.php');
    exit;
}

// Include database connection
require_once __DIR__ . '/../includes/db.php';

// Check if user is still active
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !$user['is_active']) {
        // User is deactivated, log them out
        session_destroy();
        header('Location: ../index.php?error=account_deactivated');
        exit;
    }
}

// Get real application statistics
try {
    // Total applications
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM applications");
    $totalApplications = $stmt->fetch()['count'];
    
    // Applications by status
    $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM applications GROUP BY status");
    $applicationStats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Convert to associative array for easy access
    $stats = [];
    foreach ($applicationStats as $stat) {
        $stats[$stat['status']] = $stat['count'];
    }
    
    $pendingCount = isset($stats['pending']) ? $stats['pending'] : 0;
    $approvedCount = isset($stats['approved']) ? $stats['approved'] : 0;
    $rejectedCount = isset($stats['rejected']) ? $stats['rejected'] : 0;
    
} catch (PDOException $e) {
    error_log("Database error in admission dashboard: " . $e->getMessage());
    $totalApplications = 0;
    $pendingCount = 0;
    $approvedCount = 0;
    $rejectedCount = 0;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mindanao Institute — Enrollment and Payment Management System</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<div style="display: flex;">
	<?php include __DIR__ . '/../includes/sidebar.php'; ?>
	<div style="flex: 1; padding: 20px;">
		<h1>Admission Dashboard</h1>
		
		<div style="margin-bottom: 30px;">
			<h2>Welcome to the Admission Area</h2>
			<p>As an admission officer, you can review and manage student applications.</p>
			<a href="/MI2/admission/manage_applications.php" class="btn">Manage Applications</a>
		</div>
		
		<div style="display: flex; gap: 20px; margin-bottom: 30px;">
			<div style="flex: 1;">
				<h2>Application Statistics</h2>
				<ul style="list-style: none; padding: 0;">
					<li style="padding: 10px; border-bottom: 1px solid #ddd;">
						Total Applications
						<span style="float: right;"><?php echo $totalApplications; ?></span>
					</li>
					<li style="padding: 10px; border-bottom: 1px solid #ddd;">
						Pending Review
						<span style="float: right;"><?php echo $pendingCount; ?></span>
					</li>
					<li style="padding: 10px; border-bottom: 1px solid #ddd;">
						Approved
						<span style="float: right;"><?php echo $approvedCount; ?></span>
					</li>
					<li style="padding: 10px; border-bottom: 1px solid #ddd;">
						Rejected
						<span style="float: right;"><?php echo $rejectedCount; ?></span>
					</li>
				</ul>
			</div>
			
			<div style="flex: 1;">
				<h2>Quick Actions</h2>
				<div style="display: flex; flex-direction: column; gap: 10px;">
					<a href="/MI2/admission/manage_applications.php" class="btn">Review Applications</a>
					<a href="#" class="btn" style="background-color: #6c757d;">View Reports</a>
					<a href="#" class="btn" style="background-color: #6c757d;">Settings</a>
				</div>
			</div>
		</div>
	</div>
</div>

<style>
.btn {
	background-color: #4CAF50;
	color: white;
	padding: 10px 15px;
	text-decoration: none;
	display: inline-block;
	border: none;
	cursor: pointer;
}

.btn:hover {
	background-color: #45a049;
}
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>