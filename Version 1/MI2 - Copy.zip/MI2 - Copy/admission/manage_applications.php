<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Only admission role allowed
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admission') {
    header('Location: ../index.php');
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['app_id'], $_POST['action'])) {
    $appId = (int)$_POST['app_id'];
    $action = $_POST['action'];
    $note = trim($_POST['note'] ?? '');
    
    // Debug: Check if we're receiving the POST data
    error_log("Processing action: $action for app ID: $appId");
    
    // Map action to status
    if ($action === 'approve') {
        $status = 'approved';
    } elseif ($action === 'verify') {
        $status = 'verified';
    } elseif ($action === 'reject') {
        $status = 'rejected';
    } else {
        $status = null;
    }

    if ($status) {
        try {
            $stmt = $pdo->prepare('UPDATE applications SET status = :status, admission_note = :admission_note WHERE id = :id');
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':admission_note', $note);
            $stmt->bindParam(':id', $appId, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                if ($status === 'approved') {
                    $successMessage = 'Application approved. You can now verify this application to allow the parent to proceed with enrollment.';
                } elseif ($status === 'verified') {
                    $successMessage = 'Application verified. The parent can now proceed to fill out the enrollment form.';
                    // Check if we should redirect the student automatically
                    try {
                        // Get the application details to check if it's a student application
                        $appStmt = $pdo->prepare('SELECT user_id FROM applications WHERE id = :id');
                        $appStmt->bindParam(':id', $appId, PDO::PARAM_INT);
                        $appStmt->execute();
                        $application = $appStmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($application && $application['user_id']) {
                            // Store in session that this application was just verified for automatic redirect
                            $_SESSION['auto_redirect_app_id'] = $appId;
                        }
                    } catch (PDOException $e) {
                        error_log("Error checking application for auto-redirect: " . $e->getMessage());
                    }
                } else {
                    $successMessage = 'Application rejected.';
                }
                // Redirect to refresh the page and show updated status
                header('Location: manage_applications.php?success=' . urlencode($successMessage));
                exit;
            } else {
                $message = 'Database error: Could not update application.';
            }
        } catch (PDOException $e) {
            error_log("Database error updating application: " . $e->getMessage());
            $message = 'Database error: Could not update application.';
        }
    } else {
        $message = 'Invalid action specified.';
    }
}

// Check for success message from redirect
if (isset($_GET['success'])) {
    $message = '<div class="alert alert-success">' . htmlspecialchars($_GET['success']) . '</div>';
} elseif (isset($_GET['error'])) {
    $message = '<div class="alert alert-danger">' . htmlspecialchars($_GET['error']) . '</div>';
}

$applications = [];
try {
    // Check if application_details table exists and adjust query accordingly
    $stmt = $pdo->query("
        SELECT a.*, u.username, u.email 
        FROM applications a 
        LEFT JOIN users u ON a.user_id = u.id
        ORDER BY a.created_at DESC
    ");
    $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error fetching applications: " . $e->getMessage());
    $message = 'Database error: Could not fetch applications.';
}

?>

<main class="container hero">
  <div class="hero-content">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>
    <div style="flex:1;">
      <h3>Manage Applications</h3>
      <?php if ($message): ?>
        <?= $message ?>
      <?php endif; ?>

      <?php if (!empty($applications)): ?>
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Student Name</th>
                <th>Submitted By</th>
                <th>Birthdate</th>
                <th>Contact</th>
                <th>Application Type</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($applications as $row): ?>
                <tr>
                  <td><?= htmlspecialchars($row['id']) ?></td>
                  <td>
                    <?= htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) ?>
                    <?php if (!empty($row['middle_name'])): ?>
                      (<?= htmlspecialchars($row['middle_name']) ?>)
                    <?php endif; ?>
                    <?php if (!empty($row['suffix'])): ?>
                      <?= htmlspecialchars($row['suffix']) ?>
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if (!empty($row['username'])): ?>
                      <?= htmlspecialchars($row['username']) ?>
                      <?php if (!empty($row['email'])): ?>
                        <br><small class="text-muted"><?= htmlspecialchars($row['email']) ?></small>
                      <?php endif; ?>
                    <?php else: ?>
                      <span class="text-muted">Unknown User</span>
                    <?php endif; ?>
                  </td>
                  <td><?= htmlspecialchars($row['birthdate']) ?></td>
                  <td><?= htmlspecialchars($row['contact']) ?></td>
                  <td><?= htmlspecialchars($row['application_type'] ?? 'N/A') ?></td>
                  <td>
                    <?php if ($row['status'] === 'pending'): ?>
                      <span class="badge bg-warning">Pending</span>
                    <?php elseif ($row['status'] === 'approved'): ?>
                      <span class="badge bg-info">Approved - Awaiting Verification</span>
                    <?php elseif ($row['status'] === 'verified'): ?>
                      <span class="badge bg-success">Verified - Ready for Enrollment</span>
                    <?php else: ?>
                      <span class="badge bg-danger">Rejected</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if ($row['status'] === 'pending'): ?>
                      <button class="btn btn-sm btn-success action-btn" data-app-id="<?= htmlspecialchars($row['id']) ?>" data-action="approve" data-bs-toggle="modal" data-bs-target="#actionModal">Approve</button>
                      <button class="btn btn-sm btn-danger action-btn" data-app-id="<?= htmlspecialchars($row['id']) ?>" data-action="reject" data-bs-toggle="modal" data-bs-target="#actionModal">Reject</button>
                      <button class="btn btn-sm btn-info view-details-btn" data-app-id="<?= htmlspecialchars($row['id']) ?>" data-bs-toggle="modal" data-bs-target="#detailsModal">View Details</button>
                    <?php elseif ($row['status'] === 'approved'): ?>
                      <button class="btn btn-sm btn-primary action-btn" data-app-id="<?= htmlspecialchars($row['id']) ?>" data-action="verify" data-bs-toggle="modal" data-bs-target="#actionModal">Verify</button>
                      <button class="btn btn-sm btn-info view-details-btn" data-app-id="<?= htmlspecialchars($row['id']) ?>" data-bs-toggle="modal" data-bs-target="#detailsModal">View Details</button>
                    <?php else: ?>
                      <button class="btn btn-sm btn-info view-details-btn" data-app-id="<?= htmlspecialchars($row['id']) ?>" data-bs-toggle="modal" data-bs-target="#detailsModal">View Details</button>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="alert alert-secondary">No applications found.</div>
      <?php endif; ?>
    </div>
  </div>
</main>

<!-- Modal for action note -->
<div class="modal fade" id="actionModal" tabindex="-1" aria-labelledby="actionModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="actionModalLabel">Application Action</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form id="actionForm" method="POST" action="">
        <div class="modal-body">
          <input type="hidden" name="app_id" id="modalAppId">
          <input type="hidden" name="action" id="modalAction">
          <div class="mb-3">
            <label for="modalNote" class="form-label">Note (optional)</label>
            <textarea name="note" id="modalNote" class="form-control" rows="4" placeholder="Add any notes or comments..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" id="modalSubmit">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal for viewing application details -->
<div class="modal fade" id="detailsModal" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="detailsModalLabel">Application Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="detailsModalBody">
        <!-- Details will be loaded here via JavaScript -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" onclick="printApplicationDetails()">
          <i class="fas fa-print"></i> Print
        </button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
// Modal behavior for approve/reject actions
document.addEventListener('DOMContentLoaded', function(){
  // Store application data for use in modals
  const applicationsData = <?= json_encode($applications) ?>;
  
  // Handle action button clicks (Approve/Reject/Verify)
  document.querySelectorAll('.action-btn').forEach(btn => {
    btn.addEventListener('click', function(e){
      const appId = this.dataset.appId;
      const action = this.dataset.action;
      
      // Update modal content
      const actionText = action === 'approve' ? 'Approve' : (action === 'verify' ? 'Verify' : 'Reject');
      document.getElementById('actionModalLabel').textContent = actionText + ' Application #' + appId;
      document.getElementById('modalAppId').value = appId;
      document.getElementById('modalAction').value = action;
      document.getElementById('modalNote').value = '';
      
      console.log('Action button clicked:', {appId, action});
    });
  });
  
  // Handle modal form submission - remove any previous event listeners and add new one
  const actionForm = document.getElementById('actionForm');
  const modalSubmit = document.getElementById('modalSubmit');
  
  // Remove any existing event listeners by cloning and replacing
  const newActionForm = actionForm.cloneNode(true);
  actionForm.parentNode.replaceChild(newActionForm, actionForm);
  
  // Now add the event listener to the new form
  document.getElementById('actionForm').addEventListener('submit', function(e) {
    console.log('Form submitted with app_id:', document.getElementById('modalAppId').value);
    console.log('Action:', document.getElementById('modalAction').value);
    // Form will submit normally
  });
  
  // View Details functionality
  document.querySelectorAll('.view-details-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const appId = this.dataset.appId;
      const appData = applicationsData.find(app => app.id == appId);
      
      if (appData) {
        let detailsHtml = `
          <div class="row">
            <div class="col-md-12">
              <h5>Application Information</h5>
              <hr>
              <p><strong>Application ID:</strong> ${appData.id || 'N/A'}<br>
              <strong>Submitted By:</strong> ${appData.username || 'Unknown User'} ${appData.email ? '(' + appData.email + ')' : ''}<br>
              <strong>Status:</strong> ${appData.status || 'N/A'}<br>
              <strong>Submitted On:</strong> ${appData.created_at ? new Date(appData.created_at).toLocaleString() : 'N/A'}</p>
            </div>
            
            <div class="col-md-12">
              <h5>Applicant Information</h5>
              <hr>
            </div>
            
            <div class="col-md-4">
              <strong>Last Name:</strong><br>${appData.last_name || 'N/A'}
            </div>
            <div class="col-md-4">
              <strong>First Name:</strong><br>${appData.first_name || 'N/A'}
            </div>
            <div class="col-md-4">
              <strong>Middle Name:</strong><br>${appData.middle_name || 'N/A'}
            </div>
            <div class="col-md-4">
              <strong>Suffix:</strong><br>${appData.suffix || 'N/A'}
            </div>
            <div class="col-md-4">
              <strong>Sex:</strong><br>${appData.sex || 'N/A'}
            </div>
            <div class="col-md-4">
              <strong>Date of Birth:</strong><br>${appData.birthdate || 'N/A'}
            </div>
            <div class="col-md-6">
              <strong>Place of Birth:</strong><br>${appData.place_of_birth || 'N/A'}
            </div>
            <div class="col-md-3">
              <strong>Nationality:</strong><br>${appData.nationality || 'N/A'}
            </div>
            <div class="col-md-3">
              <strong>Religion:</strong><br>${appData.religion || 'N/A'}
            </div>
            <div class="col-md-6">
              <strong>LRN:</strong><br>${appData.lrn || 'N/A'}
            </div>
            
            <div class="col-md-12 mt-4">
              <h5>Contact Information</h5>
              <hr>
            </div>
            
            <div class="col-md-6">
              <strong>Mobile Number:</strong><br>${appData.contact || 'N/A'}
            </div>
            <div class="col-md-6">
              <strong>Email Address:</strong><br>${appData.email_address || 'N/A'}
            </div>
            <div class="col-md-6">
              <strong>Home Address:</strong><br>${appData.home_address || 'N/A'}
            </div>
            <div class="col-md-6">
              <strong>Barangay:</strong><br>${appData.barangay || 'N/A'}
            </div>
            <div class="col-md-4">
              <strong>Municipality/City:</strong><br>${appData.municipality || 'N/A'}
            </div>
            <div class="col-md-4">
              <strong>Province:</strong><br>${appData.province || 'N/A'}
            </div>
            <div class="col-md-4">
              <strong>ZIP Code:</strong><br>${appData.zip_code || 'N/A'}
            </div>
            
            <div class="col-md-12 mt-4">
              <h5>Application Type</h5>
              <hr>
            </div>
            
            <div class="col-md-12">
              <strong>Type:</strong><br>${appData.application_type || 'N/A'}
            </div>
          </div>
        `;
        
        document.getElementById('detailsModalBody').innerHTML = detailsHtml;
      } else {
        document.getElementById('detailsModalBody').innerHTML = '<div class="alert alert-danger">Application details not found.</div>';
      }
    });
  });
});

function printApplicationDetails() {
  window.print();
}
</script>

<style>
@media print {
  /* Hide everything except the modal body when printing */
  body * {
    visibility: hidden;
  }
  
  #detailsModalBody,
  #detailsModalBody * {
    visibility: visible;
  }
  
  #detailsModalBody {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    padding: 20px;
  }
  
  /* Print styling */
  #detailsModalBody {
    font-size: 12pt;
  }
  
  #detailsModalBody h5 {
    color: maroon;
    font-size: 14pt;
    margin-top: 15px;
    page-break-after: avoid;
  }
  
  #detailsModalBody hr {
    border-top: 2px solid maroon;
  }
  
  #detailsModalBody .col-md-3,
  #detailsModalBody .col-md-4,
  #detailsModalBody .col-md-6,
  #detailsModalBody .col-md-12 {
    margin-bottom: 10px;
    page-break-inside: avoid;
  }
  
  #detailsModalBody strong {
    color: #000;
    font-weight: bold;
  }
  
  /* Add header to print */
  #detailsModalBody::before {
    content: "Mindanao Institute - Application Details";
    display: block;
    text-align: center;
    font-size: 18pt;
    font-weight: bold;
    color: maroon;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 3px solid maroon;
  }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>