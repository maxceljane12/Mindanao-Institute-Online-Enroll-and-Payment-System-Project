<?php
if (session_status() === PHP_SESSION_NONE) session_start();

$displayName = isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest';
$displayRole = isset($_SESSION['role']) ? htmlspecialchars(ucfirst($_SESSION['role'])) : 'Visitor';
$userId = isset($_SESSION['user_id']) ? htmlspecialchars($_SESSION['user_id']) : null;
?>

<div class="sidebar" id="mainSidebar">
  <!-- Sidebar toggle removed for hover-based expansion -->
  <div class="sidebar-user">
    <div class="sidebar-icon-wrapper">
      <i class="fas fa-user-circle"></i>
    </div>
    <div class="sidebar-user-info">
      <h3>User Info</h3>
      <div class="sidebar-user-name"><?php echo $displayName; ?></div>
      <div class="sidebar-user-role"><?php echo $displayRole; ?></div>
      <?php if ($userId): ?>
        <div class="sidebar-user-id">ID: <?php echo $userId; ?></div>
      <?php endif; ?>
    </div>
  </div>

  <hr class="sidebar-divider">

  <?php if (isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'student'): ?>
    <div class="sidebar-section-title">Student</div>
    <nav class="sidebar-nav">
      <a href="/MI2/student/student_dashboard.php" class="sidebar-link">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
      </a>
      <a href="/MI2/student/new_application.php" class="sidebar-link">
        <i class="fas fa-user-plus"></i>
        <span>New Student Enrollment</span>
      </a>
      <a href="/MI2/student/old_student_enrollment.php" class="sidebar-link">
        <i class="fas fa-user-graduate"></i>
        <span>Old Student Enrollment</span>
      </a>
    </nav>
  <?php endif; ?>

  <?php if (isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'parent'): ?>
    <div class="sidebar-section-title">Parent</div>
    <nav class="sidebar-nav">
      <a href="/MI2/Parent/parent_dashboard.php" class="sidebar-link">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
      </a>
      <a href="/MI2/Parent/parent_enrollment.php" class="sidebar-link">
        <i class="fas fa-child"></i>
        <span>Enroll a Student</span>
      </a>
    </nav>
  <?php endif; ?>

  <div class="sidebar-section-title">General</div>
  <nav class="sidebar-nav">
    <a href="/MI2/profile.php" class="sidebar-link">
      <i class="fas fa-id-card"></i>
      <span>Profile</span>
    </a>
    <a href="/MI2/settings.php" class="sidebar-link">
      <i class="fas fa-cog"></i>
      <span>Settings</span>
    </a>
    <?php if (isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'admission'): ?>
      <a href="/MI2/admission/admission_dashboard.php" class="sidebar-link">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
      </a>
      <a href="/MI2/admission/manage_applications.php" class="sidebar-link">
        <i class="fas fa-tasks"></i>
        <span>Manage Applications</span>
      </a>
    <?php endif; ?>
    <?php if (isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'cashier'): ?>
      <a href="/MI2/cashier/cashier_dashboard.php" class="sidebar-link">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
      </a>
      <a href="/MI2/cashier/manage_enrollment_fees.php" class="sidebar-link">
        <i class="fas fa-money-bill-wave"></i>
        <span>Enrollment Fee</span>
      </a>
      <a href="/MI2/cashier/verify_payments.php" class="sidebar-link">
        <i class="fas fa-check-circle"></i>
        <span>Verify Payments</span>
      </a>
      <a href="/MI2/cashier/transaction_records.php" class="sidebar-link">
        <i class="fas fa-receipt"></i>
        <span>Transaction Records</span>
      </a>
    <?php endif; ?>
    <?php if (isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'registrar'): ?>
      <a href="/MI2/registrar/registrar_dashboard.php" class="sidebar-link">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
      </a>
      <a href="/MI2/registrar/registrar_dashboard.php" class="sidebar-link">
        <i class="fas fa-user-check"></i>
        <span>Enroll Student</span>
      </a>
      <a href="/MI2/registrar/enrolled_students.php" class="sidebar-link">
        <i class="fas fa-users"></i>
        <span>Enrolled Students</span>
      </a>
    <?php endif; ?>
    <?php if (isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'admin'): ?>
      <a href="/MI2/admin/admin_dashboard.php" class="sidebar-link">
        <i class="fas fa-tachometer-alt"></i>
        <span>Admin Dashboard</span>
      </a>
      <div class="sidebar-section-title">System Management</div>
      <a href="/MI2/admin/manage_enrollment_periods.php" class="sidebar-link">
        <i class="fas fa-calendar-alt"></i>
        <span>Enrollment Periods</span>
      </a>
      <a href="/MI2/admin/manage_users.php" class="sidebar-link">
        <i class="fas fa-users"></i>
        <span>Manage Users</span>
      </a>
      <a href="/MI2/admin/manage_enrollment_statuses.php" class="sidebar-link">
        <i class="fas fa-tasks"></i>
        <span>Enrollment Statuses</span>
      </a>
      <a href="#" class="sidebar-link">
        <i class="fas fa-cog"></i>
        <span>System Settings</span>
      </a>
      
      <div class="sidebar-section-title">Financial Management</div>
      <a href="/MI2/admin/financial_reports.php" class="sidebar-link">
        <i class="fas fa-chart-line"></i>
        <span>Financial Reports</span>
      </a>
      <a href="/MI2/admin/manage_enrollment_fees.php" class="sidebar-link">
        <i class="fas fa-money-bill-wave"></i>
        <span>Enrollment Fees</span>
      </a>
      <a href="#" class="sidebar-link">
        <i class="fas fa-file-invoice"></i>
        <span>Billing Management</span>
      </a>
      
      <!-- Placeholder for extra test links -->
      <div class="extra-test-links"></div>
    <?php endif; ?>
    <a href="/MI2/logout.php" class="sidebar-link">
      <i class="fas fa-sign-out-alt"></i>
      <span>Logout</span>
    </a>
  </nav>
</div>

<!-- JavaScript toggle functionality removed for hover-based expansion -->