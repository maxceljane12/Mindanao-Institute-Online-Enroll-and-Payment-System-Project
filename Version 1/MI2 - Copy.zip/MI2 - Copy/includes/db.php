<?php
// Database credentials
$host = "localhost";
$user = "root";     // your MySQL username
$pass = "";         // your MySQL password (default in XAMPP is empty)
$dbname = "mi";

$dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// The $conn variable (mysqli object) is no longer used,
// so any code relying on $conn would need to be updated to use $pdo.
// My scripts already assume $pdo, so this change will align them.
?>