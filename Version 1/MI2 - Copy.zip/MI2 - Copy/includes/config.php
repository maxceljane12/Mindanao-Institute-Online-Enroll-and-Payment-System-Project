<?php
// config.php - Database credentials and other sensitive configurations

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', ''); // default is empty for XAMPP
define('DB_DATABASE', 'mi'); // This must match your phpMyAdmin database name

// PHPMailer SMTP settings (example, replace with your actual settings)
define('SMTP_HOST', 'smtp.example.com');
define('SMTP_USERNAME', 'user@example.com');
define('SMTP_PASSWORD', 'your_smtp_password');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls'); // Use 'ssl' for port 465, 'tls' for port 587

// Add any other sensitive configuration variables here


