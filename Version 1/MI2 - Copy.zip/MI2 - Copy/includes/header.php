<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
// Determine if current request is for a dashboard path so we can
// hide the Home/Register links when viewing dashboards.
$requestUri = $_SERVER['REQUEST_URI'] ?? '';
$isDashboard = (bool) preg_match('#/(student|Parent|cashier|registrar|admission|admin)/#i', $requestUri);
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mindanao Institute — Enrollment and Payment Management System</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
  <?php if (!$isDashboard): ?>
  <header class="site-header">
    <div class="container">
      <div class="site-header-inner">
        <a href="/MI2/index.php" class="site-header-brand">
          <img src="/MI2/image/logo.png" alt="Mindanao Institute Logo" class="site-header-logo">
          <div class="site-header-brand-text">
            <span class="site-header-name">Mindanao Institute</span>
            <span class="site-header-tagline">Enrollment and Payment Management System</span>
          </div>
        </a>

        <ul class="site-header-nav">
          <li><a href="/MI2/index.php">Home</a></li>
          <li><a href="/MI2/registration.php">Register</a></li>
        </ul>

        <?php if (isset($_SESSION['username'])): ?>
          <div class="site-header-user">
            
            
          </div>
        <?php endif; ?>
      </div>
    </div>
  </header>
  <?php endif; ?>
