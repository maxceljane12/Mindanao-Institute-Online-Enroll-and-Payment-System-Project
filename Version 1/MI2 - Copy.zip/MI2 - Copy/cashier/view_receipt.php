<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'cashier') {
    header('Location: ../index.php');
    exit;
}
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php'; // Include header for consistent styling

$billId = filter_input(INPUT_GET, 'bill_id', FILTER_VALIDATE_INT);
$billDetails = null;
$message = '';

if (!$billId) {
    $message = "Invalid bill ID provided.";
} else {
    try {
        $stmt = $pdo->prepare("
            SELECT b.*, e.first_name, e.last_name, e.enrollment_number, u.username as student_username
            FROM bills b
            JOIN enrollments e ON b.enrollment_id = e.id
            LEFT JOIN users u ON e.user_id = u.id
            WHERE b.bill_id = :bill_id
        ");
        $stmt->execute(['bill_id' => $billId]);
        $billDetails = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$billDetails) {
            $message = "Bill not found.";
        }
    } catch (PDOException $e) {
        error_log("Error fetching bill details: " . $e->getMessage());
        $message = "Database error: Could not fetch bill details.";
    }
}

?>

<main class="container hero">
    <div class="hero-content">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div style="flex:1;">
            <h1 class="display-6" style="color:var(--maroon);font-weight:700">View Payment Receipt</h1>
            <p class="small-muted">Details of the payment and uploaded receipt.</p>

            <?php if ($message): ?>
                <div class="alert alert-warning" role="alert">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php elseif ($billDetails): ?>
                <div class="card shadow-sm mt-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Bill Details (ID: <?= htmlspecialchars($billDetails['bill_id']) ?>)</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Student Name:</strong> <?= htmlspecialchars($billDetails['first_name'] . ' ' . $billDetails['last_name']) ?></p>
                                <p><strong>Enrollment No.:</strong> <?= htmlspecialchars($billDetails['enrollment_number'] ?? 'N/A') ?></p>
                                <p><strong>Bill Type:</strong> <?= htmlspecialchars($billDetails['bill_type']) ?></p>
                                <p><strong>Description:</strong> <?= htmlspecialchars($billDetails['description'] ?? 'N/A') ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Amount:</strong> ₱<?= htmlspecialchars(number_format($billDetails['amount'], 2)) ?></p>
                                <p><strong>Payment Method:</strong> <?= htmlspecialchars(str_replace('_', ' ', $billDetails['payment_method'] ?? 'N/A')) ?></p>
                                <p><strong>Status:</strong> <?= htmlspecialchars(str_replace('_', ' ', $billDetails['status'])) ?></p>
                                <p><strong>Date Submitted:</strong> <?= htmlspecialchars((new DateTime($billDetails['created_at']))->format('Y-m-d H:i')) ?></p>
                                <?php if ($billDetails['verified_by']): ?>
                                    <p><strong>Verified By:</strong> <?= htmlspecialchars($billDetails['verified_by']) ?></p>
                                <?php endif; ?>
                                <?php if ($billDetails['verification_note']): ?>
                                    <p><strong>Verification Note:</strong> <?= htmlspecialchars($billDetails['verification_note']) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <hr>
                        <h4>Proof of Payment</h4>
                        <?php if ($billDetails['receipt_path']): ?>
                            <?php
                            $receiptPath = htmlspecialchars(str_replace('../', '/', $billDetails['receipt_path']));
                            $fileExtension = pathinfo($receiptPath, PATHINFO_EXTENSION);
                            ?>
                            <?php if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                <img src="<?= $receiptPath ?>" alt="Payment Receipt" class="img-fluid" style="max-width: 100%; height: auto;">
                            <?php elseif ($fileExtension === 'pdf'): ?>
                                <p><a href="<?= $receiptPath ?>" target="_blank">View PDF Receipt</a></p>
                                <iframe src="<?= $receiptPath ?>" width="100%" height="600px" style="border: none;"></iframe>
                            <?php else: ?>
                                <p>Unsupported file type for preview. <a href="<?= $receiptPath ?>" target="_blank">Download Receipt</a></p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p>No receipt uploaded for this payment.</p>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer text-end">
                        <button class="btn btn-secondary" onclick="window.print()">Print Receipt</button>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
