<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'cashier') {
    header('Location: ../index.php');
    exit;
}
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$message = '';

// Handle payment verification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bill_id']) && isset($_POST['action'])) {
    $billId = filter_input(INPUT_POST, 'bill_id', FILTER_VALIDATE_INT);
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
    $note = filter_input(INPUT_POST, 'note', FILTER_SANITIZE_STRING);

    try {
        $pdo->beginTransaction();

        if ($action === 'approve') {
            // Get bill details before updating
            $stmt_get_bill = $pdo->prepare("SELECT amount, payment_method FROM bills WHERE bill_id = :bill_id");
            $stmt_get_bill->execute(['bill_id' => $billId]);
            $bill_details = $stmt_get_bill->fetch(PDO::FETCH_ASSOC);

            if (!$bill_details) {
                throw new Exception("Bill not found.");
            }

            $sql = "UPDATE bills SET status = 'paid', verified_by = :verified_by, verification_note = :note, updated_at = NOW() WHERE bill_id = :bill_id";
            error_log("Verifying payment with query: " . $sql);
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['bill_id' => $billId, 'verified_by' => $_SESSION['user_id'], 'note' => $note]);

            // Create payment record
            $stmt_payment = $pdo->prepare("
                INSERT INTO payments (bill_id, amount, payment_method, payment_date) 
                VALUES (:bill_id, :amount, :payment_method, NOW())
            ");
            $stmt_payment->execute([
                'bill_id' => $billId,
                'amount' => $bill_details['amount'],
                'payment_method' => $bill_details['payment_method']
            ]);

            // Update the enrollment status to 'paid' after payment verification
            // This allows the registrar to see which students have paid and can be enrolled
            $stmt_get_enrollment = $pdo->prepare("SELECT enrollment_id FROM bills WHERE bill_id = :bill_id");
            $stmt_get_enrollment->execute(['bill_id' => $billId]);
            $enrollment_id_to_update = $stmt_get_enrollment->fetchColumn();

            if ($enrollment_id_to_update) {
                $stmt_enrollment = $pdo->prepare("UPDATE enrollments SET status = 'paid' WHERE id = :enrollment_id");
                $stmt_enrollment->execute(['enrollment_id' => $enrollment_id_to_update]);
                error_log("Successfully updated enrollment status for enrollment_id: {$enrollment_id_to_update} to paid");
            } else {
                error_log("Could not find enrollment_id for bill_id: {$billId}");
            }
            
            $pdo->commit();
            $message = "Bill #{$billId} approved successfully. The registrar will now manually enroll the student.";
        } elseif ($action === 'reject') {
            $sql = "UPDATE bills SET status = 'cancelled', verified_by = :verified_by, verification_note = :note, updated_at = NOW() WHERE bill_id = :bill_id";
            error_log("Verifying payment with query: " . $sql);
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['bill_id' => $billId, 'verified_by' => $_SESSION['user_id'], 'note' => $note]);

            // Get enrollment ID first to ensure it exists
            $stmt_get_enrollment = $pdo->prepare("SELECT enrollment_id FROM bills WHERE bill_id = :bill_id");
            $stmt_get_enrollment->execute(['bill_id' => $billId]);
            $enrollment_id_to_update = $stmt_get_enrollment->fetchColumn();

            if ($enrollment_id_to_update) {
                // Additionally update the enrollment status to 'cancelled'
                $stmt_enrollment = $pdo->prepare("UPDATE enrollments SET status = 'cancelled' WHERE id = :enrollment_id");
                $stmt_enrollment->execute(['enrollment_id' => $enrollment_id_to_update]);
                error_log("Successfully updated enrollment status for enrollment_id: {$enrollment_id_to_update} to cancelled");
                $message = "Bill #{$billId} rejected. Enrollment status updated to 'cancelled'.";
            } else {
                error_log("Could not find enrollment_id for bill_id: {$billId}");
                $message = "Bill #{$billId} rejected, but could not update enrollment status (enrollment ID not found).";
            }
            
            $pdo->commit();
        } else {
            $message = "Invalid action.";
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Error verifying payment: " . $e->getMessage());
        $message = "Database error: Could not process verification. " . $e->getMessage();
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Error verifying payment: " . $e->getMessage());
        $message = "Error: " . $e->getMessage();
    }
}

// Fetch all relevant bills for verification and display (pending, pending_verification, paid, cancelled)
$unpaidBills = [];
$paidBills = [];
try {
    $stmt = $pdo->prepare("
        SELECT b.*, e.first_name, e.last_name, e.enrollment_number, u.username as student_username
        FROM bills b
        JOIN enrollments e ON b.enrollment_id = e.id
        LEFT JOIN users u ON e.user_id = u.id
        WHERE b.status IN ('pending', 'pending_verification', 'cancelled')
           OR (b.status = 'paid' AND b.payment_method IN ('gcash', 'walk_in'))
        ORDER BY b.created_at DESC
    ");
    $stmt->execute();
    $allBills = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($allBills as $bill) {
        if ($bill['status'] === 'paid') {
            $paidBills[] = $bill;
        } else {
            $unpaidBills[] = $bill;
        }
    }

} catch (PDOException $e) {
    error_log("Error fetching bills for cashier: " . $e->getMessage());
    $message = "Database error: Could not fetch bills.";
}
?>

<main class="container hero">
    <div class="hero-content">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div style="flex:1;">
            <h1 class="display-6" style="color:var(--maroon);font-weight:700">Verify Payments</h1>
            <p class="small-muted">Review and verify student payments.</p>

            <?php if ($message): ?>
                <div class="alert alert-info" role="alert">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <h2 class="mt-4">Unpaid Payments (Pending / Awaiting Verification / Cancelled)</h2>
            <?php if (empty($unpaidBills)): ?>
                <p>No unpaid payments to verify at this time.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Bill ID</th>
                                <th>Student Name</th>
                                <th>Enrollment No.</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th>Receipt</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($unpaidBills as $bill): ?>
                                <tr>
                                    <td><?= htmlspecialchars($bill['bill_id']) ?></td>
                                    <td><?= htmlspecialchars($bill['first_name'] . ' ' . $bill['last_name']) ?></td>
                                    <td><?= htmlspecialchars($bill['enrollment_number'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($bill['bill_type']) ?></td>
                                    <td>₱<?= htmlspecialchars(number_format($bill['amount'], 2)) ?></td>
                                    <td><?= htmlspecialchars(str_replace('_', ' ', $bill['payment_method'] ?? 'N/A')) ?></td>
                                    <td><?= htmlspecialchars(str_replace('_', ' ', $bill['status'])) ?></td>
                                    <td>
                                        <?php if (!empty($bill['receipt_path'])): ?>
                                            <a href="/MI2/cashier/view_receipt.php?bill_id=<?= htmlspecialchars($bill['bill_id']) ?>" target="_blank" class="btn btn-sm btn-info">View Receipt</a>
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-success verify-btn" data-bs-toggle="modal" data-bs-target="#verificationModal" data-bill-id="<?= $bill['bill_id'] ?>" data-action="approve">Approve</button>
                                        <button class="btn btn-sm btn-danger verify-btn" data-bs-toggle="modal" data-bs-target="#verificationModal" data-bill-id="<?= $bill['bill_id'] ?>" data-action="reject">Reject</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <h2 class="mt-4">Paid Payments</h2>
            <?php if (empty($paidBills)): ?>
                <p>No paid payments found.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Bill ID</th>
                                <th>Student Name</th>
                                <th>Enrollment No.</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th>Receipt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($paidBills as $bill): ?>
                                <tr>
                                    <td><?= htmlspecialchars($bill['bill_id']) ?></td>
                                    <td><?= htmlspecialchars($bill['first_name'] . ' ' . $bill['last_name']) ?></td>
                                    <td><?= htmlspecialchars($bill['enrollment_number'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($bill['bill_type']) ?></td>
                                    <td>₱<?= htmlspecialchars(number_format($bill['amount'], 2)) ?></td>
                                    <td><?= htmlspecialchars(str_replace('_', ' ', $bill['payment_method'] ?? 'N/A')) ?></td>
                                    <td><?= htmlspecialchars(str_replace('_', ' ', $bill['status'])) ?></td>
                                    <td>
                                        <?php if (!empty($bill['receipt_path'])): ?>
                                            <a href="/MI2/cashier/view_receipt.php?bill_id=<?= htmlspecialchars($bill['bill_id']) ?>" target="_blank" class="btn btn-sm btn-info">View Receipt</a>
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<!-- Modal for action note -->
<div class="modal fade" id="verificationModal" tabindex="-1" aria-labelledby="verificationModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="verificationModalLabel">Verify Payment</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form id="verificationForm" method="post">
        <div class="modal-body">
          <input type="hidden" name="bill_id" id="modalVerifyBillId">
          <input type="hidden" name="action" id="modalVerifyAction">
          <div class="mb-3">
            <label for="verification_note" class="form-label">Note (optional)</label>
            <textarea name="note" id="verification_note" class="form-control" rows="3"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" id="modalVerifySubmit">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var verificationModal = document.getElementById('verificationModal');
    verificationModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget; // Button that triggered the modal
        var billId = button.getAttribute('data-bill-id');
        var action = button.getAttribute('data-action');

        var modalVerifyBillId = verificationModal.querySelector('#modalVerifyBillId');
        var modalVerifyAction = verificationModal.querySelector('#modalVerifyAction');
        var verificationModalLabel = verificationModal.querySelector('#verificationModalLabel');

        modalVerifyBillId.value = billId;
        modalVerifyAction.value = action;
        verificationModalLabel.textContent = (action === 'approve' ? 'Approve' : 'Reject') + ' Payment for Bill #' + billId;
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>