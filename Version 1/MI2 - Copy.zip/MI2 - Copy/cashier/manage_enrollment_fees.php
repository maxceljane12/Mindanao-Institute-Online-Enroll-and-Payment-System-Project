<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'cashier') {
	header('Location: ../index.php');
	exit;
}
include __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/db.php'; // Include database connection

// Fetch enrollment fees
try {
    $stmt = $pdo->query("SELECT * FROM enrollment_fees ORDER BY school_year DESC, fee_name ASC");
    $enrollmentFees = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching enrollment fees: " . $e->getMessage());
    $_SESSION['error_message'] = "Database error: Could not fetch enrollment fees.";
    $enrollmentFees = [];
}
?>

<main class="container hero">
	<div class="hero-content">
		<?php include __DIR__ . '/../includes/sidebar.php'; ?>
		<div style="flex:1;">
			<h1 class="display-6" style="color:var(--maroon);font-weight:700">Manage Enrollment Fees</h1>
			<p class="small-muted">This is where you can manage enrollment fees.</p>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success" role="alert">
                    <?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                </div>
            <?php endif; ?>

            <h2 class="mt-4">Existing Enrollment Fees</h2>
            <?php if (empty($enrollmentFees)): ?>
                <p>No enrollment fees found.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Fee Name</th>
                                <th>Amount</th>
                                <th>School Year</th>
                                <th>Applicable To</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($enrollmentFees as $fee): ?>
                                <tr>
                                    <td><?= htmlspecialchars($fee['fee_name']) ?></td>
                                    <td><?= htmlspecialchars(number_format($fee['amount'], 2)) ?></td>
                                    <td><?= htmlspecialchars($fee['school_year']) ?></td>
                                    <td><?= htmlspecialchars($fee['applicable_to_group']) ?></td>
                                    <td><?= htmlspecialchars($fee['description']) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-info edit-fee-btn" data-fee='<?= json_encode($fee) ?>'>Edit</button>
                                        <form action="../PHP/process_enrollment_fee.php" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this fee?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="fee_id" value="<?= $fee['fee_id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <!-- Form for adding/editing fees -->
            <h2 class="mt-4">Add New Enrollment Fee</h2>
            <form action="../PHP/process_enrollment_fee.php" method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="add" id="fee-action">
                <input type="hidden" name="fee_id" id="fee-id">
                
                <div class="mb-3">
                    <label for="fee-name" class="form-label">Fee Name</label>
                    <input type="text" class="form-control" id="fee-name" name="fee_name" required>
                    <div class="invalid-feedback">
                        Please provide a fee name.
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="amount" class="form-label">Amount</label>
                    <input type="number" step="0.01" class="form-control" id="amount" name="amount" required min="0.01">
                    <div class="invalid-feedback">
                        Please provide a valid amount.
                    </div>
                </div>

                <div class="mb-3">
                    <label for="school-year" class="form-label">School Year</label>
                    <input type="text" class="form-control" id="school-year" name="school_year" placeholder="e.g., 2023-2024" required>
                    <div class="invalid-feedback">
                        Please provide the school year.
                    </div>
                </div>

                <div class="mb-3">
                    <label for="applicable-to-group" class="form-label">Applicable To Group</label>
                    <input type="text" class="form-control" id="applicable-to-group" name="applicable_to_group" placeholder="e.g., All, Kindergarten, Grade 1" required>
                    <div class="invalid-feedback">
                        Please specify the applicable group.
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">Description (Optional)</label>
                    <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary" id="fee-form-submit-btn">Add Fee</button>
                <button type="button" class="btn btn-secondary" id="cancel-edit-btn" style="display:none;">Cancel Edit</button>
            </form>

		</div>
	</div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const editButtons = document.querySelectorAll('.edit-fee-btn');
    const feeForm = document.querySelector('form');
    const feeIdInput = document.getElementById('fee-id');
    const feeNameInput = document.getElementById('fee-name');
    const amountInput = document.getElementById('amount');
    const schoolYearInput = document.getElementById('school-year');
    const applicableToGroupInput = document.getElementById('applicable-to-group');
    const descriptionInput = document.getElementById('description');
    const formActionInput = document.getElementById('fee-action');
    const formSubmitBtn = document.getElementById('fee-form-submit-btn');
    const cancelEditBtn = document.getElementById('cancel-edit-btn');

    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const fee = JSON.parse(this.dataset.fee);
            
            feeIdInput.value = fee.fee_id;
            feeNameInput.value = fee.fee_name;
            amountInput.value = parseFloat(fee.amount).toFixed(2);
            schoolYearInput.value = fee.school_year;
            applicableToGroupInput.value = fee.applicable_to_group;
            descriptionInput.value = fee.description;

            formActionInput.value = 'update';
            formSubmitBtn.textContent = 'Update Fee';
            cancelEditBtn.style.display = 'inline-block';

            // Scroll to the form
            feeForm.scrollIntoView({ behavior: 'smooth' });
        });
    });

    cancelEditBtn.addEventListener('click', function() {
        feeIdInput.value = '';
        feeNameInput.value = '';
        amountInput.value = '';
        schoolYearInput.value = '';
        applicableToGroupInput.value = '';
        descriptionInput.value = '';

        formActionInput.value = 'add';
        formSubmitBtn.textContent = 'Add Fee';
        cancelEditBtn.style.display = 'none';

        feeForm.reset(); // Resets form validation state as well
    });

    // Bootstrap form validation
    (function () {
      'use strict'
      var forms = document.querySelectorAll('.needs-validation')
      Array.prototype.slice.call(forms)
        .forEach(function (form) {
          form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
            }
            form.classList.add('was-validated')
          }, false)
        })
    })()
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>