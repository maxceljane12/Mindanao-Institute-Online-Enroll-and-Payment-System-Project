<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'cashier') {
    header('Location: ../index.php');
    exit;
}
require_once __DIR__ . '/../includes/db.php';

// Check if user is still active
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !$user['is_active']) {
        // User is deactivated, log them out
        session_destroy();
        header('Location: ../index.php?error=account_deactivated');
        exit;
    }
}

// Fetch summary data
$total_paid = 0;
$total_pending_verification = 0;
$pending_count = 0;

try {
    // Get total paid amount
    $stmt = $pdo->query("SELECT SUM(amount) as total_paid FROM bills WHERE status = 'paid'");
    $total_paid_result = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_paid = $total_paid_result['total_paid'] ?? 0;

    // Get total pending verification amount
    $stmt = $pdo->query("SELECT SUM(amount) as total_pending FROM bills WHERE status = 'pending_verification'");
    $total_pending_result = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_pending_verification = $total_pending_result['total_pending'] ?? 0;

    // Get pending payments count
    $stmt = $pdo->query("SELECT COUNT(*) as pending_count FROM bills WHERE status IN ('pending', 'pending_verification')");
    $pending_count_result = $stmt->fetch(PDO::FETCH_ASSOC);
    $pending_count = $pending_count_result['pending_count'] ?? 0;

    // Get recent transactions
    try {
        $stmt = $pdo->query("
            SELECT
                b.bill_id,
                e.first_name,
                e.last_name,
                b.amount,
                b.status,
                b.created_at
            FROM
                bills b
            LEFT JOIN
                enrollments e ON b.enrollment_id = e.id
            WHERE b.status IN ('paid', 'pending_verification')
            ORDER BY
                b.created_at DESC
            LIMIT 10
        ");
        $paid_bills = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error_message = "Database error: " . $e->getMessage();
    }
    
    // Get yearly revenue data for graph
    $yearly_revenue = [];
    try {
        $stmt = $pdo->query("
            SELECT 
                YEAR(created_at) as year,
                SUM(amount) as total_revenue
            FROM bills
            WHERE status = 'paid'
            GROUP BY YEAR(created_at)
            ORDER BY year ASC
        ");
        $yearly_revenue = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error fetching yearly revenue: " . $e->getMessage());
    }

} catch (PDOException $e) {
    // Handle database errors
    $error_message = "Database error: " . $e->getMessage();
    // You might want to log this error
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mindanao Institute — Enrollment and Payment Management System</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Cashier Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print()">
                            <i class="fas fa-print"></i> Print Revenue Report
                        </button>
                    </div>
                </div>
            </div>

            <?php if (isset($error_message)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card text-white bg-success h-100">
                        <div class="card-header">Financial Summary</div>
                        <div class="card-body">
                            <h5 class="card-title">Total Revenue</h5>
                            <p class="card-text display-6">₱<?= htmlspecialchars(number_format($total_paid, 2)) ?></p>
                            <small>All time collected payments</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card text-white bg-info h-100">
                        <div class="card-header">Pending Verification</div>
                        <div class="card-body">
                            <h5 class="card-title">Awaiting Approval</h5>
                            <p class="card-text display-6">₱<?= htmlspecialchars(number_format($total_pending_verification, 2)) ?></p>
                            <small>Paid awaiting verification</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card text-white bg-warning h-100">
                        <div class="card-header">Pending Payments</div>
                        <div class="card-body">
                            <h5 class="card-title">Payments to Process</h5>
                            <p class="card-text display-6"><?= htmlspecialchars($pending_count) ?></p>
                            <a href="verify_payments.php" class="text-white">View Details &rarr;</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h5 class="my-0 fw-normal"><i class="fas fa-chart-line"></i> Yearly Enrollment Revenue</h5>
                </div>
                <div class="card-body">
                    <canvas id="yearlyRevenueChart" style="max-height: 400px;"></canvas>
                </div>
            </div>

            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h5 class="my-0 fw-normal">Recent Transactions</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($paid_bills)): ?>
                        <p class="text-muted">No transactions found.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Bill ID</th>
                                        <th>Student Name</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Date Submitted</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($paid_bills as $bill): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($bill['bill_id']) ?></td>
                                            <td><?= htmlspecialchars($bill['first_name'] . ' ' . $bill['last_name']) ?></td>
                                            <td>₱<?= htmlspecialchars(number_format($bill['amount'], 2)) ?></td>
                                            <td>
                                                <span class="badge bg-<?= $bill['status'] === 'paid' ? 'success' : 'info' ?>">
                                                    <?= htmlspecialchars(ucfirst(str_replace('_', ' ', $bill['status']))) ?>
                                                </span>
                                            </td>
                                            <td><?= htmlspecialchars(date('M d, Y', strtotime($bill['created_at']))) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<script>
// Yearly Revenue Chart
const yearlyRevenueData = <?= json_encode($yearly_revenue) ?>;

const years = yearlyRevenueData.map(item => item.year);
const revenues = yearlyRevenueData.map(item => parseFloat(item.total_revenue));

const ctx = document.getElementById('yearlyRevenueChart').getContext('2d');
const yearlyRevenueChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: years,
        datasets: [{
            label: 'Total Revenue (₱)',
            data: revenues,
            backgroundColor: 'rgba(128, 0, 0, 0.7)',
            borderColor: 'maroon',
            borderWidth: 2,
            borderRadius: 5
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                position: 'top'
            },
            title: {
                display: true,
                text: 'Enrollment Revenue by Year',
                font: {
                    size: 16,
                    weight: 'bold'
                },
                color: 'maroon'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        let label = context.dataset.label || '';
                        if (label) {
                            label += ': ';
                        }
                        label += '₱' + context.parsed.y.toLocaleString('en-PH', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                        return label;
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₱' + value.toLocaleString('en-PH');
                    }
                },
                title: {
                    display: true,
                    text: 'Revenue (₱)',
                    font: {
                        size: 12,
                        weight: 'bold'
                    }
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Year',
                    font: {
                        size: 12,
                        weight: 'bold'
                    }
                }
            }
        }
    }
});
</script>

<style>
@media print {
    .no-print {
        display: none !important;
    }
    
    body {
        font-size: 12pt;
    }
    
    .card {
        border: 1px solid #000;
        page-break-inside: avoid;
    }
    
    table {
        border-collapse: collapse;
        width: 100%;
        margin-top: 20px;
    }
    
    th, td {
        border: 1px solid #000;
        padding: 8px;
        text-align: left;
    }
    
    th {
        background-color: #f2f2f2;
    }
    
    .print-header {
        text-align: center;
        margin-bottom: 20px;
        border-bottom: 2px solid #000;
        padding-bottom: 10px;
    }
    
    .print-header h1 {
        margin: 0;
        font-size: 24px;
    }
    
    .print-header p {
        margin: 5px 0 0 0;
    }
    
    .stats-container {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }
    
    .stat-box {
        border: 1px solid #000;
        padding: 10px;
        text-align: center;
        flex: 1;
        margin: 0 5px;
    }
    
    .stat-box h3 {
        margin-top: 0;
        font-size: 16px;
    }
    
    .stat-value {
        font-size: 18px;
        font-weight: bold;
    }
}
</style>

<script>
// Add print header when printing
window.onbeforeprint = function() {
    // Create a print header
    var printHeader = document.createElement('div');
    printHeader.className = 'print-header';
    printHeader.innerHTML = `
        <h1>Mindanao Institute</h1>
        <h2>Cashier Revenue Report</h2>
        <p>Generated on ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}</p>
    `;
    
    // Create stats summary for print
    var statsContainer = document.createElement('div');
    statsContainer.className = 'stats-container';
    statsContainer.innerHTML = `
        <div class="stat-box">
            <h3>Total Revenue</h3>
            <div class="stat-value">₱<?= number_format($total_paid, 2) ?></div>
        </div>
        <div class="stat-box">
            <h3>Pending Verification</h3>
            <div class="stat-value">₱<?= number_format($total_pending_verification, 2) ?></div>
        </div>
        <div class="stat-box">
            <h3>Pending Payments</h3>
            <div class="stat-value"><?= $pending_count ?></div>
        </div>
    `;
    
    // Insert at the beginning of the container
    var container = document.querySelector('.container-fluid');
    container.insertBefore(statsContainer, container.firstChild);
    container.insertBefore(printHeader, container.firstChild);
};
window.onafterprint = function() {
    // Remove print header after printing
    var printHeaders = document.querySelectorAll('.print-header, .stats-container');
    printHeaders.forEach(function(el) {
        el.remove();
    });
};
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
