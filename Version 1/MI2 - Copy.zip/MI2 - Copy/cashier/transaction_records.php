<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'cashier') {
    header('Location: ../index.php');
    exit;
}
include __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/db.php';

// Get filter parameters
$filter_status = $_GET['filter_status'] ?? 'all';
$search_query = $_GET['search'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Get all transaction records with filters
$all_transactions = [];
try {
    $sql = "
        SELECT
            b.bill_id,
            b.enrollment_id,
            e.first_name,
            e.last_name,
            e.enrollment_number,
            b.amount,
            b.status,
            b.created_at,
            b.updated_at
        FROM
            bills b
        LEFT JOIN
            enrollments e ON b.enrollment_id = e.id
        WHERE 1=1
    ";
    
    $params = [];
    
    if ($filter_status !== 'all') {
        $sql .= " AND b.status = :status";
        $params[':status'] = $filter_status;
    }
    
    if (!empty($search_query)) {
        $sql .= " AND (b.bill_id LIKE :search OR e.first_name LIKE :search OR e.last_name LIKE :search OR e.enrollment_number LIKE :search)";
        $params[':search'] = '%' . $search_query . '%';
    }
    
    if (!empty($date_from)) {
        $sql .= " AND DATE(b.created_at) >= :date_from";
        $params[':date_from'] = $date_from;
    }
    
    if (!empty($date_to)) {
        $sql .= " AND DATE(b.created_at) <= :date_to";
        $params[':date_to'] = $date_to;
    }
    
    $sql .= " ORDER BY b.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $all_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $error_message = "Database error: " . $e->getMessage();
}

// Calculate totals for filtered results
$total_amount = 0;
$paid_amount = 0;
$pending_amount = 0;

foreach ($all_transactions as $transaction) {
    $total_amount += $transaction['amount'];
    if ($transaction['status'] === 'paid') {
        $paid_amount += $transaction['amount'];
    } elseif ($transaction['status'] === 'pending' || $transaction['status'] === 'pending_verification') {
        $pending_amount += $transaction['amount'];
    }
}
?>
<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="fas fa-receipt"></i> Transaction Records</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print Records
                    </button>
                </div>
            </div>

            <?php if (isset($error_message)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>

            <!-- Filter Section -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="my-0"><i class="fas fa-filter"></i> Filter Transactions</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label for="filter_status" class="form-label">Status</label>
                                <select class="form-select" id="filter_status" name="filter_status">
                                    <option value="all" <?= $filter_status === 'all' ? 'selected' : '' ?>>All Status</option>
                                    <option value="pending" <?= $filter_status === 'pending' ? 'selected' : '' ?>>Pending</option>
                                    <option value="pending_verification" <?= $filter_status === 'pending_verification' ? 'selected' : '' ?>>Pending Verification</option>
                                    <option value="paid" <?= $filter_status === 'paid' ? 'selected' : '' ?>>Paid</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="search" class="form-label">Search</label>
                                <input type="text" class="form-control" id="search" name="search" placeholder="Bill ID, Name, or Enrollment #" value="<?= htmlspecialchars($search_query) ?>">
                            </div>
                            <div class="col-md-2">
                                <label for="date_from" class="form-label">Date From</label>
                                <input type="date" class="form-control" id="date_from" name="date_from" value="<?= htmlspecialchars($date_from) ?>">
                            </div>
                            <div class="col-md-2">
                                <label for="date_to" class="form-label">Date To</label>
                                <input type="date" class="form-control" id="date_to" name="date_to" value="<?= htmlspecialchars($date_to) ?>">
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-search"></i> Filter
                                </button>
                                <a href="transaction_records.php" class="btn btn-secondary">
                                    <i class="fas fa-redo"></i> Reset
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Summary Cards -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card text-white bg-primary">
                        <div class="card-body">
                            <h6 class="card-title">Total Transactions</h6>
                            <h3>₱<?= number_format($total_amount, 2) ?></h3>
                            <small><?= count($all_transactions) ?> records</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-success">
                        <div class="card-body">
                            <h6 class="card-title">Paid Amount</h6>
                            <h3>₱<?= number_format($paid_amount, 2) ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-warning">
                        <div class="card-body">
                            <h6 class="card-title">Pending Amount</h6>
                            <h3>₱<?= number_format($pending_amount, 2) ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Transaction Records Table -->
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="my-0">All Transactions (<?= count($all_transactions) ?>)</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($all_transactions)): ?>
                        <p class="text-muted text-center py-4">No transactions found matching your filters.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Bill ID</th>
                                        <th>Enrollment #</th>
                                        <th>Student Name</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Created Date</th>
                                        <th>Updated Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($all_transactions as $transaction): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($transaction['bill_id']) ?></td>
                                            <td><?= htmlspecialchars($transaction['enrollment_number'] ?? 'N/A') ?></td>
                                            <td><?= htmlspecialchars($transaction['first_name'] . ' ' . $transaction['last_name']) ?></td>
                                            <td>₱<?= number_format($transaction['amount'], 2) ?></td>
                                            <td>
                                                <?php
                                                $badge_class = 'secondary';
                                                if ($transaction['status'] === 'paid') {
                                                    $badge_class = 'success';
                                                } elseif ($transaction['status'] === 'pending_verification') {
                                                    $badge_class = 'info';
                                                } elseif ($transaction['status'] === 'pending') {
                                                    $badge_class = 'warning';
                                                }
                                                ?>
                                                <span class="badge bg-<?= $badge_class ?>">
                                                    <?= htmlspecialchars(ucfirst(str_replace('_', ' ', $transaction['status']))) ?>
                                                </span>
                                            </td>
                                            <td><?= date('M d, Y g:i A', strtotime($transaction['created_at'])) ?></td>
                                            <td><?= $transaction['updated_at'] ? date('M d, Y g:i A', strtotime($transaction['updated_at'])) : 'N/A' ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<style>
@media print {
    .btn-toolbar, .no-print, .sidebar, .card-header button {
        display: none !important;
    }
    
    body {
        font-size: 12pt;
    }
    
    .card {
        border: 1px solid #000;
        page-break-inside: avoid;
        margin-bottom: 20px;
    }
    
    table {
        border-collapse: collapse;
        width: 100%;
    }
    
    th, td {
        border: 1px solid #000;
        padding: 8px;
        text-align: left;
    }
    
    th {
        background-color: #f2f2f2;
    }
    
    .print-header {
        text-align: center;
        margin-bottom: 20px;
        border-bottom: 2px solid #000;
        padding-bottom: 10px;
    }
    
    .col-md-9 {
        margin-left: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
    }
}
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>
