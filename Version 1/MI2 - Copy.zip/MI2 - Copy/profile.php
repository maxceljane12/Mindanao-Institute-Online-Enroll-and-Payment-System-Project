<?php
require_once __DIR__ . '/includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Fetch user data
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        header('Location: logout.php');
        exit;
    }
} catch (PDOException $e) {
    error_log("Error fetching user profile: " . $e->getMessage());
    $error = "Failed to load profile data.";
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $last_name = trim($_POST['last_name']);
    $extension = trim($_POST['extension']);
    $email = trim($_POST['email']);
    $contact = trim($_POST['contact']);
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET 
            first_name = ?, 
            middle_name = ?, 
            last_name = ?, 
            extension = ?, 
            email = ?, 
            contact = ?,
            updated_at = NOW() 
            WHERE id = ?");
        
        $stmt->execute([
            $first_name,
            $middle_name,
            $last_name,
            $extension,
            $email,
            $contact,
            $user_id
        ]);
        
        $message = "Profile updated successfully!";
        
        // Refresh user data
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("Error updating profile: " . $e->getMessage());
        $error = "Failed to update profile.";
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($new_password !== $confirm_password) {
        $error = "New passwords do not match.";
    } elseif (strlen($new_password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif (password_verify($current_password, $user['password'])) {
        try {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$hashed_password, $user_id]);
            $message = "Password changed successfully!";
        } catch (PDOException $e) {
            error_log("Error changing password: " . $e->getMessage());
            $error = "Failed to change password.";
        }
    } else {
        $error = "Current password is incorrect.";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My Profile - Mindanao Institute</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>

<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">My Profile</h1>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success" role="alert">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger" role="alert">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-8">
                    <!-- Profile Information Card -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal">Profile Information</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="id_number" class="form-label">ID Number</label>
                                        <input type="text" class="form-control" id="id_number" value="<?= htmlspecialchars($user['id_number'] ?? '') ?>" readonly>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="username" class="form-label">Username</label>
                                        <input type="text" class="form-control" id="username" value="<?= htmlspecialchars($user['username']) ?>" readonly>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="first_name" class="form-label">First Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="first_name" name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="middle_name" class="form-label">Middle Name</label>
                                        <input type="text" class="form-control" id="middle_name" name="middle_name" value="<?= htmlspecialchars($user['middle_name'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="last_name" class="form-label">Last Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="last_name" name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" required>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="extension" class="form-label">Suffix/Extension</label>
                                        <input type="text" class="form-control" id="extension" name="extension" value="<?= htmlspecialchars($user['extension'] ?? '') ?>" placeholder="Jr., Sr., III">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                        <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="contact" class="form-label">Contact Number</label>
                                        <input type="text" class="form-control" id="contact" name="contact" value="<?= htmlspecialchars($user['contact'] ?? '') ?>">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="birthdate" class="form-label">Birthdate</label>
                                        <input type="date" class="form-control" id="birthdate" value="<?= htmlspecialchars($user['birthdate'] ?? '') ?>" readonly>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="sex" class="form-label">Sex</label>
                                        <input type="text" class="form-control" id="sex" value="<?= htmlspecialchars($user['sex'] ?? '') ?>" readonly>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="role" class="form-label">Role</label>
                                        <input type="text" class="form-control" id="role" value="<?= htmlspecialchars(ucfirst($user['role'])) ?>" readonly>
                                    </div>
                                </div>

                                <button type="submit" name="update_profile" class="btn btn-success">
                                    <i class="fas fa-save"></i> Update Profile
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Change Password Card -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal">Change Password</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label for="current_password" class="form-label">Current Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                                </div>

                                <div class="mb-3">
                                    <label for="new_password" class="form-label">New Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                                    <small class="form-text text-muted">Password must be at least 6 characters long.</small>
                                </div>

                                <div class="mb-3">
                                    <label for="confirm_password" class="form-label">Confirm New Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                </div>

                                <button type="submit" name="change_password" class="btn btn-warning">
                                    <i class="fas fa-key"></i> Change Password
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <!-- Account Info Card -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal">Account Details</h5>
                        </div>
                        <div class="card-body">
                            <p><strong>Account Created:</strong><br>
                            <?= htmlspecialchars(date('F j, Y', strtotime($user['created_at']))) ?></p>
                            
                            <?php if (!empty($user['updated_at'])): ?>
                                <p><strong>Last Updated:</strong><br>
                                <?= htmlspecialchars(date('F j, Y g:i A', strtotime($user['updated_at']))) ?></p>
                            <?php endif; ?>
                            
                            <p><strong>Account Status:</strong><br>
                            <span class="badge bg-success">Active</span></p>
                        </div>
                    </div>

                    <!-- Address Info Card -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal">Address Information</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($user['street']) || !empty($user['barangay'])): ?>
                                <p class="mb-1"><?= htmlspecialchars($user['street'] ?? '') ?></p>
                                <p class="mb-1"><?= htmlspecialchars($user['barangay'] ?? '') ?></p>
                                <p class="mb-1"><?= htmlspecialchars($user['municipal'] ?? '') ?></p>
                                <p class="mb-1"><?= htmlspecialchars($user['province'] ?? '') ?></p>
                                <p class="mb-1"><?= htmlspecialchars($user['country'] ?? '') ?></p>
                                <p class="mb-0"><?= htmlspecialchars($user['zipcode'] ?? '') ?></p>
                            <?php else: ?>
                                <p class="text-muted">No address information available.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
</body>
</html>
