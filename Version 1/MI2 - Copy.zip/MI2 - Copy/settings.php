<?php
require_once __DIR__ . '/includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Fetch user settings (we'll use the users table for basic settings)
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        header('Location: logout.php');
        exit;
    }
} catch (PDOException $e) {
    error_log("Error fetching user settings: " . $e->getMessage());
    $error = "Failed to load settings.";
}

// Handle security questions update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_security'])) {
    $security_question1 = trim($_POST['security_question1']);
    $security_answer1 = trim($_POST['security_answer1']);
    $security_question2 = trim($_POST['security_question2']);
    $security_answer2 = trim($_POST['security_answer2']);
    $security_question3 = trim($_POST['security_question3']);
    $security_answer3 = trim($_POST['security_answer3']);
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET 
            security_question1 = ?, 
            security_answer1 = ?, 
            security_question2 = ?, 
            security_answer2 = ?,
            security_question3 = ?, 
            security_answer3 = ?,
            updated_at = NOW() 
            WHERE id = ?");
        
        $stmt->execute([
            $security_question1,
            $security_answer1,
            $security_question2,
            $security_answer2,
            $security_question3,
            $security_answer3,
            $user_id
        ]);
        
        $message = "Security questions updated successfully!";
        
        // Refresh user data
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("Error updating security questions: " . $e->getMessage());
        $error = "Failed to update security questions.";
    }
}

// Handle notification preferences (placeholder - can be expanded)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_notifications'])) {
    // For now, we'll just show a success message
    // You can add notification preferences to the database if needed
    $message = "Notification preferences saved!";
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Settings - Mindanao Institute</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>

<main class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>
        
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Settings</h1>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success" role="alert">
                    <i class="fas fa-check-circle"></i> <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-8">
                    <!-- Security Questions Card -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal"><i class="fas fa-shield-alt"></i> Security Questions</h5>
                        </div>
                        <div class="card-body">
                            <p class="text-muted">Update your security questions for account recovery.</p>
                            <form method="POST" action="">
                                <div class="mb-4">
                                    <label for="security_question1" class="form-label">Security Question 1 <span class="text-danger">*</span></label>
                                    <select class="form-control mb-2" id="security_question1" name="security_question1" required>
                                        <option value="">-- Select Question --</option>
                                        <option value="What is your mother's maiden name?" <?= ($user['security_question1'] ?? '') === "What is your mother's maiden name?" ? 'selected' : '' ?>>What is your mother's maiden name?</option>
                                        <option value="What was the name of your first pet?" <?= ($user['security_question1'] ?? '') === "What was the name of your first pet?" ? 'selected' : '' ?>>What was the name of your first pet?</option>
                                        <option value="What is your favorite color?" <?= ($user['security_question1'] ?? '') === "What is your favorite color?" ? 'selected' : '' ?>>What is your favorite color?</option>
                                        <option value="What city were you born in?" <?= ($user['security_question1'] ?? '') === "What city were you born in?" ? 'selected' : '' ?>>What city were you born in?</option>
                                    </select>
                                    <input type="text" class="form-control" name="security_answer1" placeholder="Your Answer" value="<?= htmlspecialchars($user['security_answer1'] ?? '') ?>" required>
                                </div>

                                <div class="mb-4">
                                    <label for="security_question2" class="form-label">Security Question 2 <span class="text-danger">*</span></label>
                                    <select class="form-control mb-2" id="security_question2" name="security_question2" required>
                                        <option value="">-- Select Question --</option>
                                        <option value="What is your favorite food?" <?= ($user['security_question2'] ?? '') === "What is your favorite food?" ? 'selected' : '' ?>>What is your favorite food?</option>
                                        <option value="What was your childhood nickname?" <?= ($user['security_question2'] ?? '') === "What was your childhood nickname?" ? 'selected' : '' ?>>What was your childhood nickname?</option>
                                        <option value="What is your favorite movie?" <?= ($user['security_question2'] ?? '') === "What is your favorite movie?" ? 'selected' : '' ?>>What is your favorite movie?</option>
                                        <option value="What is your dream job?" <?= ($user['security_question2'] ?? '') === "What is your dream job?" ? 'selected' : '' ?>>What is your dream job?</option>
                                    </select>
                                    <input type="text" class="form-control" name="security_answer2" placeholder="Your Answer" value="<?= htmlspecialchars($user['security_answer2'] ?? '') ?>" required>
                                </div>

                                <div class="mb-4">
                                    <label for="security_question3" class="form-label">Security Question 3 <span class="text-danger">*</span></label>
                                    <select class="form-control mb-2" id="security_question3" name="security_question3" required>
                                        <option value="">-- Select Question --</option>
                                        <option value="What is your favorite book?" <?= ($user['security_question3'] ?? '') === "What is your favorite book?" ? 'selected' : '' ?>>What is your favorite book?</option>
                                        <option value="What was the name of your elementary school?" <?= ($user['security_question3'] ?? '') === "What was the name of your elementary school?" ? 'selected' : '' ?>>What was the name of your elementary school?</option>
                                        <option value="What is your favorite hobby?" <?= ($user['security_question3'] ?? '') === "What is your favorite hobby?" ? 'selected' : '' ?>>What is your favorite hobby?</option>
                                        <option value="What is the name of your best friend?" <?= ($user['security_question3'] ?? '') === "What is the name of your best friend?" ? 'selected' : '' ?>>What is the name of your best friend?</option>
                                    </select>
                                    <input type="text" class="form-control" name="security_answer3" placeholder="Your Answer" value="<?= htmlspecialchars($user['security_answer3'] ?? '') ?>" required>
                                </div>

                                <button type="submit" name="update_security" class="btn btn-success">
                                    <i class="fas fa-save"></i> Update Security Questions
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Notification Preferences Card -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal"><i class="fas fa-bell"></i> Notification Preferences</h5>
                        </div>
                        <div class="card-body">
                            <p class="text-muted">Manage how you receive notifications.</p>
                            <form method="POST" action="">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="email_notifications" name="email_notifications" checked>
                                    <label class="form-check-label" for="email_notifications">
                                        Email Notifications
                                    </label>
                                    <small class="form-text text-muted d-block">Receive notifications via email</small>
                                </div>

                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="enrollment_updates" name="enrollment_updates" checked>
                                    <label class="form-check-label" for="enrollment_updates">
                                        Enrollment Updates
                                    </label>
                                    <small class="form-text text-muted d-block">Get notified about enrollment status changes</small>
                                </div>

                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="payment_reminders" name="payment_reminders" checked>
                                    <label class="form-check-label" for="payment_reminders">
                                        Payment Reminders
                                    </label>
                                    <small class="form-text text-muted d-block">Receive payment due date reminders</small>
                                </div>

                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="application_updates" name="application_updates" checked>
                                    <label class="form-check-label" for="application_updates">
                                        Application Updates
                                    </label>
                                    <small class="form-text text-muted d-block">Get notified about application status changes</small>
                                </div>

                                <button type="submit" name="update_notifications" class="btn btn-success">
                                    <i class="fas fa-save"></i> Save Preferences
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <!-- Quick Links Card -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal"><i class="fas fa-link"></i> Quick Links</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="/MI2/profile.php" class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-user"></i> View Profile
                                </a>
                                <a href="/MI2/logout.php" class="btn btn-outline-danger btn-sm">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Account Info Card -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal"><i class="fas fa-info-circle"></i> Account Information</h5>
                        </div>
                        <div class="card-body">
                            <p><strong>Username:</strong><br>
                            <?= htmlspecialchars($user['username']) ?></p>
                            
                            <p><strong>Email:</strong><br>
                            <?= htmlspecialchars($user['email']) ?></p>
                            
                            <p><strong>Role:</strong><br>
                            <span class="badge bg-primary"><?= htmlspecialchars(ucfirst($user['role'])) ?></span></p>
                            
                            <p><strong>Account Created:</strong><br>
                            <?= htmlspecialchars(date('F j, Y', strtotime($user['created_at']))) ?></p>
                        </div>
                    </div>

                    <!-- Privacy & Security Tips -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header">
                            <h5 class="my-0 fw-normal"><i class="fas fa-lock"></i> Security Tips</h5>
                        </div>
                        <div class="card-body">
                            <ul class="small mb-0">
                                <li>Use a strong, unique password</li>
                                <li>Never share your password with anyone</li>
                                <li>Update security questions regularly</li>
                                <li>Keep your contact information up to date</li>
                                <li>Log out when using shared computers</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
</body>
</html>
