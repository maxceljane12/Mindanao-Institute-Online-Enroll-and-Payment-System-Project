<?php
require_once __DIR__ . '/includes/db.php';

// Handle login
$login_error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    try {
        $stmt = $pdo->prepare("SELECT id, username, password, role, is_active FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // Check if user is active
            if (!$user['is_active']) {
                $login_error = 'Account is deactivated. Please contact administrator.';
            } else {
                session_start();
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                // Redirect based on role
                switch (strtolower($user['role'])) {
                    case 'student':
                        header('Location: student/student_dashboard.php');
                        exit;
                    case 'parent':
                        header('Location: Parent/parent_dashboard.php');
                        exit;
                    case 'cashier':
                        header('Location: cashier/cashier_dashboard.php');
                        exit;
                    case 'registrar':
                        header('Location: registrar/registrar_dashboard.php');
                        exit;
                    case 'admission':
                        header('Location: admission/admission_dashboard.php');
                        exit;
                    case 'admin':
                        header('Location: admin/admin_dashboard.php');
                        exit;
                    default:
                        $login_error = 'Invalid role assigned to user.';
                }
            }
        } else {
            $login_error = 'Invalid username or password.';
        }
    } catch (PDOException $e) {
        error_log("Login error: " . $e->getMessage());
        $login_error = 'An error occurred during login. Please try again.';
    }
}
?>

<?php include __DIR__ . '/includes/header.php'; ?>

<main class="mi-landing">
  <div class="container">
    <div class="row align-items-start">
      <!-- Left: Hero + Features -->
      <div class="col-lg-7 mb-4 mb-lg-0">
        <h1 class="mi-landing-hero-title">Welcome to</h1>
        <h1 class="mi-landing-hero-title">Mindanao Institute</h1>
        <p class="mi-landing-hero-subtitle">
          Nurturing Knowledge, Cultivating Character, and Building Leaders for Tomorrow
        </p>

        <button type="button" class="mi-landing-cta-btn" onclick="window.location.href='registration.php'">
          Get Started
        </button>

        <div class="mi-landing-features">
          <div class="row g-3">
            <div class="col-md-4">
              <div class="mi-feature-card">
                <div class="mi-feature-icon">🎓</div>
                <div>Building minds with knowledge, integrity, and innovation.</div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="mi-feature-card">
                <div class="mi-feature-icon">🏃‍♂️</div>
                <div>Shaping discipline, teamwork, and resilience through play.</div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="mi-feature-card">
                <div class="mi-feature-icon">🎭</div>
                <div>Inspiring creativity, culture, and self-expression.</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Right: Login Card -->
      <div class="col-lg-4 offset-lg-1">
        <div class="mi-login-card">
          <h2 class="mi-login-title">Login to Your Account</h2>

          <?php
            $registration_success = isset($_GET['registration_success']);
            $prefill_username = isset($_GET['username']) ? htmlspecialchars($_GET['username']) : '';
            $account_deactivated = isset($_GET['error']) && $_GET['error'] === 'account_deactivated';

            if ($login_error) {
                echo "<div class='alert alert-error'>{$login_error}</div>";
            }

            if ($registration_success) {
                echo "<div class='alert alert-success'>Registration successful. Please log in.</div>";
            }
            
            if ($account_deactivated) {
                echo "<div class='alert alert-error'>Your account has been deactivated. Please contact administrator.</div>";
            }
          ?>

          <form method="post" action="index.php" class="mi-login-form">
            <div class="form-group">
              <label for="username">Username<span class="required-asterisk">*</span></label>
              <input
                name="username"
                type="text"
                id="username"
                class="mi-login-input"
                value="<?php echo $prefill_username ?: 'Admin'; ?>"
                required
              >
            </div>

            <div class="form-group">
              <label for="password">Password<span class="required-asterisk">*</span></label>
              <input
                name="password"
                type="password"
                id="password"
                class="mi-login-input"
                value="password"
                required
              >
            </div>

            <div class="form-group">
              <button type="submit" class="mi-login-btn">Login</button>
            </div>
          </form>

          <div class="mi-login-footer">
            Don't have an account? Please <a href="registration.php">register here</a>
          </div>
          <div class="mi-login-footer">
            <a href="forgot_password.php">Forgot Password?</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
