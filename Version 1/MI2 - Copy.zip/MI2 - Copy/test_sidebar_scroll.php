<?php
session_start();
$_SESSION['role'] = 'admin';
$_SESSION['username'] = 'testuser';
$_SESSION['user_id'] = '2025-0001';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sidebar Scroll Test</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="/MI2/CSS/app.css">
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <?php 
      // Include sidebar but add extra test links for admin
      ob_start();
      include __DIR__ . '/includes/sidebar.php';
      $sidebarContent = ob_get_clean();
      
      // Add extra links for testing scroll
      if (strpos($sidebarContent, 'Admin Dashboard') !== false) {
        $extraLinks = '';
        for ($i = 1; $i <= 20; $i++) {
          $extraLinks .= '<a href="#" class="sidebar-link">' . "\n";
          $extraLinks .= '  <i class="fas fa-link"></i>' . "\n";
          $extraLinks .= '  <span>Test Link ' . $i . '</span>' . "\n";
          $extraLinks .= '</a>' . "\n";
        }
        // Insert extra links in the placeholder div
        $sidebarContent = str_replace(
          '<div class="extra-test-links"></div>',
          '<div class="extra-test-links">' . $extraLinks . '</div>',
          $sidebarContent
        );
      }
      
      echo $sidebarContent;
      ?>
      <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h1 class="h2">Sidebar Scroll Test</h1>
        </div>
        <div class="alert alert-info">
          <h4>Sidebar Scroll Test Instructions</h4>
          <ol>
            <li>Hover over the sidebar on the left to expand it</li>
            <li>Try scrolling the sidebar content vertically</li>
            <li>You should be able to scroll to see all the links, including the extra test links at the bottom</li>
          </ol>
          <p><strong>If you can see all links by scrolling, the sidebar scrolling is working correctly!</strong></p>
        </div>
        <div class="card">
          <div class="card-body">
            <h5>Main Content Area</h5>
            <p>This is the main content area. The sidebar should be scrollable when it has more content than can fit in the viewport.</p>
            <p>The sidebar has been artificially extended with extra links to ensure it overflows the viewport height, making it necessary to scroll.</p>
          </div>
        </div>
        <div class="card mt-4">
          <div class="card-body">
            <h5>Additional Content</h5>
            <p>This content is here to take up space and demonstrate that the main content area is unaffected by the sidebar scrolling changes.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>