<?php
require_once __DIR__ . '/includes/db.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username'])) {
        // Step 1: Verify username exists
        $username = trim($_POST['username']);
        
        try {
            $stmt = $pdo->prepare("SELECT id, username, security_question_1, security_question_2, security_question_3 FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                // Store user info in session for the next step
                session_start();
                $_SESSION['reset_user_id'] = $user['id'];
                $_SESSION['reset_username'] = $user['username'];
                $_SESSION['security_questions'] = [
                    $user['security_question_1'],
                    $user['security_question_2'],
                    $user['security_question_3']
                ];
                header('Location: forgot_password.php?step=security');
                exit;
            } else {
                $error = 'Username not found.';
            }
        } catch (PDOException $e) {
            error_log("Forgot password error: " . $e->getMessage());
            $error = 'An error occurred. Please try again.';
        }
    } elseif (isset($_POST['answers'])) {
        // Step 2: Verify security answers
        session_start();
        
        if (!isset($_SESSION['reset_user_id'])) {
            $error = 'Invalid request. Please start over.';
        } else {
            $answers = $_POST['answers'];
            $user_id = $_SESSION['reset_user_id'];
            
            try {
                $stmt = $pdo->prepare("SELECT answer_1, answer_2, answer_3 FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($user) {
                    // Verify answers (case insensitive)
                    $valid = true;
                    if (!password_verify(strtolower($answers[0]), $user['answer_1'])) $valid = false;
                    if (!password_verify(strtolower($answers[1]), $user['answer_2'])) $valid = false;
                    if (!password_verify(strtolower($answers[2]), $user['answer_3'])) $valid = false;
                    
                    if ($valid) {
                        // Answers are correct, proceed to reset password
                        header('Location: forgot_password.php?step=reset');
                        exit;
                    } else {
                        $error = 'One or more security answers are incorrect.';
                    }
                } else {
                    $error = 'User not found.';
                }
            } catch (PDOException $e) {
                error_log("Forgot password error: " . $e->getMessage());
                $error = 'An error occurred. Please try again.';
            }
        }
    } elseif (isset($_POST['new_password'])) {
        // Step 3: Reset password
        session_start();
        
        if (!isset($_SESSION['reset_user_id'])) {
            $error = 'Invalid request. Please start over.';
        } else {
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            $user_id = $_SESSION['reset_user_id'];
            
            // Validate passwords
            if (strlen($new_password) < 6) {
                $error = 'Password must be at least 6 characters long.';
            } elseif ($new_password !== $confirm_password) {
                $error = 'Passwords do not match.';
            } else {
                try {
                    // Hash the new password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    
                    // Update the password in the database
                    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->execute([$hashed_password, $user_id]);
                    
                    // Clear session data
                    unset($_SESSION['reset_user_id']);
                    unset($_SESSION['reset_username']);
                    unset($_SESSION['security_questions']);
                    
                    $message = 'Password successfully reset. You can now log in with your new password.';
                } catch (PDOException $e) {
                    error_log("Password reset error: " . $e->getMessage());
                    $error = 'An error occurred while resetting your password. Please try again.';
                }
            }
        }
    }
}

$step = isset($_GET['step']) ? $_GET['step'] : 'username';
?>

<?php include __DIR__ . '/includes/header.php'; ?>

<main class="container hero">
  <div class="hero-content">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    
    <div style="flex:1;">
      <h3>Forgot Password</h3>
      
      <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <p><a href="index.php">Click here to log in</a></p>
      <?php endif; ?>
      
      <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      
      <?php if ($step === 'username'): ?>
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Step 1: Enter Your Username</h5>
            <p>Please enter your username to begin the password reset process.</p>
            
            <form method="post" action="forgot_password.php">
              <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
              </div>
              <button type="submit" class="btn btn-primary">Continue</button>
            </form>
            
            <div class="mt-3">
              <a href="index.php">Back to Login</a>
            </div>
          </div>
        </div>
      <?php elseif ($step === 'security'): ?>
        <?php 
        session_start();
        if (!isset($_SESSION['security_questions'])) {
            header('Location: forgot_password.php');
            exit;
        }
        $questions = $_SESSION['security_questions'];
        ?>
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Step 2: Security Questions</h5>
            <p>Please answer the following security questions to verify your identity.</p>
            
            <form method="post" action="forgot_password.php">
              <?php for ($i = 0; $i < 3; $i++): ?>
                <?php if (!empty($questions[$i])): ?>
                  <div class="mb-3">
                    <label for="answers[<?= $i ?>]" class="form-label"><?= htmlspecialchars($questions[$i]) ?></label>
                    <input type="text" class="form-control" id="answers[<?= $i ?>]" name="answers[<?= $i ?>]" required>
                  </div>
                <?php endif; ?>
              <?php endfor; ?>
              
              <button type="submit" class="btn btn-primary">Continue</button>
            </form>
            
            <div class="mt-3">
              <a href="forgot_password.php">Start Over</a>
            </div>
          </div>
        </div>
      <?php elseif ($step === 'reset'): ?>
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Step 3: Reset Password</h5>
            <p>Please enter your new password below.</p>
            
            <form method="post" action="forgot_password.php">
              <div class="mb-3">
                <label for="new_password" class="form-label">New Password</label>
                <input type="password" class="form-control" id="new_password" name="new_password" required minlength="6">
                <div class="form-text">Password must be at least 6 characters long.</div>
              </div>
              <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm New Password</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="6">
              </div>
              <button type="submit" class="btn btn-primary">Reset Password</button>
            </form>
            
            <div class="mt-3">
              <a href="forgot_password.php">Start Over</a>
            </div>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>